# Authentication fixes included

This package updates the VideoHub + Global Jobs source project.

## Changes
- Registration UI now enforces the same 12-character minimum password length as the server (maximum 128 remains server-enforced).
- Removed the passwordless quick-demo sign-in buttons and the misleading demo-password hint.
- Removed demo persona/admin impersonation controls from the signed-in UI; demo switching now reports that it is disabled.
- Authentication session credentials are no longer copied into `localStorage` or returned in login/register/Google-auth JSON responses.
- The browser now relies on the server-issued `HttpOnly`, `SameSite=Strict` session cookie. Video upload XHR requests continue to send cookies.

## Deployment notes
- Deploy the project to Vercel with the required production environment variables documented in `.env.example` / `README.md` (including `MONGODB_URI` and a strong `AUTH_SECRET`).
- Configure `GOOGLE_CLIENT_ID` only if Google sign-in is intended to be enabled.
- After deployment, test registration with a password of at least 12 characters, login with the new account, refresh while signed in, logout, and login again.
- Existing demo accounts without password hashes cannot sign in; create a real password-protected account.

## Validation status
Source-level changes were applied. Automated lint/build/test checks could not be completed in this environment because project dependencies are not installed and package installation did not complete. Run `npm install`, then `npm run lint`, `npm run build`, `npm test`, and `npm run security:check` before production release.
