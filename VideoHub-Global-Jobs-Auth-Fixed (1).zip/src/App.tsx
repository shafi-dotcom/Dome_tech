import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { I18nProvider } from './context/I18nContext.tsx';
import { TopBar } from './components/navigation/TopBar.tsx';
import { Sidebar } from './components/navigation/Sidebar.tsx';
import { MobileBottomNav } from './components/navigation/MobileBottomNav.tsx';
import { HomeView } from './components/views/HomeView.tsx';
import { ShortsView } from './components/views/ShortsView.tsx';
import { WatchView } from './components/views/WatchView.tsx';
import { JobsView } from './components/views/JobsView.tsx';
import { ApplicationsView } from './components/views/ApplicationsView.tsx';
import { UploadView } from './components/views/UploadView.tsx';
import { SubscriptionsView } from './components/views/SubscriptionsView.tsx';
import { NotificationsView } from './components/views/NotificationsView.tsx';
import { MessagesView } from './components/views/MessagesView.tsx';
import { ProfileView } from './components/views/ProfileView.tsx';
import { AdminView } from './components/views/AdminView.tsx';
import { PlaylistsView } from './components/views/PlaylistsView.tsx';
import { LiveMatchView } from './components/views/LiveMatchView.tsx';
import { PoliciesView } from './components/views/PoliciesView.tsx';
import { MonetizationView } from './components/views/MonetizationView.tsx';
import { StoreView } from './components/views/StoreView.tsx';
import { MiniPlayer } from './components/common/MiniPlayer.tsx';
import { AuthModal } from './components/modals/AuthModal.tsx';
import { ApplyModal } from './components/modals/ApplyModal.tsx';
import { ReportModal } from './components/modals/ReportModal.tsx';
import { SettingsModal } from './components/modals/SettingsModal.tsx';
import { VerificationModal } from './components/modals/VerificationModal.tsx';
import { Video, ShieldCheck, Heart, Sparkles, Globe, ExternalLink } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeView, setActiveView, toasts, settingsModalOpen, setSettingsModalOpen } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderActiveView = () => {
    switch (activeView) {
      case 'home':
      case 'explore':
        return <HomeView />;
      case 'shorts':
        return <ShortsView />;
      case 'watch':
        return <WatchView />;
      case 'live_match':
        return <LiveMatchView />;
      case 'jobs':
        return <JobsView />;
      case 'applications':
        return <ApplicationsView />;
      case 'upload':
        return <UploadView />;
      case 'subscriptions':
        return <SubscriptionsView />;
      case 'notifications':
        return <NotificationsView />;
      case 'messages':
        return <MessagesView />;
      case 'profile':
        return <ProfileView />;
      case 'playlists':
        return <PlaylistsView />;
      case 'admin':
        return <AdminView />;
      case 'policies':
        return <PoliciesView />;
      case 'monetization':
        return <MonetizationView />;
      case 'store':
        return <StoreView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F3F4F9] dark:bg-[#0F121C] text-slate-800 dark:text-slate-100 transition-colors">
      {/* Top Header */}
      <TopBar
        sidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />

      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Collapsible Sidebar (Desktop) */}
        {activeView !== 'shorts' && (
          <Sidebar
            isOpen={sidebarOpen}
            onCloseMobile={() => setSidebarOpen(false)}
          />
        )}

        {/* Primary Content View Area */}
        <main
          className={`flex-1 min-w-0 px-4 sm:px-6 lg:px-8 py-6 transition-all duration-300 ${
            activeView === 'shorts' ? 'max-w-4xl mx-auto' : ''
          }`}
        >
          {renderActiveView()}
        </main>
      </div>

      {/* Global Footer (Visible on normal feeds) */}
      {activeView !== 'shorts' && (
        <footer className="mt-auto border-t border-slate-200/60 dark:border-slate-800/80 bg-white/70 dark:bg-[#131722]/70 backdrop-blur-md py-8 px-4 text-xs text-slate-500 pb-20 lg:pb-8">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-xl bg-gradient-to-tr from-violet-600 to-pink-500 flex items-center justify-center text-white">
                <Video className="w-3.5 h-3.5 fill-white/20" />
              </div>
              <span className="font-extrabold text-slate-900 dark:text-slate-100">
                VideoHub + Global Jobs
              </span>
              <span>• Worldwide Video Sharing & Specialized Careers</span>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-slate-400 font-semibold">
              <button onClick={() => setActiveView('home')} className="hover:text-violet-600 transition">Home</button>
              <button onClick={() => setActiveView('jobs')} className="hover:text-emerald-600 transition">Careers</button>
              <button onClick={() => setActiveView('store')} className="hover:text-amber-500 font-bold transition">Online Store</button>
              <button onClick={() => setActiveView('subscriptions')} className="hover:text-amber-600 transition">Creator Plans</button>
              <button onClick={() => setActiveView('monetization')} className="hover:text-amber-500 font-bold transition">Monetization</button>
              <button onClick={() => setActiveView('admin')} className="hover:text-rose-600 transition">Admin Console</button>
              <span>•</span>
              <button
                onClick={() => setActiveView('policies')}
                className="hover:text-indigo-500 font-bold flex items-center gap-1 text-slate-300 dark:text-slate-300 transition"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                Supplementary Platform Rules (A-H) & Monetization Terms
              </button>
              <button onClick={() => setActiveView('policies')} className="hover:text-violet-500 transition">
                Community Guidelines
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav />

      {/* Global Modals */}
      <AuthModal />
      <ApplyModal />
      <ReportModal />
      <SettingsModal isOpen={settingsModalOpen} onClose={() => setSettingsModalOpen(false)} />
      <VerificationModal />

      {/* Floating Picture-in-Picture Mini-Player */}
      <MiniPlayer />

      {/* Floating Toast Alerts Container */}
      <div className="fixed bottom-16 lg:bottom-6 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto clay-card px-4 py-2.5 text-xs font-bold text-white shadow-xl animate-in fade-in slide-in-from-bottom duration-200 flex items-center gap-2 ${
              toast.type === 'error'
                ? 'bg-rose-600'
                : toast.type === 'info'
                ? 'bg-blue-600'
                : 'bg-emerald-600'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{toast.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <I18nProvider>
        <MainLayout />
      </I18nProvider>
    </AppProvider>
  );
}
