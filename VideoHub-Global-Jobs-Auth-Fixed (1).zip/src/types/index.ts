export type UserRole = 'user' | 'creator' | 'employer' | 'admin';

export type MembershipTier = 'free' | 'creator_plus' | 'pro_creator' | 'business_recruiter';

export interface Chapter {
  timestamp: number; // in seconds
  title: string;
}

export interface Subtitle {
  startTime: number; // in seconds
  endTime: number; // in seconds
  text: string;
}

export interface User {
  id: string;
  name: string;
  displayName?: string;
  username: string;
  email: string;
  avatar: string;
  banner?: string;
  bio?: string;
  country: string;
  phone?: string;
  role: UserRole;
  verified: boolean;
  membershipPlan: MembershipTier;
  subscribersCount: number;
  followingCount: number;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: string;
  category: string;
  tags: string[];
  creatorId: string;
  creator: {
    name: string;
    username: string;
    avatar: string;
    verified: boolean;
    role?: UserRole;
  };
  views: number;
  likesCount: number;
  commentsCount: number;
  repostsCount?: number;
  isLiked?: boolean;
  isReposted?: boolean;
  isShort: boolean;
  visibility: 'public' | 'unlisted' | 'private';
  commentsEnabled: boolean;
  processingStatus: 'ready' | 'processing' | 'failed';
  moderationStatus: 'approved' | 'pending' | 'flagged' | 'removed';
  createdAt: string;
  chapters?: Chapter[];
  subtitles?: Subtitle[];
  isMonetized?: boolean;
  earnings?: number;
}

export interface Repost {
  id: string;
  videoId: string;
  userId: string;
  user: {
    name: string;
    username: string;
    avatar: string;
    verified?: boolean;
    role?: UserRole;
  };
  quoteText?: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  user: {
    name: string;
    username: string;
    avatar: string;
    verified?: boolean;
  };
  text: string;
  likesCount: number;
  isLiked?: boolean;
  createdAt: string;
}

export type JobCategory =
  | 'Aluminium & Façade Engineering'
  | 'Curtain Wall & Glazing'
  | 'Architectural Engineering'
  | 'Civil Engineering'
  | 'AutoCAD Drafting'
  | 'Revit & BIM'
  | 'Surveying'
  | 'Manufacturing & Fabrication'
  | 'Construction Management'
  | 'Software & IT'
  | 'Sales & Marketing'
  | 'Administration';

export type EmploymentType = 'Full-time' | 'Part-time' | 'Contract' | 'Remote' | 'Hybrid';

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo: string;
  location: string;
  country: string;
  category: JobCategory | string;
  employmentType: EmploymentType;
  experienceLevel: 'Entry' | 'Mid-level' | 'Senior' | 'Lead' | 'Director';
  salaryMin: number;
  salaryMax: number;
  currency: string;
  description: string;
  responsibilities: string[];
  qualifications: string[];
  deadline: string;
  contactEmail: string;
  employerId: string;
  status: 'active' | 'closed' | 'under_review';
  featured?: boolean;
  applicantsCount: number;
  isSaved?: boolean;
  createdAt: string;
}

export type ApplicationStatus =
  | 'Submitted'
  | 'Under Review'
  | 'Shortlisted'
  | 'Interview'
  | 'Rejected'
  | 'Hired';

export interface JobApplication {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  applicantId: string;
  applicantName: string;
  applicantEmail: string;
  applicantPhone: string;
  resumeFileName: string;
  portfolioUrl?: string;
  coverNote?: string;
  videoPitchUrl?: string;
  videoPitchTitle?: string;
  videoPitchDuration?: string;
  status: ApplicationStatus;
  createdAt: string;
  updatedAt: string;
}

export type NotificationType =
  | 'like'
  | 'comment'
  | 'follow'
  | 'mention'
  | 'job_status'
  | 'job_alert'
  | 'membership'
  | 'admin_announcement'
  | 'video_ready';

export interface Notification {
  id: string;
  recipientId: string;
  actorId?: string;
  actorName?: string;
  actorAvatar?: string;
  type: NotificationType;
  title: string;
  message: string;
  link?: string;
  read: boolean;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  createdAt: string;
}

export interface Conversation {
  id: string;
  participants: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    role: UserRole;
  }[];
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount?: number;
}

export interface MembershipPlan {
  id: MembershipTier;
  name: string;
  priceMonthly: number;
  tagline: string;
  badge: string;
  badgeColor: string;
  perks: string[];
  recommended?: boolean;
}

export interface Report {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'video' | 'comment' | 'job' | 'user';
  targetId: string;
  targetTitle: string;
  reason: string;
  details?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface AuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface Playlist {
  id: string;
  name: string;
  videoIds: string[];
}

export interface LiveGiftItem {
  id: string;
  name: string;
  icon: string;
  coins: number;
  points: number;
  exclusiveSubscriber?: boolean;
  effect: 'sparkle' | 'rocket' | 'crown' | 'fire' | 'trophy' | 'galaxy';
}

export interface LiveMatchChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  isSubscriber: boolean;
  subscriberTier?: string;
  text: string;
  createdAt: string;
}

export interface LiveMatchGiftEvent {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  giftCost: number;
  points: number;
  multiplier: number;
  targetTeam: 'red' | 'blue';
  createdAt: string;
}

export interface LiveMatchParticipant {
  id: string;
  name: string;
  username: string;
  avatar: string;
  role: string;
  verified: boolean;
  team: 'red' | 'blue';
  teamName: string;
  score: number;
  videoUrl: string;
  subscribersGiftingCount: number;
}

export interface LiveMatchMysteryDrop {
  id: string;
  title: string;
  prizeCoins: number;
  remainingClaims: number;
  totalClaims: number;
  expiresAt: string;
  claimedByUserIds: string[];
}

export interface LiveMatchRoom {
  id: string;
  title: string;
  category: string;
  status: 'live' | 'speed_challenge' | 'sudden_death' | 'ended';
  startedAt: string;
  endsAt: string;
  durationSeconds: number;
  viewersCount: number;
  subscribersCount: number;
  winningsPool: number; // in Coins
  activeDrop?: LiveMatchMysteryDrop | null;
  host: LiveMatchParticipant;
  opponent: LiveMatchParticipant;
  chatMessages: LiveMatchChatMessage[];
  recentGifts: LiveMatchGiftEvent[];
  topDonors: {
    userId: string;
    userName: string;
    userAvatar: string;
    targetTeam: 'red' | 'blue';
    totalPoints: number;
    isSubscriber: boolean;
  }[];
}

export interface MonetizationEligibility {
  isEligible: boolean;
  status: 'not_applied' | 'under_review' | 'active' | 'suspended';
  currentSubscribers: number;
  requiredSubscribers: number;
  currentWatchHours: number;
  requiredWatchHours: number;
  currentShortsViews: number;
  requiredShortsViews: number;
  twoStepVerification: boolean;
  communityGuidelinesCompliant: boolean;
  termsAcceptedDate?: string;
}

export interface CreatorEarningsBreakdown {
  watchPageAds: number;
  shortsFeedAds: number;
  channelMemberships: number;
  liveGiftDrops: number;
  superThanksTips: number;
  sponsoredDeals: number;
}

export interface MonetizationTransaction {
  id: string;
  type: 'ad_revenue' | 'membership' | 'gift_winnings' | 'super_thanks' | 'payout';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'processing';
  referenceId?: string;
}

export interface CreatorMonetizationData {
  partnerStatus?: 'active' | 'eligible' | 'under_review';
  eligibility: MonetizationEligibility;
  totalEstimatedRevenue: number;
  pendingBalance: number;
  availableCashoutBalance: number;
  lifetimeEarnings: number;
  currency: string;
  rpm: number; // Revenue per mille (1,000 views)
  cpm: number;
  adsEnabledGlobally: boolean;
  revenueBreakdown: CreatorEarningsBreakdown;
  recentTransactions: MonetizationTransaction[];
  balance?: {
    available: number;
    pending: number;
    totalRevenue: number;
    rpm: number;
    cpm: number;
  };
  breakdown?: {
    watchPageAds: number;
    shortsFeedAds: number;
    memberships: number;
    liveGifts: number;
    superThanks: number;
    sponsoredDeals: number;
  };
  videos?: Video[];
  payoutMethod?: {
    type: 'bank_wire' | 'iban' | 'paypal' | 'stripe';
    accountName: string;
    details: string;
  };
}

export type ProductCategory =
  | 'all'
  | 'electronics'
  | 'fashion'
  | 'home_living'
  | 'tools_diy'
  | 'sports_fitness'
  | 'digital_assets'
  | 'creator_merch'
  | 'industrial_facade'
  | 'facade_hardware'
  | 'fabrication_tools'
  | 'safety_gear'
  | 'machinery'
  | 'bim_templates';

export type ProductCondition = 'new' | 'certified_refurbished' | 'engineering_spec' | 'digital';

export interface StoreProduct {
  id: string;
  title: string;
  description: string;
  category: ProductCategory;
  categoryName: string;
  price: number; // in USD
  currency: string;
  compareAtPrice?: number;
  condition: ProductCondition;
  rating: number;
  reviewsCount: number;
  stock: number;
  images: string[];
  thumbnailUrl: string;
  features: string[];
  specifications: Record<string, string>;
  brand: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  sellerVerified: boolean;
  shippingInfo: {
    freeShipping: boolean;
    estimatedDelivery: string;
    shipsFrom: string;
    shippingCost?: number;
  };
  tags: string[];
  isFeatured?: boolean;
  isCreatorProduct?: boolean;
  createdAt: string;
}

export interface CartItem {
  product: StoreProduct;
  quantity: number;
  selectedOptions?: Record<string, string>;
}

export interface StoreOrder {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  items: {
    productId: string;
    title: string;
    price: number;
    quantity: number;
    thumbnailUrl: string;
  }[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  currency: string;
  shippingAddress: {
    fullName: string;
    street: string;
    city: string;
    country: string;
    postalCode: string;
    phone: string;
  };
  paymentMethod: 'card' | 'apple_pay' | 'mada' | 'cash_on_delivery';
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  trackingNumber?: string;
  createdAt: string;
}

