import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { useI18n, AVAILABLE_LANGUAGES, Language } from '../../context/I18nContext.tsx';
import { X, Play, Globe, Check, ChevronDown } from 'lucide-react';

export const SettingsModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { isAutoplay, setIsAutoplay, setActiveView, showToast } = useApp();
  const { language, setLanguage, t, currentLanguageDetails } = useI18n();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  if (!isOpen) return null;

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang);
    setDropdownOpen(false);
    const selected = AVAILABLE_LANGUAGES.find(l => l.code === newLang);
    showToast(
      `🌐 Language updated to ${selected?.nativeName || newLang} (${selected?.name})`,
      'info'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="clay-card p-6 w-full max-w-lg bg-white dark:bg-[#181D2E] border border-slate-200/80 dark:border-slate-800 shadow-2xl rounded-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
              {t('settings')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t('general_settings')}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            aria-label="Close Settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Language Selection Dropdown (English, Spanish, French, Japanese, Arabic) */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300 ring-2 ring-emerald-500/20">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                      {t('language')}
                    </p>
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300">
                      {currentLanguageDetails.flag} {currentLanguageDetails.code.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {t('language_desc')}
                  </p>
                </div>
              </div>
            </div>

            {/* Custom Responsive Dropdown Selector */}
            <div className="relative pt-1">
              <button
                type="button"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm hover:border-violet-400 dark:hover:border-violet-500 transition-all text-left"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl leading-none">{currentLanguageDetails.flag}</span>
                  <div>
                    <span className="text-xs font-black text-slate-900 dark:text-slate-100 block">
                      {currentLanguageDetails.nativeName}
                    </span>
                    <span className="text-[10px] text-slate-400 block -mt-0.5">
                      {currentLanguageDetails.name} • {currentLanguageDetails.region}
                    </span>
                  </div>
                </div>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Dropdown Menu */}
              {dropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-1.5 p-1.5 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700 rounded-2xl shadow-2xl z-30 animate-in fade-in zoom-in-95 duration-150 divide-y divide-slate-100 dark:divide-slate-800">
                  {AVAILABLE_LANGUAGES.map((langOption) => {
                    const isSelected = language === langOption.code;
                    return (
                      <button
                        key={langOption.code}
                        type="button"
                        onClick={() => handleLanguageChange(langOption.code)}
                        className={`w-full flex items-center justify-between p-2.5 rounded-xl transition text-left ${
                          isSelected
                            ? 'bg-violet-50 dark:bg-violet-950/50 text-violet-700 dark:text-violet-300 font-bold'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800/70 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-xl leading-none">{langOption.flag}</span>
                          <div>
                            <span className="text-xs font-black block">
                              {langOption.nativeName}
                            </span>
                            <span className="text-[10px] text-slate-400 block -mt-0.5">
                              {langOption.name} ({langOption.region})
                            </span>
                          </div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-violet-600 dark:text-violet-400 flex-shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Auto-Play Toggle Setting */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-xl transition-colors ${
                  isAutoplay
                    ? 'bg-violet-100 text-violet-600 dark:bg-violet-900/50 dark:text-violet-300 ring-2 ring-violet-500/20'
                    : 'bg-slate-200 text-slate-500 dark:bg-slate-700 dark:text-slate-400'
                }`}>
                  <Play className={`w-5 h-5 ${isAutoplay ? 'fill-current' : ''}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                      {t('autoplay')}
                    </p>
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      isAutoplay
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300'
                        : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                    }`}>
                      {isAutoplay ? t('enabled') : t('disabled')}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {t('autoplay_desc')}
                  </p>
                </div>
              </div>

              {/* Claymorphic Switch Toggle */}
              <button
                type="button"
                role="switch"
                aria-checked={isAutoplay}
                onClick={() => {
                  const nextState = !isAutoplay;
                  setIsAutoplay(nextState);
                  showToast(
                    nextState
                      ? '⚡ Auto-play enabled: Videos will preview automatically on scroll'
                      : '🛑 Auto-play disabled: Videos will stay paused until tapped',
                    'info'
                  );
                }}
                className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${
                  isAutoplay ? 'bg-violet-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className="sr-only">Toggle auto-play on scroll</span>
                <span
                  aria-hidden="true"
                  className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                    isAutoplay ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Supplementary Platform Rules & Legal Compliance */}
          <div className="p-4 rounded-2xl bg-violet-50/70 dark:bg-violet-950/20 border border-violet-200 dark:border-violet-900/40 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-violet-600" />
              <p className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                World Video Hub Policies
              </p>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400">
              Supplementary provisions governing video uploads (A), shorts & long videos (B & C), global jobs (D), sponsored promotions (E), reporting (F), account deletion (G), and endorsement disclaimers (H).
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  onClose();
                  setActiveView('policies');
                }}
                className="flex-1 px-3 py-2 text-xs font-bold rounded-xl bg-violet-600 hover:bg-violet-700 text-white transition shadow-sm text-center"
              >
                Supplementary Rules (A–H)
              </button>
              <button
                onClick={() => {
                  onClose();
                  setActiveView('policies');
                }}
                className="px-3 py-2 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition text-center"
              >
                Delete Account (Sec. G)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
