import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { StoreOrder } from '../../types/index.ts';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  CreditCard,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Tag,
  ArrowRight,
  ExternalLink,
  Lock,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderPlaced?: (order: StoreOrder) => void;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  onOrderPlaced
}) => {
  const {
    currentUser,
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartSubtotal,
    cartCount,
    showToast,
    setAuthModalOpen,
    setActiveView
  } = useApp();

  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('ALUM2026');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<StoreOrder | null>(null);

  // Checkout address state
  const [address, setAddress] = useState({
    fullName: currentUser?.displayName || currentUser?.name || 'Shafi Afzal Shah',
    street: 'King Fahd Road, Al Olaya District',
    city: 'Riyadh',
    country: 'Saudi Arabia',
    postalCode: '12214',
    phone: currentUser?.phone || '+966 50 123 4567'
  });

  const [paymentMethod, setPaymentMethod] = useState<'mada' | 'apple_pay' | 'card' | 'cash_on_delivery'>('mada');

  if (!isOpen) return null;

  // Coupon calculations
  let discountAmount = 0;
  if (appliedCoupon === 'STORE20') {
    discountAmount = cartSubtotal * 0.20;
  } else if (appliedCoupon === 'ALUM2026' || appliedCoupon === 'SHAFI15' || appliedCoupon === 'GLOBAL15') {
    discountAmount = cartSubtotal * 0.15;
  } else if (appliedCoupon === 'WELCOME10') {
    discountAmount = cartSubtotal * 0.10;
  }

  const freeShippingThreshold = 150;
  const isFreeShipping = cartSubtotal >= freeShippingThreshold;
  const shippingFee = cart.length === 0 ? 0 : (isFreeShipping ? 0 : 15.00);
  const finalTotal = Math.max(0, cartSubtotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponInput.toUpperCase().trim();
    if (code === 'STORE20') {
      setAppliedCoupon(code);
      showToast('Coupon "STORE20" applied: 20% discount unlocked!', 'success');
      setCouponInput('');
    } else if (code === 'ALUM2026' || code === 'SHAFI15' || code === 'GLOBAL15') {
      setAppliedCoupon(code);
      showToast(`Coupon "${code}" applied: 15% discount unlocked!`, 'success');
      setCouponInput('');
    } else if (code === 'WELCOME10') {
      setAppliedCoupon(code);
      showToast('Coupon "WELCOME10" applied: 10% discount unlocked!', 'success');
      setCouponInput('');
    } else {
      showToast('Invalid coupon code. Try "STORE20", "GLOBAL15", or "ALUM2026"', 'error');
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    if (cart.length === 0) {
      showToast('Your cart is empty', 'error');
      return;
    }

    try {
      setIsSubmittingOrder(true);
      const res = await fetch('/api/store/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map(item => ({
            productId: item.product.id,
            title: item.product.title,
            price: item.product.price,
            quantity: item.quantity,
            thumbnailUrl: item.product.thumbnailUrl
          })),
          shippingAddress: address,
          paymentMethod,
          couponCode: appliedCoupon
        })
      });

      const data = await res.json();
      if (res.ok && data.order) {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
        setConfirmedOrder(data.order);
        clearCart();
        setIsCheckingOut(false);
        showToast('🎉 Order placed successfully! Tracking code generated.', 'success');
        if (onOrderPlaced) onOrderPlaced(data.order);
      } else {
        showToast(data.error || 'Failed to place order', 'error');
      }
    } catch (err: any) {
      showToast('Order processing error: ' + err.message, 'error');
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="clay-card bg-white dark:bg-[#131722] max-w-2xl w-full max-h-[92vh] overflow-y-auto no-scrollbar rounded-3xl p-5 sm:p-7 space-y-6 shadow-2xl border border-slate-200/80 dark:border-slate-800 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/25">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                {confirmedOrder ? 'Order Confirmed' : isCheckingOut ? 'Express Checkout' : 'Shopping Cart'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {confirmedOrder
                  ? `Receipt #${confirmedOrder.id} • Dispatched via Express Logistics`
                  : isCheckingOut
                  ? 'Verify your delivery address & payment option'
                  : `${cartCount} item${cartCount === 1 ? '' : 's'} in your bag`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ORDER SUCCESS SCREEN */}
        {confirmedOrder ? (
          <div className="space-y-6 py-4 text-center">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-slate-900 dark:text-slate-100">
                Thank You for Your Order!
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                Your engineering equipment and tools have been recorded and sent to the certified seller for immediate preparation.
              </p>
            </div>

            {/* Order Details Card */}
            <div className="clay-card p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 text-left text-xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800 pb-2">
                <span className="font-bold text-slate-400">Order ID:</span>
                <span className="font-mono font-black text-slate-900 dark:text-slate-100">{confirmedOrder.id}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800 pb-2">
                <span className="font-bold text-slate-400">Tracking Code:</span>
                <span className="font-mono font-black text-indigo-600 dark:text-indigo-400">{confirmedOrder.trackingNumber}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800 pb-2">
                <span className="font-bold text-slate-400">Total Paid:</span>
                <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-sm">
                  ${confirmedOrder.total.toFixed(2)} USD (≈ {(confirmedOrder.total * 3.75).toFixed(0)} SAR)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-400">Delivery To:</span>
                <span className="font-bold text-slate-700 dark:text-slate-300 truncate max-w-xs">
                  {confirmedOrder.shippingAddress.fullName}, {confirmedOrder.shippingAddress.city}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => {
                  setConfirmedOrder(null);
                  onClose();
                }}
                className="clay-btn clay-btn-primary px-6 py-2.5 text-xs font-black"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        ) : isCheckingOut ? (
          /* CHECKOUT FORM */
          <form onSubmit={handlePlaceOrder} className="space-y-5">
            {/* Delivery Address */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-black uppercase text-slate-400">
                <Truck className="w-4 h-4 text-amber-500" />
                <span>1. Shipping & Delivery Address</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={address.fullName}
                    onChange={e => setAddress({ ...address, fullName: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={address.phone}
                    onChange={e => setAddress({ ...address, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Street Address / Facility</label>
                <input
                  type="text"
                  required
                  value={address.street}
                  onChange={e => setAddress({ ...address, street: e.target.value })}
                  className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={address.city}
                    onChange={e => setAddress({ ...address, city: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Country</label>
                  <input
                    type="text"
                    required
                    value={address.country}
                    onChange={e => setAddress({ ...address, country: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Postal Code</label>
                  <input
                    type="text"
                    required
                    value={address.postalCode}
                    onChange={e => setAddress({ ...address, postalCode: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input rounded-xl"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-xs font-black uppercase text-slate-400">
                <CreditCard className="w-4 h-4 text-emerald-500" />
                <span>2. Payment Method</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('mada')}
                  className={`p-3 rounded-2xl border text-center transition ${
                    paymentMethod === 'mada'
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-400/40 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <p className="text-xs font-black">Mada (مدى)</p>
                  <span className="text-[10px] text-slate-400">Saudi Debit</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('apple_pay')}
                  className={`p-3 rounded-2xl border text-center transition ${
                    paymentMethod === 'apple_pay'
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-400/40 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <p className="text-xs font-black">Apple Pay</p>
                  <span className="text-[10px] text-slate-400">1-Touch Pay</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-2xl border text-center transition ${
                    paymentMethod === 'card'
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-400/40 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <p className="text-xs font-black">Credit Card</p>
                  <span className="text-[10px] text-slate-400">Visa/Mastercard</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash_on_delivery')}
                  className={`p-3 rounded-2xl border text-center transition ${
                    paymentMethod === 'cash_on_delivery'
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-400/40 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <p className="text-xs font-black">COD</p>
                  <span className="text-[10px] text-slate-400">Pay on Receipt</span>
                </button>
              </div>
            </div>

            {/* Price Summary Breakdown */}
            <div className="clay-card p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 text-xs space-y-2">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Items Subtotal:</span>
                <span className="font-mono font-bold">${cartSubtotal.toFixed(2)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                  <span>Voucher Discount ({appliedCoupon}):</span>
                  <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Shipping:</span>
                <span className="font-mono font-bold">{shippingFee === 0 ? 'FREE' : `$${shippingFee.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm font-black text-slate-900 dark:text-slate-100 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span>Total Amount:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                  ${finalTotal.toFixed(2)} USD (≈ {(finalTotal * 3.75).toFixed(0)} SAR)
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => setIsCheckingOut(false)}
                className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
              >
                Back to Cart
              </button>
              <button
                type="submit"
                disabled={isSubmittingOrder}
                className="clay-btn clay-btn-primary px-6 py-2.5 text-xs font-black bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-500/25 flex items-center gap-2"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isSubmittingOrder ? 'Processing...' : `Pay $${finalTotal.toFixed(2)} Now`}</span>
              </button>
            </div>
          </form>
        ) : (
          /* CART ITEMS VIEW */
          <div className="space-y-5">
            {/* Free Shipping Progress Indicator */}
            <div className="p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/60 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-amber-600" />
                  {isFreeShipping
                    ? '🎉 You unlocked FREE Express GCC Delivery!'
                    : `Add $${(freeShippingThreshold - cartSubtotal).toFixed(2)} more for FREE Express Delivery!`}
                </span>
                <span className="font-mono text-amber-700 dark:text-amber-400">
                  {Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100))}%
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (cartSubtotal / freeShippingThreshold) * 100)}%` }}
                />
              </div>
            </div>

            {/* Cart Items List */}
            {cart.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Your cart is empty
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                  Explore verified façade equipment, suction lifters, safety gear, and digital CAD packs in the store.
                </p>
                <button
                  onClick={onClose}
                  className="clay-btn clay-btn-primary px-5 py-2 text-xs font-bold mt-2"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/70 dark:border-slate-800 transition"
                  >
                    <img
                      src={item.product.thumbnailUrl}
                      alt={item.product.title}
                      className="w-14 h-14 rounded-xl object-cover bg-slate-800 flex-shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                        {item.product.title}
                      </h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Brand: {item.product.brand}
                      </p>
                      <div className="text-xs font-black text-emerald-600 dark:text-emerald-400 mt-1 font-mono">
                        ${item.product.price.toFixed(2)} USD
                      </div>
                    </div>

                    {/* Quantity Stepper */}
                    <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1">
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-bold font-mono">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                        className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Delete Item */}
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="p-2 text-slate-400 hover:text-rose-500 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/30 transition ml-1"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {cart.length > 0 && (
              <>
                {/* Coupon Code Input */}
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Promo code (e.g. ALUM2026, SHAFI15)"
                      value={couponInput}
                      onChange={e => setCouponInput(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs clay-input rounded-xl uppercase font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                  >
                    Apply
                  </button>
                </form>

                {/* Pricing Summary */}
                <div className="clay-card p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 text-xs space-y-2">
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Subtotal:</span>
                    <span className="font-mono font-bold">${cartSubtotal.toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                      <span>Voucher Discount ({appliedCoupon}):</span>
                      <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Shipping:</span>
                    <span className="font-mono font-bold">{shippingFee === 0 ? 'FREE' : `$${shippingFee.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-slate-900 dark:text-slate-100 pt-2 border-t border-slate-200 dark:border-slate-800">
                    <span>Estimated Total:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                      ${finalTotal.toFixed(2)} USD (≈ {(finalTotal * 3.75).toFixed(0)} SAR)
                    </span>
                  </div>
                </div>

                {/* Checkout Trigger */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={clearCart}
                    className="text-xs text-slate-400 hover:text-rose-500 font-medium"
                  >
                    Empty Bag
                  </button>
                  <button
                    onClick={() => {
                      if (!currentUser) {
                        setAuthModalOpen(true);
                        return;
                      }
                      setIsCheckingOut(true);
                    }}
                    className="clay-btn clay-btn-primary px-6 py-2.5 text-xs font-black bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white shadow-lg shadow-amber-500/25 flex items-center gap-2"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
