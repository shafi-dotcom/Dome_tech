import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { useSearchHistory } from '../../hooks/useSearchHistory.ts';
import { StoreProduct, ProductCategory, StoreOrder } from '../../types/index.ts';
import { CreateListingModal } from '../modals/CreateListingModal.tsx';
import { CartModal } from '../modals/CartModal.tsx';
import {
  ShoppingBag,
  Heart,
  Search,
  Filter,
  Plus,
  Star,
  Truck,
  ShieldCheck,
  Package,
  Layers,
  Sparkles,
  ExternalLink,
  CheckCircle2,
  Trash2,
  X,
  Clock,
  ArrowRight,
  Eye,
  Check,
  SlidersHorizontal,
  ChevronRight,
  DollarSign
} from 'lucide-react';
import confetti from 'canvas-confetti';

const CATEGORIES: { id: ProductCategory; label: string; icon: string }[] = [
  { id: 'all', label: 'All Products', icon: '⚡' },
  { id: 'electronics', label: 'Electronics & Tech', icon: '📱' },
  { id: 'fashion', label: 'Fashion & Apparel', icon: '👕' },
  { id: 'home_living', label: 'Home & Living', icon: '☕' },
  { id: 'tools_diy', label: 'Tools, Hardware & DIY', icon: '🛠️' },
  { id: 'sports_fitness', label: 'Sports & Fitness', icon: '🏋️' },
  { id: 'digital_assets', label: 'Digital Assets & Software', icon: '💾' },
  { id: 'creator_merch', label: 'Creator Merch & Swag', icon: '✨' },
  { id: 'industrial_facade', label: 'Industrial & Façade', icon: '🏢' }
];

export const StoreView: React.FC = () => {
  const {
    currentUser,
    wishlistProductIds,
    toggleWishlist,
    isInWishlist,
    cart,
    addToCart,
    cartCount,
    showToast,
    setAuthModalOpen,
    storeCategory,
    setStoreCategory
  } = useApp();

  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showStoreHistory, setShowStoreHistory] = useState(false);
  const {
    history: storeHistory,
    addQuery: addStoreQuery,
    removeQuery: removeStoreQuery,
    clearHistory: clearStoreHistory
  } = useSearchHistory('storeSearchHistory');
  const [activeTab, setActiveTab] = useState<'all' | 'wishlist' | 'my_listings' | 'orders'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'rating'>('featured');

  // Modals state
  const [createListingOpen, setCreateListingOpen] = useState(false);
  const [cartModalOpen, setCartModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<StoreProduct | null>(null);
  const [modalQuantity, setModalQuantity] = useState(1);

  // Orders state
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  // Fetch products from backend
  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/store/products');
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
      }
    } catch (err) {
      console.error('Failed to load store products:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    try {
      setLoadingOrders(true);
      const res = await fetch('/api/store/orders');
      if (res.ok) {
        const data = await res.json();
        setOrders(data.orders || []);
      }
    } catch (err) {
      console.error('Failed to load orders:', err);
    } finally {
      setLoadingOrders(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    if (activeTab === 'orders') {
      fetchOrders();
    }
  }, [activeTab]);

  const handleDeleteListing = async (productId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to remove this product listing from the store?')) {
      return;
    }
    try {
      const res = await fetch(`/api/store/products/${productId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Product listing removed', 'info');
        setProducts(prev => prev.filter(p => p.id !== productId));
        if (selectedProduct?.id === productId) setSelectedProduct(null);
      }
    } catch (err) {
      showToast('Failed to delete listing', 'error');
    }
  };

  // Filter & sort products
  const filteredProducts = products.filter((p) => {
    // Tab filter
    if (activeTab === 'wishlist' && !isInWishlist(p.id)) {
      return false;
    }
    if (activeTab === 'my_listings' && currentUser && p.sellerId !== currentUser.id) {
      return false;
    }

    // Category filter
    if (storeCategory !== 'all') {
      if (storeCategory === 'industrial_facade') {
        const isIndustrial =
          p.category === 'industrial_facade' ||
          p.category === 'facade_hardware' ||
          p.category === 'machinery' ||
          p.category === 'safety_gear';
        if (!isIndustrial) return false;
      } else if (storeCategory === 'tools_diy') {
        const isTool = p.category === 'tools_diy' || p.category === 'fabrication_tools';
        if (!isTool) return false;
      } else if (storeCategory === 'digital_assets') {
        const isDigital = p.category === 'digital_assets' || p.category === 'bim_templates';
        if (!isDigital) return false;
      } else if (p.category !== storeCategory) {
        return false;
      }
    }

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchTitle = p.title.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      const matchBrand = p.brand.toLowerCase().includes(q);
      const matchCategory = p.categoryName.toLowerCase().includes(q);
      const matchTags = p.tags && p.tags.some(t => t.toLowerCase().includes(q));
      if (!matchTitle && !matchDesc && !matchBrand && !matchCategory && !matchTags) {
        return false;
      }
    }

    return true;
  });

  // Sort logic
  filteredProducts.sort((a, b) => {
    if (sortBy === 'price_asc') return a.price - b.price;
    if (sortBy === 'price_desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
  });

  const wishlistCount = products.filter(p => isInWishlist(p.id)).length;
  const myListingsCount = currentUser ? products.filter(p => p.sellerId === currentUser.id).length : 0;

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in pb-20">
      {/* Hero Banner */}
      <div className="clay-card p-6 sm:p-8 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 text-white shadow-2xl relative overflow-hidden rounded-3xl">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-white/5 rounded-l-full pointer-events-none transform translate-x-32" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-black uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Global Creator & Consumer Marketplace</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              World Hub Online Marketplace & Store
            </h1>
            <p className="text-white/90 text-xs sm:text-sm max-w-2xl leading-relaxed">
              Shop 4K streaming cameras, ANC studio headphones, smartwatches, urban streetwear, barista espresso makers, cordless power tools, percussion massagers, digital software templates, and industrial hardware.
            </p>
          </div>

          {/* Header Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                if (!currentUser) {
                  setAuthModalOpen(true);
                  return;
                }
                setCreateListingOpen(true);
              }}
              className="clay-btn bg-white text-slate-900 hover:bg-amber-50 px-4 py-2.5 rounded-2xl text-xs font-black shadow-xl flex items-center gap-2 transition active:scale-95"
            >
              <Plus className="w-4 h-4 text-amber-600" />
              <span>List a Product</span>
            </button>

            {/* My Wishlist Quick Navigation Button */}
            <button
              onClick={() => setActiveTab('wishlist')}
              className={`clay-btn px-4 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 backdrop-blur-md transition active:scale-95 border ${
                activeTab === 'wishlist'
                  ? 'bg-rose-500 text-white border-rose-400 shadow-xl shadow-rose-500/30'
                  : 'bg-white/20 hover:bg-white/30 text-white border-white/20'
              }`}
            >
              <Heart className={`w-4 h-4 ${wishlistCount > 0 ? 'fill-current text-white' : ''}`} />
              <span>My Wishlist</span>
              {wishlistCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-rose-400 text-white text-[10px] font-black flex items-center justify-center shadow-md">
                  {wishlistCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setCartModalOpen(true)}
              className="clay-btn bg-white/20 hover:bg-white/30 text-white px-4 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 backdrop-blur-md transition active:scale-95 border border-white/20 relative"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Cart</span>
              {cartCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-900 text-[10px] font-black flex items-center justify-center shadow-md">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/80 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'all'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/25'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <span>All Store Products</span>
            <span className="px-1.5 py-0.5 rounded-full bg-white/20 text-[10px]">
              {products.length}
            </span>
          </button>

          {/* Wishlist Tab */}
          <button
            onClick={() => setActiveTab('wishlist')}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'wishlist'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/25'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${activeTab === 'wishlist' ? 'fill-current' : 'text-rose-500'}`} />
            <span>My Wishlist</span>
            {wishlistCount > 0 && (
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${
                activeTab === 'wishlist' ? 'bg-white text-rose-600' : 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
              }`}>
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Seller / My Listings Tab */}
          <button
            onClick={() => {
              if (!currentUser) {
                setAuthModalOpen(true);
                return;
              }
              setActiveTab('my_listings');
            }}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'my_listings'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/25'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>My Listings</span>
            {myListingsCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[10px]">
                {myListingsCount}
              </span>
            )}
          </button>

          {/* Order History Tab */}
          <button
            onClick={() => {
              if (!currentUser) {
                setAuthModalOpen(true);
                return;
              }
              setActiveTab('orders');
            }}
            className={`px-4 py-2 rounded-2xl text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'orders'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/25'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Order History</span>
            {orders.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px]">
                {orders.length}
              </span>
            )}
          </button>
        </div>

        {/* Sorting Dropdown */}
        {activeTab !== 'orders' && (
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <span className="text-xs text-slate-400 font-bold hidden sm:inline">Sort by:</span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="px-3 py-1.5 text-xs clay-input rounded-xl bg-white dark:bg-slate-800 font-bold"
            >
              <option value="featured">Featured First</option>
              <option value="rating">Highest Rated</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        )}
      </div>

      {/* Category Pills & Search Filter */}
      {activeTab !== 'orders' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Search Input with Recent Searches Dropdown */}
            <div className="relative w-full sm:w-96">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search electronics, smartwatches, fashion, home, tools, fitness..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onFocus={() => setShowStoreHistory(true)}
                onBlur={() => setTimeout(() => setShowStoreHistory(false), 250)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim()) {
                    addStoreQuery(searchQuery);
                    setShowStoreHistory(false);
                  }
                }}
                className="w-full pl-10 pr-9 py-2 text-xs clay-input rounded-2xl"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Store Recent Searches Dropdown (Last 5 Queries) */}
              {showStoreHistory && storeHistory.length > 0 && (
                <div
                  onMouseDown={(e) => e.preventDefault()}
                  className="absolute top-full left-0 w-full mt-2 clay-card bg-white dark:bg-[#181D2E] border border-slate-200/80 dark:border-slate-800 shadow-2xl rounded-2xl p-2.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                >
                  <div className="flex justify-between items-center px-2 py-1 border-b border-slate-100 dark:border-slate-800/80 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-500" />
                      Recent Searches
                    </span>
                    <button
                      type="button"
                      onClick={clearStoreHistory}
                      className="text-amber-600 dark:text-amber-400 hover:underline normal-case text-[11px] font-bold"
                    >
                      Clear All
                    </button>
                  </div>

                  <div className="py-1 divide-y divide-slate-100/60 dark:divide-slate-800/60">
                    {storeHistory.slice(0, 5).map((q, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between group hover:bg-slate-100/80 dark:hover:bg-slate-800/80 rounded-xl px-2 py-1.5 transition"
                      >
                        <button
                          type="button"
                          onClick={() => {
                            setSearchQuery(q);
                            addStoreQuery(q);
                            setShowStoreHistory(false);
                          }}
                          className="flex-1 flex items-center gap-2 text-left text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-amber-600 dark:hover:text-amber-400 truncate"
                        >
                          <Clock className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-500 transition-colors flex-shrink-0" />
                          <span className="truncate">{q}</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeStoreQuery(q);
                          }}
                          title="Remove search"
                          className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Filter Info */}
            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium self-end sm:self-auto">
              Showing <span className="font-bold text-slate-900 dark:text-slate-100">{filteredProducts.length}</span> items
            </div>
          </div>

          {/* Category Pills Bar */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setStoreCategory(cat.id)}
                className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition whitespace-nowrap flex items-center gap-1.5 active:scale-95 ${
                  storeCategory === cat.id
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md'
                    : 'bg-white dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60 hover:border-amber-400'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ORDERS VIEW TAB */}
      {activeTab === 'orders' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                Your Order History
              </h3>
              <p className="text-xs text-slate-500">
                Track shipments, download invoices, and inspect order milestones
              </p>
            </div>
            <button
              onClick={fetchOrders}
              className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold"
            >
              Refresh Orders
            </button>
          </div>

          {loadingOrders ? (
            <div className="p-12 text-center text-xs text-slate-400 font-medium">
              Loading orders...
            </div>
          ) : orders.length === 0 ? (
            <div className="clay-card p-12 text-center space-y-3 bg-white dark:bg-[#131722] rounded-3xl border border-slate-200/80 dark:border-slate-800">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center">
                <Clock className="w-8 h-8" />
              </div>
              <h4 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                No orders placed yet
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                Once you purchase engineering tools or digital BIM assets, your shipments and tracking codes will be cataloged here.
              </p>
              <button
                onClick={() => setActiveTab('all')}
                className="clay-btn clay-btn-primary px-5 py-2 text-xs font-bold mt-2"
              >
                Browse Store Products
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map(order => (
                <div
                  key={order.id}
                  className="clay-card p-5 bg-white dark:bg-[#131722] rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-4 shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-xs text-slate-900 dark:text-slate-100">
                          {order.id}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 font-bold text-[10px] uppercase">
                          {order.status}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Placed on {new Date(order.createdAt).toLocaleDateString()} • Payment: {order.paymentMethod.toUpperCase()}
                      </p>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-black text-emerald-600 dark:text-emerald-400 font-mono">
                        ${order.total.toFixed(2)} USD
                      </div>
                      <p className="text-[10px] text-slate-400 font-mono">
                        Tracking: {order.trackingNumber}
                      </p>
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="space-y-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.thumbnailUrl}
                            alt={item.title}
                            className="w-10 h-10 rounded-lg object-cover bg-slate-800"
                          />
                          <div>
                            <p className="font-bold text-slate-800 dark:text-slate-200 line-clamp-1">
                              {item.title}
                            </p>
                            <span className="text-[10px] text-slate-400">Qty: {item.quantity}</span>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                          ${(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                    <span>Delivering to: <strong className="text-slate-800 dark:text-slate-200">{order.shippingAddress.city}, {order.shippingAddress.country}</strong></span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5" />
                      GCC Express Carrier
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* PRODUCT GRID VIEW */
        <div className="space-y-6">
          {/* DEDICATED MY WISHLIST SECTION HEADER BANNER */}
          {activeTab === 'wishlist' && (
            <div className="clay-card p-5 sm:p-6 bg-gradient-to-r from-rose-500/10 via-pink-500/5 to-amber-500/10 border-2 border-rose-400/40 dark:border-rose-800/60 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm animate-in fade-in">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 to-pink-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30 flex-shrink-0">
                  <Heart className="w-6 h-6 fill-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                      My Saved Wishlist
                    </h2>
                    <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black">
                      {wishlistCount} {wishlistCount === 1 ? 'Product Saved' : 'Products Saved'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Your personal collection of saved items. Click the heart icon anytime to add or remove products.
                  </p>
                </div>
              </div>

              {wishlistCount > 0 && (
                <div className="flex items-center gap-2.5 self-end sm:self-auto flex-wrap">
                  <button
                    onClick={() => {
                      const saved = products.filter(p => isInWishlist(p.id));
                      saved.forEach(item => addToCart(item, 1));
                      setCartModalOpen(true);
                      showToast(`Added all ${saved.length} wishlist items to your shopping cart!`, 'success');
                    }}
                    className="clay-btn bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white px-4 py-2.5 rounded-2xl text-xs font-black shadow-md shadow-rose-500/25 flex items-center gap-2 active:scale-95 transition"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Move All to Cart</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map(n => (
                <div key={n} className="clay-card rounded-3xl h-80 bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="clay-card p-12 text-center space-y-4 bg-white dark:bg-[#131722] rounded-3xl border border-slate-200/80 dark:border-slate-800">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center">
                {activeTab === 'wishlist' ? <Heart className="w-8 h-8 text-rose-400" /> : <ShoppingBag className="w-8 h-8" />}
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                {activeTab === 'wishlist'
                  ? 'Your wishlist is empty'
                  : activeTab === 'my_listings'
                  ? 'You haven\'t listed any products yet'
                  : 'No products match your search'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                {activeTab === 'wishlist'
                  ? 'Click the heart icon on any camera, gadget, smartwatch, fashion item, tool, or engineering hardware to save it to your wishlist.'
                  : activeTab === 'my_listings'
                  ? 'Offer products, electronics, or digital templates to thousands of verified professionals.'
                  : 'Try adjusting your search keywords or switching category filters.'}
              </p>

              {activeTab === 'wishlist' ? (
                <button
                  onClick={() => {
                    setActiveTab('all');
                    setStoreCategory('all');
                  }}
                  className="clay-btn bg-rose-500 hover:bg-rose-600 text-white px-6 py-2.5 rounded-2xl text-xs font-black shadow-lg shadow-rose-500/25 inline-flex items-center gap-2 active:scale-95 transition"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Discover Products to Save</span>
                </button>
              ) : activeTab === 'my_listings' ? (
                <button
                  onClick={() => setCreateListingOpen(true)}
                  className="clay-btn clay-btn-primary px-5 py-2.5 text-xs font-black inline-flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>List Your First Product</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setActiveTab('all');
                    setStoreCategory('all');
                    setSearchQuery('');
                  }}
                  className="clay-btn clay-btn-secondary px-5 py-2 text-xs font-bold"
                >
                  Reset All Filters
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredProducts.map(product => {
                const inWishlist = isInWishlist(product.id);
                const hasDiscount = product.compareAtPrice && product.compareAtPrice > product.price;
                const discountPct = hasDiscount
                  ? Math.round(((product.compareAtPrice! - product.price) / product.compareAtPrice!) * 100)
                  : 0;

                return (
                  <div
                    key={product.id}
                    onClick={() => {
                      setSelectedProduct(product);
                      setModalQuantity(1);
                    }}
                    className="clay-card rounded-3xl overflow-hidden bg-white dark:bg-[#181D2E] border border-slate-200/80 dark:border-slate-800 shadow-md hover:shadow-xl hover:border-amber-400/50 transition-all duration-200 cursor-pointer group flex flex-col justify-between"
                  >
                    <div>
                      {/* Thumbnail Container */}
                      <div className="relative aspect-video bg-slate-900 overflow-hidden">
                        <img
                          src={product.thumbnailUrl}
                          alt={product.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />

                        {/* Badges Overlay */}
                        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 flex-wrap">
                          <span className={`px-2 py-0.5 rounded-full text-white font-black text-[9px] uppercase tracking-wider shadow-sm ${
                            product.condition === 'digital' ? 'bg-indigo-600' : 'bg-amber-500'
                          }`}>
                            {product.condition === 'new'
                              ? 'Brand New'
                              : product.condition === 'engineering_spec'
                              ? 'Engineering Spec'
                              : product.condition === 'digital'
                              ? 'Digital Asset'
                              : product.condition}
                          </span>
                          {hasDiscount && (
                            <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-black text-[9px] shadow-sm">
                              -{discountPct}%
                            </span>
                          )}
                        </div>

                        {/* Wishlist Heart Button on top right of thumbnail */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleWishlist(product.id);
                          }}
                          title={inWishlist ? 'Remove from My Wishlist' : 'Add to My Wishlist'}
                          className={`absolute top-2.5 right-2.5 p-2 rounded-2xl backdrop-blur-md transition-all duration-200 active:scale-90 flex items-center justify-center z-10 shadow-md ${
                            inWishlist
                              ? 'bg-rose-500 text-white shadow-rose-500/50 scale-105 ring-2 ring-white/60'
                              : 'bg-black/40 text-white/90 hover:text-white hover:bg-rose-600/90 hover:scale-105'
                          }`}
                        >
                          <Heart className={`w-4 h-4 transition-all duration-200 ${inWishlist ? 'fill-white stroke-white scale-110' : 'hover:scale-110'}`} />
                        </button>

                        {/* Seller Listing Delete button if owned */}
                        {currentUser && (product.sellerId === currentUser.id || currentUser.role === 'admin') && activeTab === 'my_listings' && (
                          <button
                            type="button"
                            onClick={(e) => handleDeleteListing(product.id, e)}
                            title="Delete this listing"
                            className="absolute bottom-2.5 right-2.5 p-1.5 rounded-xl bg-black/60 text-white hover:text-rose-400 hover:bg-rose-950/80 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Card Body */}
                      <div className="p-4 space-y-2">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-extrabold uppercase tracking-wider text-amber-600 dark:text-amber-400 truncate max-w-[150px]">
                            {product.brand}
                          </span>
                          <div className="flex items-center gap-1 text-amber-500 font-bold">
                            <Star className="w-3 h-3 fill-current" />
                            <span>{product.rating.toFixed(1)}</span>
                            <span className="text-slate-400">({product.reviewsCount})</span>
                          </div>
                        </div>

                        <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                          {product.title}
                        </h3>

                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                          {product.description}
                        </p>
                      </div>
                    </div>

                    {/* Card Footer: Pricing & Add to Cart */}
                    <div className="p-4 pt-0 space-y-3">
                      <div className="flex items-baseline justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                        <div>
                          <div className="flex items-baseline gap-1.5">
                            <span className="text-base font-black text-slate-900 dark:text-slate-100 font-mono">
                              ${product.price.toFixed(2)}
                            </span>
                            {hasDiscount && (
                              <span className="text-[11px] text-slate-400 line-through font-mono">
                                ${product.compareAtPrice!.toFixed(2)}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400">
                            ≈ {(product.price * 3.75).toFixed(0)} SAR
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Inline Wishlist Heart Icon */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleWishlist(product.id);
                            }}
                            className={`p-2 rounded-xl transition-all duration-200 active:scale-90 flex items-center justify-center ${
                              inWishlist
                                ? 'bg-rose-50 text-rose-600 border border-rose-300 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800 shadow-sm'
                                : 'text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-slate-200/80 dark:border-slate-800'
                            }`}
                            title={inWishlist ? 'Remove from My Wishlist' : 'Add to My Wishlist'}
                          >
                            <Heart className={`w-4 h-4 transition-colors ${inWishlist ? 'fill-rose-500 text-rose-500' : ''}`} />
                          </button>

                          {/* Add to Cart button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              addToCart(product, 1);
                            }}
                            className="clay-btn bg-amber-500 hover:bg-amber-600 text-white px-3 py-2 rounded-xl shadow-md shadow-amber-500/20 active:scale-95 transition flex items-center gap-1.5 text-xs font-black"
                            title="Add to shopping bag"
                          >
                            <ShoppingBag className="w-4 h-4" />
                            <span className="hidden sm:inline">Add</span>
                          </button>
                        </div>
                      </div>

                      {/* Seller Tag */}
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                        <span className="truncate">by {product.sellerName}</span>
                        {product.shippingInfo.freeShipping && (
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-0.5">
                            <Truck className="w-3 h-3" />
                            Free Express
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* PRODUCT DETAIL MODAL */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="clay-card bg-white dark:bg-[#131722] max-w-3xl w-full max-h-[92vh] overflow-y-auto no-scrollbar rounded-3xl p-5 sm:p-8 space-y-6 shadow-2xl border border-slate-200/80 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 font-extrabold text-[10px] uppercase">
                    {selectedProduct.categoryName}
                  </span>
                  <span className="text-xs text-slate-400 font-bold">• Brand: {selectedProduct.brand}</span>
                </div>
                <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100">
                  {selectedProduct.title}
                </h2>
              </div>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Image & Seller */}
              <div className="space-y-4">
                <div className="rounded-2xl overflow-hidden aspect-video sm:aspect-square bg-slate-900 shadow-md">
                  <img
                    src={selectedProduct.thumbnailUrl}
                    alt={selectedProduct.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Seller Box */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedProduct.sellerAvatar}
                      alt={selectedProduct.sellerName}
                      className="w-10 h-10 rounded-full object-cover bg-slate-800"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-slate-900 dark:text-slate-100">
                          {selectedProduct.sellerName}
                        </span>
                        {selectedProduct.sellerVerified && (
                          <ShieldCheck className="w-3.5 h-3.5 text-violet-500" />
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Ships from {selectedProduct.shippingInfo.shipsFrom}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Specs & Pricing Actions */}
              <div className="space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  {/* Price Tag */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/20 border border-amber-200 dark:border-amber-900/50">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-black text-slate-900 dark:text-slate-100 font-mono">
                        ${selectedProduct.price.toFixed(2)} USD
                      </span>
                      {selectedProduct.compareAtPrice && (
                        <span className="text-sm text-slate-400 line-through font-mono">
                          ${selectedProduct.compareAtPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-amber-700 dark:text-amber-400 font-bold mt-0.5">
                      Approx. {(selectedProduct.price * 3.75).toFixed(0)} Saudi Riyals (SAR)
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-emerald-500" />
                      <span>{selectedProduct.shippingInfo.estimatedDelivery}</span>
                    </p>
                  </div>

                  {/* Bullet Features */}
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                      Key Highlights
                    </h4>
                    {selectedProduct.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Tech Specs */}
                  {selectedProduct.specifications && Object.keys(selectedProduct.specifications).length > 0 && (
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                        Technical Specifications
                      </h4>
                      <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                        {Object.entries(selectedProduct.specifications).map(([k, v]) => (
                          <div key={k} className="flex justify-between p-2">
                            <span className="font-bold text-slate-500">{k}</span>
                            <span className="font-semibold text-slate-800 dark:text-slate-200">{v}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Actions */}
                <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    {/* Quantity Picker */}
                    <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-xl p-1.5">
                      <button
                        onClick={() => setModalQuantity(Math.max(1, modalQuantity - 1))}
                        className="w-7 h-7 flex items-center justify-center rounded-lg bg-white dark:bg-slate-700 font-bold"
                      >
                        -
                      </button>
                      <span className="w-8 text-center font-bold text-xs font-mono">
                        {modalQuantity}
                      </span>
                      <button
                        onClick={() => setModalQuantity(modalQuantity + 1)}
                        className="w-7 h-7 flex items-center justify-center rounded-lg bg-white dark:bg-slate-700 font-bold"
                      >
                        +
                      </button>
                    </div>

                    {/* Wishlist Button in Modal */}
                    <button
                      type="button"
                      onClick={() => toggleWishlist(selectedProduct.id)}
                      className={`p-3 rounded-2xl border transition active:scale-95 ${
                        isInWishlist(selectedProduct.id)
                          ? 'bg-rose-50 border-rose-500 text-rose-600 dark:bg-rose-950/40 dark:text-rose-300'
                          : 'border-slate-200 dark:border-slate-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                      title="Save to wishlist"
                    >
                      <Heart className={`w-5 h-5 ${isInWishlist(selectedProduct.id) ? 'fill-current' : ''}`} />
                    </button>

                    {/* Add to Cart */}
                    <button
                      type="button"
                      onClick={() => {
                        addToCart(selectedProduct, modalQuantity);
                        setSelectedProduct(null);
                      }}
                      className="flex-1 clay-btn clay-btn-secondary py-3 text-xs font-bold gap-2 flex items-center justify-center"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Bag</span>
                    </button>
                  </div>

                  {/* Instant Buy Now Button */}
                  <button
                    type="button"
                    onClick={() => {
                      addToCart(selectedProduct, modalQuantity);
                      setSelectedProduct(null);
                      setCartModalOpen(true);
                    }}
                    className="w-full clay-btn clay-btn-primary py-3 text-xs font-black bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2"
                  >
                    <span>Instant Checkout (${(selectedProduct.price * modalQuantity).toFixed(2)})</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Modals */}
      <CreateListingModal
        isOpen={createListingOpen}
        onClose={() => setCreateListingOpen(false)}
        onProductCreated={(newProd) => {
          setProducts(prev => [newProd, ...prev]);
        }}
      />

      <CartModal
        isOpen={cartModalOpen}
        onClose={() => setCartModalOpen(false)}
        onOrderPlaced={(newOrder) => {
          setOrders(prev => [newOrder, ...prev]);
        }}
      />
    </div>
  );
};
