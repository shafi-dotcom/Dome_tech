import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { User, Video, StoreProduct } from '../../types/index.ts';
import {
  CheckCircle,
  MapPin,
  Calendar,
  Users,
  Video as VideoIcon,
  Flame,
  Bookmark,
  Share2,
  Sparkles,
  Edit3,
  Repeat2,
  ShoppingBag,
  Heart,
  ExternalLink,
  Plus
} from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge.tsx';

export const ProfileView: React.FC = () => {
  const {
    currentUser,
    activeProfileUsername,
    setActiveVideo,
    setActiveView,
    showToast,
    setVerificationModalOpen,
    addToCart,
    openStore,
    isInWishlist,
    toggleWishlist,
    setIsCartOpen
  } = useApp();

  const [profile, setProfile] = useState<User | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [reposts, setReposts] = useState<{ repost: any; video: Video }[]>([]);
  const [creatorProducts, setCreatorProducts] = useState<StoreProduct[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState<'videos' | 'shorts' | 'store' | 'reposts' | 'about' | 'dashboard'>('videos');
  const [loading, setLoading] = useState(true);

  const usernameToFetch = activeProfileUsername || currentUser?.username || 'facade_academy';

  useEffect(() => {
    fetchProfile();
  }, [usernameToFetch]);

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/creators/${usernameToFetch}`);
      if (res.ok) {
        const data = await res.json();
        setProfile(data.creator);
        setIsFollowing(Boolean(data.isFollowing));
        setVideos(data.videos || []);

        // Fetch products listed by this creator
        try {
          const prodRes = await fetch(`/api/store/products?sellerId=${encodeURIComponent(data.creator.id)}`);
          if (prodRes.ok) {
            const prodData = await prodRes.json();
            setCreatorProducts(prodData.products || []);
          }
        } catch (pe) {
          console.warn('Error fetching creator store items', pe);
        }
      }

      const repRes = await fetch(`/api/creators/${usernameToFetch}/reposts`);
      if (repRes.ok) {
        const repData = await repRes.json();
        if (repData.reposts) setReposts(repData.reposts);
      }
    } catch (e) {
      console.warn('Error fetching profile', e);
    } finally {
      setLoading(false);
    }
  };

  const handleFollowToggle = async () => {
    if (!profile) return;
    try {
      const res = await fetch(`/api/creators/${profile.id}/follow`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setIsFollowing(data.isFollowing);
        setProfile({ ...profile, subscribersCount: data.subscribersCount });
        showToast(data.isFollowing ? 'Subscribed to creator channel!' : 'Unsubscribed');
      }
    } catch (e) {
      showToast('Error subscribing', 'error');
    }
  };

  if (loading || !profile) {
    return (
      <div className="clay-card p-12 text-center max-w-sm mx-auto">
        <p className="text-xs font-bold text-slate-500">Loading channel profile...</p>
      </div>
    );
  }

  const shorts = videos.filter(v => v.isShort);
  const standardVideos = videos.filter(v => !v.isShort);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      {/* Channel Banner */}
      <div className="relative h-44 md:h-64 rounded-3xl overflow-hidden bg-slate-900 shadow-md">
        <img
          src={profile.banner || 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&h=400&fit=crop'}
          alt="Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      </div>

      {/* Profile Header Details */}
      <div className="clay-card p-6 bg-white dark:bg-[#181D2E] relative -mt-16 sm:-mt-20 z-10 mx-2 sm:mx-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-5">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4 text-center sm:text-left">
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl object-cover border-4 border-white dark:border-[#181D2E] shadow-xl -mt-12 sm:-mt-16 bg-white"
            />
            <div className="space-y-1">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
                  {profile.name}
                </h1>
                {profile.verified && <VerifiedBadge size={20} />}
              </div>
              <p className="text-xs text-slate-400 font-semibold">@{profile.username}</p>
              <div className="flex items-center justify-center sm:justify-start gap-3 text-xs text-slate-500 dark:text-slate-400 pt-1">
                <span className="font-bold text-slate-900 dark:text-slate-100">
                  {profile.subscribersCount.toLocaleString()} <span className="font-normal text-slate-400">subscribers</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" />
                  {profile.country}
                </span>
                <span>•</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300 uppercase">
                  {profile.role}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2">
            {currentUser?.id === profile.id ? (
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveView('upload')}
                  className="clay-btn clay-btn-primary px-5 py-2.5 text-xs font-bold"
                >
                  Upload Video
                </button>
                {!profile.verified && (
                  <button
                    onClick={() => setVerificationModalOpen(true)}
                    className="clay-btn px-5 py-2.5 text-xs font-bold bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-2 border-slate-200 dark:border-slate-600 hover:border-violet-400"
                  >
                    Request Verification
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={handleFollowToggle}
                className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition active:scale-95 ${
                  isFollowing
                    ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    : 'clay-btn clay-btn-primary'
                }`}
              >
                {isFollowing ? 'Subscribed' : 'Subscribe to Channel'}
              </button>
            )}
            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href);
                showToast('Channel link copied!');
              }}
              className="p-2.5 rounded-2xl clay-btn-secondary"
              title="Share Channel"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bio */}
        <p className="text-xs text-slate-600 dark:text-slate-300 mt-4 leading-relaxed pt-3 border-t border-slate-100 dark:border-slate-800">
          {profile.bio || 'Architectural engineer and creator on VideoHub + Global Jobs.'}
        </p>
      </div>

      {/* Tabs (Videos, Shorts, About) */}
      <div className="border-b border-slate-200/80 dark:border-slate-800 flex gap-4 px-2">
        <button
          onClick={() => setActiveTab('videos')}
          className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'videos'
              ? 'border-violet-600 text-violet-600 dark:text-violet-400'
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <VideoIcon className="w-4 h-4" />
          Videos ({standardVideos.length})
        </button>

        <button
          onClick={() => setActiveTab('shorts')}
          className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'shorts'
              ? 'border-rose-500 text-rose-500'
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Flame className="w-4 h-4" />
          Shorts ({shorts.length})
        </button>

        <button
          onClick={() => setActiveTab('store')}
          className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'store'
              ? 'border-amber-500 text-amber-500'
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          Store & Merch ({creatorProducts.length})
        </button>

        <button
          onClick={() => setActiveTab('reposts')}
          className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'reposts'
              ? 'border-emerald-500 text-emerald-500'
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Repeat2 className="w-4 h-4" />
          Reposts ({reposts.length})
        </button>
        
        {currentUser?.id === profile.id && (
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
              activeTab === 'dashboard'
                ? 'border-orange-500 text-orange-500'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            Dashboard
          </button>
        )}

        <button
          onClick={() => setActiveTab('about')}
          className={`pb-3 text-xs font-extrabold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'about'
              ? 'border-emerald-500 text-emerald-500'
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Channel Details
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'videos' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {standardVideos.length === 0 ? (
            <p className="col-span-full text-center text-xs text-slate-400 py-8">
              No long-form videos published yet.
            </p>
          ) : (
            standardVideos.map((video) => (
              <div
                key={video.id}
                onClick={() => {
                  setActiveVideo(video);
                  setActiveView('watch');
                }}
                className="clay-card p-3 cursor-pointer group hover:border-violet-400 transition"
              >
                <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 mb-2.5">
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-black/80 text-white">
                    {video.duration}
                  </span>
                </div>
                <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-violet-600 transition-colors">
                  {video.title}
                </h4>
                <p className="text-[10px] text-slate-400 mt-1">
                  {video.views.toLocaleString()} views • {video.category}
                </p>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'shorts' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {shorts.length === 0 ? (
            <p className="col-span-full text-center text-xs text-slate-400 py-8">
              No shorts published by this creator yet.
            </p>
          ) : (
            shorts.map((short) => (
              <div
                key={short.id}
                onClick={() => setActiveView('shorts')}
                className="group relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:scale-[1.02] transition-transform"
              >
                <img
                  src={short.thumbnailUrl}
                  alt={short.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent p-3 flex flex-col justify-end text-white">
                  <h4 className="text-xs font-bold leading-tight line-clamp-2">
                    {short.title}
                  </h4>
                  <span className="text-[10px] text-slate-300 mt-1 font-semibold">
                    {short.views.toLocaleString()} views
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'reposts' && (
        <div className="space-y-4">
          {reposts.length === 0 ? (
            <div className="text-center py-12 clay-card bg-white/60 dark:bg-slate-900/40">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <Repeat2 className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">No reposted videos yet</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                Videos reposted by {profile.name} will appear here for channel visitors to discover.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {reposts.map(({ repost, video }) => (
                <div
                  key={repost.id}
                  onClick={() => {
                    setActiveVideo(video);
                    setActiveView('watch');
                  }}
                  className="clay-card p-3 cursor-pointer group hover:border-emerald-400 transition relative flex flex-col justify-between"
                >
                  <div>
                    {/* Repost Header Badge */}
                    <div className="flex items-center gap-1.5 mb-2.5 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                      <Repeat2 className="w-3.5 h-3.5 flex-shrink-0" />
                      <span className="truncate">Reposted by {profile.name}</span>
                      <span className="ml-auto text-[9px] text-emerald-600/70 font-normal">
                        {new Date(repost.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    {/* Optional Quote Commentary */}
                    {repost.quoteText && (
                      <div className="mb-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border-l-4 border-emerald-500 text-[11px] font-medium text-slate-800 dark:text-slate-200 italic line-clamp-3">
                        "{repost.quoteText}"
                      </div>
                    )}

                    <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 mb-2.5">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-black/80 text-white">
                        {video.duration}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-2 group-hover:text-emerald-600 transition-colors">
                      {video.title}
                    </h4>
                  </div>

                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <img
                      src={video.creator.avatar}
                      alt={video.creator.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <div className="min-w-0 flex-1 text-[10px] text-slate-400">
                      <p className="font-bold text-slate-700 dark:text-slate-300 truncate">
                        {video.creator.name}
                      </p>
                      <p>{video.views.toLocaleString()} views</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Store & Merch Tab Content */}
      {activeTab === 'store' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">
                Products & Merchandise by {profile.name}
              </h3>
              <p className="text-xs text-slate-400">
                Direct seller items with verified warranty, fast dispatch, and secure payments
              </p>
            </div>

            <button
              onClick={() => openStore()}
              className="clay-btn bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition"
            >
              <span>Marketplace</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {creatorProducts.length === 0 ? (
            <div className="clay-card p-12 text-center space-y-3 bg-white dark:bg-[#181D2E] rounded-3xl border border-slate-200/80 dark:border-slate-800">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-50 dark:bg-amber-950/50 text-amber-500 flex items-center justify-center">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                No Store Listings Yet
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {currentUser?.id === profile.id
                  ? 'You haven\'t listed any products or merchandise in your channel store yet.'
                  : `${profile.name} currently has no active store listings.`}
              </p>
              {currentUser?.id === profile.id ? (
                <button
                  onClick={() => openStore()}
                  className="clay-btn bg-amber-500 text-white px-4 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>List a Product</span>
                </button>
              ) : (
                <button
                  onClick={() => openStore()}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Browse Global Store
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {creatorProducts.map((prod) => {
                const inWish = isInWishlist(prod.id);
                return (
                  <div
                    key={prod.id}
                    className="clay-card rounded-3xl overflow-hidden bg-white dark:bg-[#181D2E] border border-slate-200/80 dark:border-slate-800 shadow-md hover:shadow-xl hover:border-amber-400/50 transition duration-200 flex flex-col justify-between group"
                  >
                    <div>
                      <div className="relative aspect-video bg-slate-900 overflow-hidden">
                        <img
                          src={prod.thumbnailUrl}
                          alt={prod.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleWishlist(prod.id);
                          }}
                          className="absolute top-2.5 right-2.5 p-2 rounded-xl bg-black/60 text-white hover:text-rose-400 backdrop-blur-sm transition active:scale-90"
                          title={inWish ? 'Remove from wishlist' : 'Save to wishlist'}
                        >
                          <Heart className={`w-4 h-4 ${inWish ? 'fill-rose-500 text-rose-500' : ''}`} />
                        </button>
                        <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-lg bg-black/70 text-white text-[10px] font-bold">
                          {prod.categoryName}
                        </span>
                      </div>

                      <div className="p-4 space-y-1.5">
                        <h4 className="text-xs font-black text-slate-900 dark:text-slate-100 line-clamp-2">
                          {prod.title}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                          {prod.description}
                        </p>
                      </div>
                    </div>

                    <div className="p-4 pt-0">
                      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <div className="flex items-baseline gap-1.5">
                            <span className="text-sm font-black text-amber-600 dark:text-amber-400">
                              ${prod.price.toFixed(2)}
                            </span>
                            {prod.compareAtPrice && (
                              <span className="text-[10px] text-slate-400 line-through">
                                ${prod.compareAtPrice.toFixed(2)}
                              </span>
                            )}
                          </div>
                          <span className="text-[9px] text-slate-400 block font-semibold">
                            ≈ SAR {(prod.price * 3.75).toFixed(0)}
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            addToCart(prod, 1);
                            setIsCartOpen(true);
                          }}
                          className="clay-btn bg-amber-500 hover:bg-amber-600 text-white px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add to Cart</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="clay-card p-6 bg-white dark:bg-[#181D2E]">
              <h4 className="text-xs font-bold text-slate-500 mb-2">Total Views</h4>
              <p className="text-3xl font-black text-violet-600">
                {videos.reduce((acc, v) => acc + v.views, 0).toLocaleString()}
              </p>
            </div>
            <div className="clay-card p-6 bg-white dark:bg-[#181D2E]">
              <h4 className="text-xs font-bold text-slate-500 mb-2">Watch Time (hrs)</h4>
              <p className="text-3xl font-black text-rose-500">45.2K</p>
            </div>
            <div className="clay-card p-6 bg-white dark:bg-[#181D2E]">
              <h4 className="text-xs font-bold text-slate-500 mb-2">Engagement Rate</h4>
              <p className="text-3xl font-black text-emerald-500">8.4%</p>
            </div>
          </div>

          {/* Milestones */}
          <div className="clay-card p-6 bg-white dark:bg-[#181D2E]">
            <h3 className="text-sm font-black text-slate-900 dark:text-slate-100 mb-4">Milestones</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { id: 'subs_50', title: '50 Subscribers', target: 50, current: profile.subscribersCount, icon: Users },
                { id: 'views_1000', title: '1,000 Total Views', target: 1000, current: videos.reduce((acc, v) => acc + v.views, 0), icon: VideoIcon },
                { id: 'subs_1000', title: '1,000 Subscribers', target: 1000, current: profile.subscribersCount, icon: Users },
                { id: 'views_10000', title: '10,000 Total Views', target: 10000, current: videos.reduce((acc, v) => acc + v.views, 0), icon: VideoIcon },
              ].map((milestone) => {
                const isAchieved = milestone.current >= milestone.target;
                const Icon = milestone.icon;
                return (
                  <div
                    key={milestone.id}
                    className={`p-4 rounded-3xl border-2 transition ${
                      isAchieved
                        ? 'bg-emerald-50 border-emerald-200 dark:bg-emerald-950 dark:border-emerald-800'
                        : 'bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center mb-3 ${
                      isAchieved ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-800 dark:text-emerald-300' : 'bg-slate-200 text-slate-500 dark:bg-slate-700 dark:text-slate-400'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <p className={`text-xs font-bold ${isAchieved ? 'text-emerald-900 dark:text-emerald-100' : 'text-slate-500'}`}>
                      {milestone.title}
                    </p>
                    <p className={`text-[10px] font-semibold mt-1 ${isAchieved ? 'text-emerald-600' : 'text-slate-400'}`}>
                      {isAchieved ? 'Achieved' : `${milestone.current} / ${milestone.target}`}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'about' && (
        <div className="clay-card p-6 bg-white dark:bg-[#181D2E] space-y-4 max-w-xl">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
            About {profile.name}
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {profile.bio}
          </p>
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
            <p>Joined platform: {new Date(profile.createdAt).toLocaleDateString()}</p>
            <p>Channel Tier: <span className="font-bold text-violet-600 uppercase">{profile.membershipPlan}</span></p>
            <p>Verification Status: {profile.verified ? 'Verified Creator Channel ✓' : 'Standard Account'}</p>
          </div>
        </div>
      )}
    </div>
  );
};
