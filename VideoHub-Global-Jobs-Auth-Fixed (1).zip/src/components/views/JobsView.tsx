import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Job, JobCategory, EmploymentType } from '../../types/index.ts';
import {
  Search,
  MapPin,
  Building2,
  DollarSign,
  Briefcase,
  Bookmark,
  Share2,
  CheckCircle,
  PlusCircle,
  Clock,
  Sparkles,
  Filter,
  ArrowRight,
  Globe,
  SlidersHorizontal,
  X
} from 'lucide-react';

const JOB_CATEGORIES: string[] = [
  'All',
  'Aluminium & Façade Engineering',
  'Curtain Wall & Glazing',
  'Architectural Engineering',
  'Civil Engineering',
  'AutoCAD Drafting',
  'Revit & BIM',
  'Surveying',
  'Manufacturing & Fabrication',
  'Construction Management',
  'Software & IT'
];

export const JobsView: React.FC = () => {
  const {
    currentUser,
    activeJob,
    setActiveJob,
    setApplyModalJob,
    setAuthModalOpen,
    showToast
  } = useApp();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCountry, setSelectedCountry] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [savedOnly, setSavedOnly] = useState(false);
  const [showPostModal, setShowPostModal] = useState(false);

  // New Job Form State
  const [newJob, setNewJob] = useState({
    title: '',
    company: currentUser?.name || 'Apex Façade Systems',
    companyLogo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120&h=120&fit=crop',
    location: 'Riyadh (KSA)',
    country: 'Saudi Arabia',
    category: 'Aluminium & Façade Engineering',
    employmentType: 'Full-time',
    experienceLevel: 'Mid-level',
    salaryMin: 70000,
    salaryMax: 95000,
    currency: 'USD',
    description: '',
    responsibilities: 'Produce 2D & 3D structural drawings for unitized curtain wall assemblies.',
    qualifications: '5+ years experience in architectural façade engineering and AutoCAD/Revit.',
    deadline: '2026-12-31'
  });

  useEffect(() => {
    fetchJobs();
  }, [selectedCategory, selectedCountry, selectedType, savedOnly]);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      if (savedOnly) {
        const res = await fetch('/api/jobs/saved');
        if (res.ok) {
          const data = await res.json();
          setJobs(data.savedJobs);
        }
      } else {
        const url = new URL('/api/jobs', window.location.origin);
        if (selectedCategory !== 'All') url.searchParams.set('category', selectedCategory);
        if (selectedCountry !== 'All') url.searchParams.set('country', selectedCountry);
        if (selectedType !== 'All') url.searchParams.set('type', selectedType);
        if (search) url.searchParams.set('search', search);

        const res = await fetch(url.toString());
        if (res.ok) {
          const data = await res.json();
          setJobs(data.jobs);
          if (data.jobs.length > 0 && !activeJob) {
            setActiveJob(data.jobs[0]);
          }
        }
      }
    } catch (e) {
      console.warn('Failed to fetch jobs', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchJobs();
  };

  const handleSaveToggle = async (e: React.MouseEvent, job: Job) => {
    e.stopPropagation();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/jobs/${job.id}/save`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setJobs(prev =>
          prev.map(j => (j.id === job.id ? { ...j, isSaved: data.isSaved } : j))
        );
        showToast(data.isSaved ? 'Job saved to your bookmarks!' : 'Job removed from bookmarks');
      }
    } catch (e) {
      showToast('Could not update saved job', 'error');
    }
  };

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newJob,
          responsibilities: [newJob.responsibilities],
          qualifications: [newJob.qualifications]
        })
      });

      if (!res.ok) throw new Error('Failed to post vacancy');
      const data = await res.json();
      setJobs(prev => [data.job, ...prev]);
      setActiveJob(data.job);
      setShowPostModal(false);
      showToast('Job vacancy successfully published worldwide!');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Portal Header & Search Form */}
      <div className="clay-card p-6 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border border-emerald-300/40 dark:border-emerald-700/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
          <div>
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs uppercase tracking-wider">
              <Globe className="w-4 h-4" />
              Global Engineering & Construction Jobs
            </div>
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-1">
              Find Your Next International Opportunity
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
              Specialized careers in Aluminium Extrusions, Unitized Curtain Walls, Structural Glazing, Revit BIM, and Megaproject Engineering.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              onClick={() => {
                setSavedOnly(!savedOnly);
              }}
              className={`clay-btn px-4 py-2 text-xs font-bold gap-1.5 transition ${
                savedOnly ? 'bg-indigo-600 text-white' : 'clay-btn-secondary'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${savedOnly ? 'fill-white' : ''}`} />
              {savedOnly ? 'Showing Saved Jobs' : 'My Saved Jobs'}
            </button>

            <button
              onClick={() => setShowPostModal(true)}
              className="clay-btn clay-btn-mint px-4 py-2 text-xs font-bold gap-1.5 shadow-sm"
            >
              <PlusCircle className="w-4 h-4" />
              Post a Vacancy
            </button>
          </div>
        </div>

        {/* Multi-field search box */}
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Job title, skills (e.g. Façade, Revit, Curtain Wall, Estimator)..."
              className="w-full pl-10 pr-3 py-2.5 text-xs clay-input"
            />
          </div>

          <div>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full px-3 py-2.5 text-xs clay-input bg-white dark:bg-slate-800"
            >
              <option value="All">All Locations & Countries</option>
              <option value="Saudi Arabia">Saudi Arabia (Riyadh/Jeddah)</option>
              <option value="United Arab Emirates">United Arab Emirates (Dubai)</option>
              <option value="United Kingdom">United Kingdom (London)</option>
              <option value="Singapore">Singapore</option>
              <option value="Germany">Germany (Frankfurt/Berlin)</option>
              <option value="Canada">Canada (Toronto)</option>
              <option value="Australia">Australia (Melbourne)</option>
              <option value="Remote">Remote (Worldwide)</option>
            </select>
          </div>

          <button
            type="submit"
            className="clay-btn clay-btn-primary py-2.5 text-xs font-bold shadow-md"
          >
            Search Vacancies
          </button>
        </form>

        {/* Specialized Category Chips */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-4">
          {JOB_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:border-emerald-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 2-Column Split: Job Listings on Left, Detailed Job View on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Job Cards List (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
              {jobs.length} Openings Found
            </span>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Sort: Most Recent</span>
            </div>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map(n => (
                <div key={n} className="clay-card p-4 animate-pulse space-y-2">
                  <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-2/3" />
                  <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <div className="clay-card p-8 text-center">
              <p className="text-xs font-bold text-slate-500">No job openings found matching these criteria.</p>
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setSelectedCountry('All');
                  setSearch('');
                  setSavedOnly(false);
                }}
                className="mt-3 clay-btn clay-btn-primary px-3 py-1.5 text-xs font-bold"
              >
                Reset Search Filters
              </button>
            </div>
          ) : (
            jobs.map((job) => {
              const isSelected = activeJob?.id === job.id;
              return (
                <div
                  key={job.id}
                  onClick={() => setActiveJob(job)}
                  className={`clay-card p-4 cursor-pointer transition-all ${
                    isSelected
                      ? 'border-2 border-emerald-500 shadow-md ring-2 ring-emerald-500/20 bg-emerald-50/20 dark:bg-emerald-950/20'
                      : 'hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <img
                      src={job.companyLogo}
                      alt={job.company}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shadow-sm flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 line-clamp-1">
                          {job.title}
                        </h3>
                        {job.featured && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300">
                            PRO
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {job.company}
                      </p>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5 truncate">
                        <MapPin className="w-3 h-3 text-rose-500 flex-shrink-0" />
                        {job.location}
                      </p>
                    </div>

                    <button
                      onClick={(e) => handleSaveToggle(e, job)}
                      className={`p-1.5 rounded-xl transition ${
                        job.isSaved
                          ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/40'
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${job.isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  <div className="mt-3 flex items-center justify-between pt-2.5 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                      {job.currency} {job.salaryMin.toLocaleString()} - {job.salaryMax.toLocaleString()}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {job.employmentType}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Active Job Detail Sheet (7 cols) */}
        <div className="lg:col-span-7">
          {activeJob ? (
            <div className="clay-card p-6 bg-white dark:bg-[#181D2E] space-y-6 sticky top-20 border border-slate-200/80 dark:border-slate-800">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3.5">
                  <img
                    src={activeJob.companyLogo}
                    alt={activeJob.company}
                    className="w-14 h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-md"
                  />
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
                      {activeJob.title}
                    </h2>
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{activeJob.company}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-400">
                        <MapPin className="w-3 h-3 text-rose-500" />
                        {activeJob.location}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setApplyModalJob(activeJob)}
                    className="clay-btn clay-btn-mint px-5 py-2.5 text-xs font-bold shadow-md active:scale-95 transition"
                  >
                    Easy Apply Now
                  </button>
                  <button
                    onClick={(e) => handleSaveToggle(e, activeJob)}
                    className="p-2.5 rounded-2xl clay-btn-secondary"
                  >
                    <Bookmark className={`w-4 h-4 ${activeJob.isSaved ? 'text-amber-500 fill-amber-500' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Key Specs Pills */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/40 dark:border-emerald-800/40">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Salary</span>
                  <p className="font-extrabold text-emerald-700 dark:text-emerald-300 mt-0.5">
                    {activeJob.currency} {activeJob.salaryMin.toLocaleString()} - {activeJob.salaryMax.toLocaleString()}
                  </p>
                </div>
                <div className="p-3 rounded-2xl bg-violet-50 dark:bg-violet-950/30 border border-violet-200/40 dark:border-violet-800/40">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Job Type</span>
                  <p className="font-extrabold text-violet-700 dark:text-violet-300 mt-0.5">
                    {activeJob.employmentType}
                  </p>
                </div>
                <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200/40 dark:border-blue-800/40">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Experience</span>
                  <p className="font-extrabold text-blue-700 dark:text-blue-300 mt-0.5">
                    {activeJob.experienceLevel}
                  </p>
                </div>
                <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/40 dark:border-amber-800/40">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Applicants</span>
                  <p className="font-extrabold text-amber-700 dark:text-amber-300 mt-0.5">
                    {activeJob.applicantsCount} Candidates
                  </p>
                </div>
              </div>

              {/* Job Description */}
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
                  Role Overview
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                  {activeJob.description}
                </p>
              </div>

              {/* Responsibilities */}
              {activeJob.responsibilities?.length > 0 && (
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
                    Key Responsibilities
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                    {activeJob.responsibilities.map((r, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Qualifications */}
              {activeJob.qualifications?.length > 0 && (
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
                    Candidate Qualifications
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                    {activeJob.qualifications.map((q, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-violet-500 flex-shrink-0 mt-0.5" />
                        <span>{q}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Footer CTA */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Deadline: {new Date(activeJob.deadline).toLocaleDateString()}
                </span>
                <button
                  onClick={() => setApplyModalJob(activeJob)}
                  className="clay-btn clay-btn-mint px-6 py-2.5 text-xs font-bold"
                >
                  Apply For This Position
                </button>
              </div>
            </div>
          ) : (
            <div className="clay-card p-12 text-center text-slate-400 text-xs">
              Select a vacancy from the left panel to review comprehensive specifications.
            </div>
          )}
        </div>
      </div>

      {/* Post a Vacancy Modal */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg clay-card p-6 bg-white dark:bg-[#181D2E] text-slate-800 dark:text-slate-100 shadow-2xl max-h-[90vh] overflow-y-auto no-scrollbar">
            <button
              onClick={() => setShowPostModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-4 text-emerald-600">
              <Briefcase className="w-6 h-6" />
              <h3 className="text-base font-extrabold tracking-tight">Post a New Vacancy</h3>
            </div>

            <form onSubmit={handleCreateJob} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold mb-1">Job Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Senior Façade Technical Engineer"
                  value={newJob.title}
                  onChange={(e) => setNewJob({ ...newJob, title: e.target.value })}
                  className="w-full px-3 py-2 text-xs clay-input"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">Company Name</label>
                  <input
                    type="text"
                    required
                    value={newJob.company}
                    onChange={(e) => setNewJob({ ...newJob, company: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">Location / Country</label>
                  <input
                    type="text"
                    required
                    value={newJob.location}
                    onChange={(e) => setNewJob({ ...newJob, location: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">Category</label>
                  <select
                    value={newJob.category}
                    onChange={(e) => setNewJob({ ...newJob, category: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
                  >
                    {JOB_CATEGORIES.filter(c => c !== 'All').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">Employment Type</label>
                  <select
                    value={newJob.employmentType}
                    onChange={(e) => setNewJob({ ...newJob, employmentType: e.target.value })}
                    className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold mb-1">Min Salary (USD/yr)</label>
                  <input
                    type="number"
                    value={newJob.salaryMin}
                    onChange={(e) => setNewJob({ ...newJob, salaryMin: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">Max Salary (USD/yr)</label>
                  <input
                    type="number"
                    value={newJob.salaryMax}
                    onChange={(e) => setNewJob({ ...newJob, salaryMax: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">Job Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Detail project scope, tower specs, curtain wall systems..."
                  value={newJob.description}
                  onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs clay-input"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="clay-btn clay-btn-mint px-5 py-2 text-xs font-bold"
                >
                  Publish Vacancy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
