import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  ShieldCheck,
  FileText,
  Video,
  Flame,
  Film,
  Briefcase,
  AlertTriangle,
  Flag,
  Trash2,
  Info,
  CheckCircle2,
  ExternalLink,
  Search,
  Copy,
  ChevronDown,
  ChevronUp,
  Download,
  Building2,
  Lock,
  ArrowRight,
  DollarSign,
  Coins,
  Clock,
  Sparkles
} from 'lucide-react';

export const PoliciesView: React.FC = () => {
  const { setActiveView, showToast, currentUser, setAuthModalOpen } = useApp();
  const [activeTab, setActiveTab] = useState<'rules' | 'monetization'>('rules');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSection, setExpandedSection] = useState<string | null>('all');
  const [deletionModalOpen, setDeletionModalOpen] = useState(false);
  const [deletionReason, setDeletionReason] = useState('');
  const [deletionSubmitting, setDeletionSubmitting] = useState(false);
  const [deletionSubmitted, setDeletionSubmitted] = useState(false);

  interface PolicySection {
    id: string;
    letter: string;
    title: string;
    subtitle: string;
    icon: any;
    color: string;
    content: string[];
    action?: {
      label: string;
      onClick: () => void;
    };
  }

  const sections: PolicySection[] = [
    {
      id: 'section-a',
      letter: 'A',
      title: 'Video Upload Agreement',
      subtitle: 'Ownership, copyright permissions & platform licence',
      icon: Video,
      color: 'violet',
      content: [
        'By uploading a video, the user confirms that:',
        '• They own the video or have permission to publish it.',
        '• They have permission to use included music, photographs and other copyrighted materials.',
        '• The video does not violate another person\'s privacy or intellectual property rights.',
        '• The video does not contain unlawful, fraudulent or prohibited material.',
        '• They grant Aluminium Hub the limited platform licence described in the main Terms and Conditions.',
        'Users remain responsible for the legality of their uploaded content.'
      ]
    },
    {
      id: 'section-b',
      letter: 'B',
      title: 'Short Video Rules',
      subtitle: 'Standards for vertical reels, shorts & quick clips',
      icon: Flame,
      color: 'rose',
      content: [
        'Short videos must comply with the same copyright, privacy and content standards as long videos.',
        'Users must not upload:',
        '• Copyrighted movies or television clips without permission.',
        '• Music without appropriate rights.',
        '• Violent or unlawful material.',
        '• Fake company promotions.',
        '• Misleading job advertisements.',
        '• Content containing malware or fraudulent links.',
        'Aluminium Hub may remove or restrict videos that violate these rules.'
      ]
    },
    {
      id: 'section-c',
      letter: 'C',
      title: 'Long Video Rules',
      subtitle: 'Permitted topics & educational engineering showcases',
      icon: Film,
      color: 'blue',
      content: [
        'Long videos may include:',
        '• Aluminium fabrication tutorials.',
        '• Curtain wall installation demonstrations.',
        '• Architectural and engineering presentations.',
        '• Factory tours.',
        '• Company introductions.',
        '• Construction project presentations.',
        '• Educational and professional training.',
        'Users must have permission to publish all included material.'
      ]
    },
    {
      id: 'section-d',
      letter: 'D',
      title: 'World Jobs Rules',
      subtitle: 'Employer responsibilities & applicant safety safeguards',
      icon: Briefcase,
      color: 'emerald',
      content: [
        'Aluminium Hub provides job advertising and professional networking facilities.',
        'Employers are responsible for the accuracy and legality of their vacancies.',
        'Job seekers should:',
        '• Verify employers independently.',
        '• Avoid paying suspicious recruitment fees.',
        '• Protect their identity documents.',
        '• Avoid sharing bank passwords or confidential information.',
        '• Report suspicious recruitment requests.',
        'Aluminium Hub does not guarantee employment or act as an employer.',
        'Unless separately authorised and licensed, Aluminium Hub does not provide recruitment or employment-placement services.'
      ]
    },
    {
      id: 'section-e',
      letter: 'E',
      title: 'Sponsored Video and Paid Promotion',
      subtitle: 'Clear identification & advertising honesty',
      icon: Building2,
      color: 'amber',
      content: [
        'Companies may purchase promotional services, including:',
        '• Featured videos.',
        '• Sponsored company profiles.',
        '• Promoted job listings.',
        '• Featured advertisements.',
        'Sponsored content must be clearly identified as sponsored or paid promotion.',
        'Advertisers must ensure that their promotional claims are truthful and legally permitted.'
      ]
    },
    {
      id: 'section-f',
      letter: 'F',
      title: 'Content Reporting',
      subtitle: 'Community reporting mechanisms & moderation inspection',
      icon: Flag,
      color: 'red',
      content: [
        'Every public video and job listing should have a reporting facility.',
        'Reports may concern:',
        '• Copyright infringement.',
        '• Fake jobs.',
        '• Fraud.',
        '• Harassment.',
        '• Illegal material.',
        '• Privacy violations.',
        '• Misleading commercial content.',
        'Aluminium Hub may investigate reports and restrict or remove content in accordance with applicable laws and its policies.'
      ]
    },
    {
      id: 'section-g',
      letter: 'G',
      title: 'Account and Data Deletion',
      subtitle: 'User privacy rights & retention compliance',
      icon: Trash2,
      color: 'slate',
      content: [
        'Users may request deletion of their accounts and personal information.',
        'Deletion will be handled subject to applicable legal retention requirements, legitimate security needs and necessary backup procedures.'
      ],
      action: {
        label: 'Request Account & Data Deletion',
        onClick: () => setDeletionModalOpen(true)
      }
    },
    {
      id: 'section-h',
      letter: 'H',
      title: 'No Endorsement',
      subtitle: 'Independent verification & publisher liability notice',
      icon: Info,
      color: 'cyan',
      content: [
        'The presence of a video, job listing, employer profile or company advertisement does not mean Aluminium Hub endorses or independently verifies the person or organisation publishing it.'
      ]
    }
  ];

  const monetizationSections: PolicySection[] = [
    {
      id: 'mon-1',
      letter: '1',
      title: 'Partner Program Eligibility & Channel Review',
      subtitle: 'Minimum qualifying metrics & compliance prerequisites',
      icon: ShieldCheck,
      color: 'emerald',
      content: [
        'To enrol and maintain active monetization in the World Video Hub Partner Program, creators must satisfy all statutory criteria:',
        '• Channel Subscribers: Maintain a minimum of 1,000 valid, organic subscribers.',
        '• Public Watch Hours: Accumulate at least 4,000 valid public watch hours within the preceding 12 months, OR 10 million valid public Shorts views within the preceding 90 days.',
        '• Identity & Security: Successfully activate 2-Step Verification and pass channel authenticity verification.',
        '• Legal Policy Compliance: Maintain zero active copyright strikes or violations under the Supplementary Platform Rules (Sections A through H).',
        '• Supported Territories: Maintain an active banking facility or verified digital account (IBAN/SWIFT) in a supported jurisdiction.',
        '• Editorial Review: Every channel undergoes human and automated compliance review before monetization privileges are enabled.'
      ]
    },
    {
      id: 'mon-2',
      letter: '2',
      title: 'Revenue Sharing Models & Payout Rates',
      subtitle: 'Transparent creator percentage shares across all revenue streams',
      icon: DollarSign,
      color: 'emerald',
      content: [
        'World Video Hub operates a transparent revenue sharing model across all monetization channels:',
        '• Watch Page Advertising (Long-form): Creators receive 55% of Net Advertising Revenue recognized by the platform for ads served on or accompanying their standard tutorials and presentations.',
        '• Shorts Feed Advertising: Creators receive a 45% pro-rata share of allocated Net Advertising Revenue based on their proportion of overall views within the Shorts Creator Pool.',
        '• Channel Memberships & Paid Subscriptions: Creators receive 70% of gross recurring membership dues paid by subscribers, net of transaction fees and applicable taxes.',
        '• Super Thanks & Viewer Tips: Creators receive 70% of gross viewer tips sent on video tutorials and demonstrations.',
        '• Live Match Subscriber Gifts: Virtual gift coins (Roses, Wrench, Rockets, Victory Cups, Galaxy, Crown) awarded during live subscriber battles are convertible to cash at $0.05 per coin.',
        '• Sponsored Videos & Brand Integrations: Creators retain 100% of directly negotiated brand partnerships, subject to mandatory commercial disclosure under Section E.'
      ]
    },
    {
      id: 'mon-3',
      letter: '3',
      title: 'Payment Thresholds & Monthly Disbursal Schedule',
      subtitle: 'Minimum cashout balance & scheduled transfer calendar',
      icon: Clock,
      color: 'violet',
      content: [
        'Earnings calculation and disbursals adhere to the following calendar:',
        '• Minimum Payout Threshold: $50.00 USD (or equivalent in local currencies, e.g., 200 SAR). Accrued balances below the threshold roll over to the subsequent billing cycle.',
        '• Payment Cycle: Earnings are tallied on the last day of each calendar month and processed between the 21st and 26th of the subsequent month.',
        '• Payout Methods: Direct Bank Wire Transfer (IBAN/SWIFT), PayPal Business, and Stripe Connect.',
        '• Payment Processing Fees: Third-party banking wire fees or foreign exchange conversion margins charged by receiving financial institutions are the responsibility of the recipient creator.'
      ]
    },
    {
      id: 'mon-4',
      letter: '4',
      title: 'Tax Obligations, ZATCA & Regulatory Invoicing',
      subtitle: 'Creator tax compliance, withholding & statutory documentation',
      icon: Building2,
      color: 'amber',
      content: [
        'Creators operate as independent commercial contractors and must comply with applicable taxation:',
        '• Saudi Arabia & GCC: Creators registered for VAT or commercial activities must provide their Zakat, Tax and Customs Authority (ZATCA) registration number where required.',
        '• International Creators: Creators must complete electronic tax self-certifications (e.g., Form W-8BEN / W-9) to determine applicable withholding rates.',
        '• Independent Contractor Status: Participation in the Partner Program does not establish an employment, joint venture, agency, or partnership relationship with Aluminium Hub (reinforcing Section D and H).'
      ]
    },
    {
      id: 'mon-5',
      letter: '5',
      title: 'Prohibited Practices, Invalid Traffic & Click Fraud',
      subtitle: 'Zero tolerance for artificial traffic, bots & deceptive inflation',
      icon: AlertTriangle,
      color: 'rose',
      content: [
        'Creators must strictly refrain from any artificial revenue inflation activities, including:',
        '• Generating artificial impressions, clicks, or watch duration using automated bots, click farms, scripts, or view exchanges.',
        '• Incentivizing third parties or viewers to click on advertisements or repeat playback loops artificially.',
        '• Uploading repetitive, plagiarized, scraped CAD/BIM blueprints, or content infringing third-party intellectual property rights.',
        '• Penalties: Detection of invalid traffic will result in immediate deduction of affected revenues, temporary or permanent demonetization, or platform account suspension.'
      ]
    },
    {
      id: 'mon-6',
      letter: '6',
      title: 'Sponsored Content & Commercial Disclosure Rules',
      subtitle: 'Mandatory transparency guidelines aligning with Section E',
      icon: Sparkles,
      color: 'cyan',
      content: [
        'All monetized videos containing paid product placement, commercial endorsements, or brand sponsorships must:',
        '• Enable the "Paid Promotion / Sponsored" badge during upload or video editing.',
        '• Ensure all claims regarding engineering materials, aluminium extrusion tolerances, software, or machinery are truthful, accurate, and substantiated.',
        '• Comply with advertising laws of the jurisdiction where the content is published and viewed.'
      ]
    },
    {
      id: 'mon-7',
      letter: '7',
      title: 'Suspension, Termination & Opt-Out Rights',
      subtitle: 'Voluntary departure, breach consequences & balance resolution',
      icon: Lock,
      color: 'slate',
      content: [
        'Either party may terminate monetization under the following provisions:',
        '• Creator Opt-Out: Creators may disable monetization globally or on specific videos at any time through the Creator Studio Monetization Dashboard.',
        '• Platform Termination for Inactivity or Breach: Aluminium Hub reserves the right to disable monetization on channels inactive for more than 6 months or in breach of platform policies.',
        '• Final Balance Settlement: Upon voluntary termination in good standing, eligible balances meeting the minimum threshold will be disbursed in the next regular cycle.'
      ]
    },
    {
      id: 'mon-8',
      letter: '8',
      title: 'Disclaimer of Earnings & Platform Discretion',
      subtitle: 'No revenue guarantee & platform operational sovereignty',
      icon: Info,
      color: 'blue',
      content: [
        '• No Guarantee of Income: Aluminium Hub does not guarantee any specific volume of advertisements, impressions, views, or revenue level.',
        '• Advertising Discretion: The platform reserves the right to determine ad placement, formats, bidding auctions, and advertiser suitability.',
        '• Policy Amendments: Aluminium Hub may update these Monetization Terms with prior electronic notice. Continued participation after notification constitutes acceptance of the amended terms.'
      ]
    }
  ];

  const currentDisplaySections = activeTab === 'rules' ? sections : monetizationSections;

  const filteredSections = currentDisplaySections.filter(sec => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      sec.title.toLowerCase().includes(q) ||
      sec.subtitle.toLowerCase().includes(q) ||
      sec.content.some(line => line.toLowerCase().includes(q))
    );
  });

  const handleCopyAll = () => {
    let fullText = '';
    if (activeTab === 'rules') {
      fullText = `WORLD VIDEO HUB — SUPPLEMENTARY PLATFORM RULES\nThese provisions supplement the seven Aluminium Hub legal policies.\n\n` +
        sections.map(s => `${s.letter}. ${s.title}\n` + s.content.join('\n')).join('\n\n');
      showToast('Supplementary Platform Rules (A-H) copied to clipboard!');
    } else {
      fullText = `WORLD VIDEO HUB — CREATOR MONETIZATION TERMS AND CONDITIONS\n` +
        `These provisions govern creator earnings, advertising revenue share, channel memberships, live gifts, and payouts.\n\n` +
        monetizationSections.map(s => `Section ${s.letter}: ${s.title}\n` + s.content.join('\n')).join('\n\n');
      showToast('Creator Monetization Terms copied to clipboard!');
    }
    navigator.clipboard?.writeText(fullText);
  };

  const handleRequestDeletion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    setDeletionSubmitting(true);
    try {
      // Send deletion request to backend reports/audit endpoint
      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetType: 'account_deletion_request',
          targetId: currentUser.id,
          targetTitle: `Account Deletion Request: ${currentUser.name} (@${currentUser.username})`,
          reason: 'Section G - Account and Data Deletion Request',
          details: deletionReason || 'User requested permanent account and data erasure.'
        })
      });
      setDeletionSubmitted(true);
      showToast('Account deletion request filed under Section G review.');
    } catch (err: any) {
      showToast('Could not submit request: ' + err.message, 'error');
    } finally {
      setDeletionSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Top Tab Navigation: Platform Rules vs Creator Monetization Terms */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 w-full sm:w-auto self-start shadow-inner">
        <button
          onClick={() => {
            setActiveTab('rules');
            setSearchQuery('');
          }}
          className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
            activeTab === 'rules'
              ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Platform Rules (Sections A–H)</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('monetization');
            setSearchQuery('');
          }}
          className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
            activeTab === 'monetization'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-500/25'
              : 'text-slate-600 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>Monetization Terms & Conditions</span>
          <span className="text-[10px] uppercase font-black px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
            PARTNER
          </span>
        </button>
      </div>

      {/* Header Banner */}
      <div className={`clay-card p-6 md:p-8 text-white rounded-3xl shadow-2xl relative overflow-hidden transition-all duration-300 ${
        activeTab === 'rules'
          ? 'bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30'
          : 'bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border border-emerald-500/30'
      }`}>
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-indigo-500/20 via-pink-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${
              activeTab === 'rules'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}>
              <ShieldCheck className="w-3.5 h-3.5" />
              {activeTab === 'rules' ? 'Official Supplementary Guidelines' : 'Creator Partner Program Contract'}
            </span>
            <span className="text-xs text-slate-400">• Updated 2026 • Legally Binding</span>
          </div>

          <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
            {activeTab === 'rules'
              ? 'WORLD VIDEO HUB — SUPPLEMENTARY PLATFORM RULES'
              : 'WORLD VIDEO HUB — CREATOR MONETIZATION TERMS AND CONDITIONS'}
          </h1>

          <p className="text-xs md:text-sm text-slate-300 max-w-2xl leading-relaxed">
            {activeTab === 'rules'
              ? 'These provisions supplement the seven Aluminium Hub legal policies. All creators, viewers, employers, and job applicants are required to adhere to these community and legal standards.'
              : 'These terms govern eligibility, net advertising revenue sharing (55% Watch Page Ads, 45% Shorts), channel memberships, live gift coins, Super Thanks tips, monthly payouts, and tax compliance for all monetized creators.'}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={handleCopyAll}
              className="clay-btn bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2 border border-white/20 transition active:scale-95"
            >
              <Copy className="w-3.5 h-3.5" />
              {activeTab === 'rules' ? 'Copy Full Rules (A–H)' : 'Copy Monetization Terms'}
            </button>
            {activeTab === 'monetization' ? (
              <button
                onClick={() => setActiveView('monetization')}
                className="clay-btn bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/30 transition active:scale-95"
              >
                <DollarSign className="w-3.5 h-3.5" />
                Go to Monetization Dashboard
              </button>
            ) : (
              <button
                onClick={() => setActiveView('upload')}
                className="clay-btn bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-2 shadow-lg shadow-rose-500/30 transition active:scale-95"
              >
                <Video className="w-3.5 h-3.5" />
                Upload Compliant Video
              </button>
            )}
            <button
              onClick={() => setActiveView('jobs')}
              className="clay-btn bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2 border border-white/10 transition active:scale-95"
            >
              <Briefcase className="w-3.5 h-3.5" />
              Browse Verified Jobs
            </button>
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={activeTab === 'rules' ? "Search rules (e.g. copyright, music, deletion)..." : "Search terms (e.g. revenue share, payout, taxes, invalid click)..."}
            className="w-full pl-9 pr-4 py-2.5 text-xs clay-input rounded-2xl"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            onClick={() => setExpandedSection(expandedSection === 'all' ? null : 'all')}
            className="text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800"
          >
            {expandedSection === 'all' ? 'Collapse All' : 'Expand All'}
          </button>
        </div>
      </div>

      {/* Sections List */}
      <div className="space-y-4">
        {filteredSections.map(sec => {
          const Icon = sec.icon;
          const isExpanded = expandedSection === 'all' || expandedSection === sec.id;

          return (
            <div
              key={sec.id}
              className="clay-card p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm transition hover:border-indigo-400/50"
            >
              <div
                onClick={() => setExpandedSection(isExpanded ? null : sec.id)}
                className="flex items-start justify-between gap-4 cursor-pointer"
              >
                <div className="flex items-start gap-3.5">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm flex-shrink-0 shadow-md ${
                    sec.color === 'violet' ? 'bg-violet-600 text-white shadow-violet-500/20' :
                    sec.color === 'rose' ? 'bg-rose-500 text-white shadow-rose-500/20' :
                    sec.color === 'blue' ? 'bg-blue-600 text-white shadow-blue-500/20' :
                    sec.color === 'emerald' ? 'bg-emerald-600 text-white shadow-emerald-500/20' :
                    sec.color === 'amber' ? 'bg-amber-500 text-white shadow-amber-500/20' :
                    sec.color === 'red' ? 'bg-red-600 text-white shadow-red-500/20' :
                    sec.color === 'cyan' ? 'bg-cyan-600 text-white shadow-cyan-500/20' :
                    'bg-slate-700 text-white shadow-slate-700/20'
                  }`}>
                    {sec.letter}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                        Section {sec.letter}
                      </span>
                    </div>
                    <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                      {sec.title}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {sec.subtitle}
                    </p>
                  </div>
                </div>

                <button className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>
              </div>

              {isExpanded && (
                <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed pl-1 sm:pl-14">
                  {sec.content.map((paragraph, idx) => (
                    <p
                      key={idx}
                      className={paragraph.startsWith('•') ? 'pl-3 font-medium text-slate-800 dark:text-slate-200' : 'font-semibold'}
                    >
                      {paragraph}
                    </p>
                  ))}

                  {sec.action && (
                    <div className="pt-3">
                      <button
                        onClick={sec.action.onClick}
                        className="clay-btn bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        {sec.action.label}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Account Deletion Modal (Section G) */}
      {deletionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="clay-card bg-white dark:bg-slate-900 max-w-md w-full p-6 space-y-4 shadow-2xl relative border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Account & Data Deletion
                </h3>
                <p className="text-xs text-slate-500">
                  Section G • User Privacy & Erasure Request
                </p>
              </div>
            </div>

            {deletionSubmitted ? (
              <div className="text-center py-4 space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Deletion Request Registered
                </h4>
                <p className="text-xs text-slate-500">
                  Your erasure request has been queued. In accordance with Section G, deletion will be handled subject to legal retention obligations, security records, and necessary backup schedules.
                </p>
                <button
                  onClick={() => {
                    setDeletionModalOpen(false);
                    setDeletionSubmitted(false);
                    setDeletionReason('');
                  }}
                  className="clay-btn clay-btn-primary px-5 py-2 text-xs font-bold"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleRequestDeletion} className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Under Section G of the Supplementary Platform Rules, you may request permanent removal of your account, uploaded media, and profile data.
                </p>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Reason for Deletion (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={deletionReason}
                    onChange={e => setDeletionReason(e.target.value)}
                    placeholder="Tell us why you are leaving or note any specific data you want deleted..."
                    className="w-full px-3 py-2 text-xs clay-input"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300/40 text-[11px] text-amber-800 dark:text-amber-300">
                  <strong>Notice:</strong> Once verified by admin, deletion cannot be undone. Active jobs and published videos will be removed.
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setDeletionModalOpen(false)}
                    className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={deletionSubmitting}
                    className="clay-btn bg-red-600 hover:bg-red-700 text-white px-4 py-1.5 text-xs font-bold gap-1 flex items-center"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    {deletionSubmitting ? 'Submitting...' : 'Submit Deletion Request'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
