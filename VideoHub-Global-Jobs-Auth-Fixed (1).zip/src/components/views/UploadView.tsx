import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  UploadCloud,
  FileVideo,
  CheckCircle2,
  Sparkles,
  Flame,
  Film,
  Play,
  RotateCcw,
  Check,
  AlertCircle,
  Eye,
  Globe,
  Sliders,
  Camera,
  CameraOff,
  Square,
  Circle,
  RotateCw,
  Mic,
  MicOff,
  ShieldCheck,
  ExternalLink,
  HelpCircle,
  AlertTriangle,
  DollarSign
} from 'lucide-react';
import confetti from 'canvas-confetti';

const UPLOAD_CATEGORIES = [
  'Aluminium & Façade Engineering',
  'Curtain Wall & Glazing',
  'Revit & BIM',
  'Architectural Engineering',
  'Civil Engineering',
  'AutoCAD Drafting',
  'Manufacturing & Fabrication',
  'Construction Management',
  'Software & IT',
  'Creative Media'
];

interface QuickPreset {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string;
  duration: string;
  videoUrl: string;
  thumbnailUrl: string;
}

const QUICK_SHORT_PRESETS: QuickPreset[] = [
  {
    id: 'p1',
    title: 'Spider Glass Fitting Articulation & Deflection Under 1000 Pa! 🏢💥',
    description: 'Watch 316 stainless steel articulation point flex under extreme horizontal wind pressure mockup test.',
    category: 'Curtain Wall & Glazing',
    tags: 'SpiderGlazing, Shorts, Engineering, Deflection',
    duration: '0:42',
    videoUrl: '/api/media/stream/video1.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop'
  },
  {
    id: 'p2',
    title: 'Precision 5-Axis Aluminium CNC Milling in Real-Time! ⚙️⚡',
    description: 'High-speed spindle machining complex transom corner notches for a 60-story unitized curtain wall tower.',
    category: 'Manufacturing & Fabrication',
    tags: 'CNC, Aluminium, Fabrication, Shorts',
    duration: '0:35',
    videoUrl: '/api/media/stream/video2.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&h=1000&fit=crop'
  },
  {
    id: 'p3',
    title: 'AutoCAD 2026 Thermal Break Drafting Snap Trick! 📐✏️',
    description: 'Instant perpendicular alignment shortcuts for polyamide barrier insulation detail drafting.',
    category: 'AutoCAD Drafting',
    tags: 'AutoCAD, Drafting, Shorts, CADTricks',
    duration: '0:29',
    videoUrl: '/api/media/stream/video3.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=600&h=1000&fit=crop'
  },
  {
    id: 'p4',
    title: 'Claymorphic Button 3D Inset Shadows: Pure CSS Magic! 🎨✨',
    description: 'How to combine double inset box-shadows to build tactile soft UI buttons that feel alive on mobile.',
    category: 'Creative Media',
    tags: 'Claymorphism, UIUX, CSS, WebDev, Shorts',
    duration: '0:38',
    videoUrl: '/api/media/stream/video4.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&h=1000&fit=crop'
  },
  {
    id: 'p5',
    title: 'Water Infiltration Mockup Chamber Test at 1000 Pascals! 💦🌊',
    description: 'High-pressure aero engine generator test verifying no moisture penetration through interlocking gaskets.',
    category: 'Aluminium & Façade Engineering',
    tags: 'WaterTest, CurtainWall, Mockup, Shorts',
    duration: '0:45',
    videoUrl: '/api/media/stream/video5.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=600&h=1000&fit=crop'
  }
];

export const UploadView: React.FC = () => {
  const { currentUser, setActiveView, showToast, setAuthModalOpen, uploadInitialFormat } = useApp();

  const [fileSelected, setFileSelected] = useState(false);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [previewBlobUrl, setPreviewBlobUrl] = useState<string | null>(null);
  const [autoDetectedShort, setAutoDetectedShort] = useState(false);
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);

  // Input Mode: File drop/browse vs Live Camera Recording
  const [inputMode, setInputMode] = useState<'file' | 'camera'>('file');

  // Video Upload Agreement acceptance state (Sections A, B & C)
  const [agreementAccepted, setAgreementAccepted] = useState(false);

  // Live Camera Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordedSeconds, setRecordedSeconds] = useState(0);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isCameraLoading, setIsCameraLoading] = useState(false);
  const [cameraFacingMode, setCameraFacingMode] = useState<'user' | 'environment'>('user');
  const [isCameraMicMuted, setIsCameraMicMuted] = useState(false);
  const [isMirrored, setIsMirrored] = useState(true);
  const [isRealWebcam, setIsRealWebcam] = useState(false);
  const [showCameraHelp, setShowCameraHelp] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const selectedFileRef = useRef<File | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: uploadInitialFormat === 'short' ? 'Curtain Wall & Glazing' : 'Aluminium & Façade Engineering',
    tags: uploadInitialFormat === 'short' ? 'Shorts, Reel, Engineering' : 'FaçadeEngineering, CurtainWall, Construction',
    isShort: uploadInitialFormat === 'short',
    visibility: 'public',
    commentsEnabled: true,
    isMonetized: true,
    thumbnailUrl: uploadInitialFormat === 'short'
      ? 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop'
      : 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=450&fit=crop',
    videoUrl: uploadInitialFormat === 'short' ? '/api/media/stream/video2.mp4' : '/api/media/stream/video1.mp4',
    duration: uploadInitialFormat === 'short' ? '0:35' : '10:00'
  });

  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);
  const canvasAnimRef = useRef<number | null>(null);

  useEffect(() => {
    if (uploadInitialFormat === 'short') {
      setFormData(prev => ({
        ...prev,
        isShort: true,
        category: 'Curtain Wall & Glazing',
        thumbnailUrl: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop',
        videoUrl: '/api/media/stream/video2.mp4',
        duration: '0:35'
      }));
    }
  }, [uploadInitialFormat]);

  // Cleanup camera stream and recording timer on unmount
  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      if (canvasAnimRef.current) cancelAnimationFrame(canvasAnimRef.current);
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
      }
    };
  }, [cameraStream]);

  // Safe fallback simulated studio camera with audio track
  const createSimulatedRecordingStream = (): MediaStream => {
    const canvas = document.createElement('canvas');
    canvas.width = formData.isShort ? 720 : 1280;
    canvas.height = formData.isShort ? 1280 : 720;
    const ctx = canvas.getContext('2d');

    let frame = 0;
    const draw = () => {
      frame++;
      if (ctx) {
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        const hue1 = (frame * 0.8) % 360;
        const hue2 = (hue1 + 90) % 360;
        gradient.addColorStop(0, `hsl(${hue1}, 75%, 20%)`);
        gradient.addColorStop(0.5, `hsl(${hue2}, 70%, 15%)`);
        gradient.addColorStop(1, '#090d16');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Futuristic grid
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.lineWidth = 2;
        const gridSize = 40;
        for (let x = 0; x < canvas.width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, canvas.height);
          ctx.stroke();
        }
        for (let y = 0; y < canvas.height; y += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(canvas.width, y);
          ctx.stroke();
        }

        // Animated target focus ring
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const radius = 90 + Math.sin(frame * 0.08) * 12;
        ctx.strokeStyle = '#8b5cf6';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();

        // Pulsing core
        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.arc(cx, cy, 26 + Math.sin(frame * 0.12) * 6, 0, Math.PI * 2);
        ctx.fill();

        // Overlay text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 32px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(currentUser?.name || 'Studio Creator', cx, cy - 130);

        ctx.font = 'bold 20px monospace';
        ctx.fillStyle = '#38bdf8';
        ctx.fillText(formData.isShort ? '⚡ SHORTS LIVE CAM FEED' : '🎬 STUDIO HD BROADCAST', cx, cy - 90);

        ctx.font = '16px monospace';
        ctx.fillStyle = '#a855f7';
        ctx.fillText(`ISO 800 • 60 FPS • 1080p • LIVE`, cx, cy + 130);
      }
      canvasAnimRef.current = requestAnimationFrame(draw);
    };
    draw();

    const canvasStream = canvas.captureStream(30);

    // Add silent audio track via Web Audio so MediaRecorder gets audio
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        gain.gain.value = 0.0001;
        const dest = audioCtx.createMediaStreamDestination();
        osc.connect(gain);
        gain.connect(dest);
        osc.start();
        dest.stream.getAudioTracks().forEach(track => canvasStream.addTrack(track));
      }
    } catch (e) {
      console.warn('Audio fallback error:', e);
    }

    return canvasStream;
  };

  const startCamera = async (facing: 'user' | 'environment' = cameraFacingMode) => {
    setIsCameraLoading(true);
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }

    let stream: MediaStream | null = null;
    let isHardwareCam = false;

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      // Step 1: Try video acquisition
      try {
        const videoConstraints: MediaStreamConstraints = {
          video: {
            facingMode: facing,
            width: { ideal: formData.isShort ? 720 : 1280 },
            height: { ideal: formData.isShort ? 1280 : 720 }
          }
        };
        const videoStream = await navigator.mediaDevices.getUserMedia(videoConstraints);
        stream = videoStream;
        isHardwareCam = true;

        // Step 2: Try audio acquisition separately
        try {
          const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          audioStream.getAudioTracks().forEach(track => stream?.addTrack(track));
        } catch (audioErr) {
          console.warn('Microphone permission denied or unavailable, proceeding with video only', audioErr);
        }
      } catch (err) {
        console.warn('HD camera acquisition failed, trying basic video:', err);
        try {
          const fallbackVideoStream = await navigator.mediaDevices.getUserMedia({ video: true });
          stream = fallbackVideoStream;
          isHardwareCam = true;
          try {
            const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            audioStream.getAudioTracks().forEach(track => stream?.addTrack(track));
          } catch {}
        } catch (finalErr) {
          console.warn('Physical camera unavailable or iframe permission blocked. Using Studio Cam:', finalErr);
        }
      }
    }

    if (!stream) {
      stream = createSimulatedRecordingStream();
      isHardwareCam = false;
    }

    setIsRealWebcam(isHardwareCam);
    setCameraStream(stream);
    setIsCameraLoading(false);

    if (cameraVideoRef.current && stream) {
      cameraVideoRef.current.srcObject = stream;
      cameraVideoRef.current.play().catch(e => console.warn('Cam video play catch:', e));
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }
    if (canvasAnimRef.current) {
      cancelAnimationFrame(canvasAnimRef.current);
      canvasAnimRef.current = null;
    }
  };

  const toggleCameraFacing = async () => {
    const nextFacing = cameraFacingMode === 'user' ? 'environment' : 'user';
    setCameraFacingMode(nextFacing);
    await startCamera(nextFacing);
  };

  const toggleCameraMic = () => {
    if (!cameraStream) return;
    const audioTracks = cameraStream.getAudioTracks();
    const nextMute = !isCameraMicMuted;
    audioTracks.forEach(t => { t.enabled = !nextMute; });
    setIsCameraMicMuted(nextMute);
    showToast(nextMute ? 'Microphone muted' : 'Microphone unmuted');
  };

  const startRecording = () => {
    if (!cameraStream) {
      startCamera();
      showToast('Initializing camera, click record again in a moment');
      return;
    }

    recordedChunksRef.current = [];
    setRecordedSeconds(0);

    let mimeType = 'video/webm;codecs=vp9,opus';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/mp4';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = '';
        }
      }
    }

    try {
      const options = mimeType ? { mimeType } : undefined;
      const mediaRecorder = new MediaRecorder(cameraStream, options);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const recordedBlob = new Blob(recordedChunksRef.current, {
          type: mimeType || 'video/webm'
        });
        const url = URL.createObjectURL(recordedBlob);
        setPreviewBlobUrl(url);
        setFileSelected(true);
        const generatedName = formData.isShort
          ? `Short_Take_${new Date().toISOString().slice(11, 19).replace(/:/g, '-')}.mp4`
          : `Studio_Video_${new Date().toISOString().slice(11, 19).replace(/:/g, '-')}.mp4`;
        setFileName(generatedName);
        setFileSize(`${(recordedBlob.size / (1024 * 1024)).toFixed(1)} MB`);
        setSelectedPresetId(null);
        setAutoDetectedShort(Boolean(formData.isShort));

        // Upload recorded blob to server /api/upload
        const uploadFile = new File([recordedBlob], generatedName, { type: recordedBlob.type });
        processSelectedFile(uploadFile);

        stopCamera();
        setInputMode('file'); // Return to preview & details view
        showToast('🎬 Recording complete! Ready to publish.');
      };

      mediaRecorder.start(250); // Collect slice every 250ms
      setIsRecording(true);

      recordingTimerRef.current = setInterval(() => {
        setRecordedSeconds((prev) => {
          const next = prev + 1;
          // For shorts, auto-stop at 60s
          if (formData.isShort && next >= 60) {
            stopRecording();
          }
          return next;
        });
      }, 1000);

      showToast('🔴 Recording started...');
    } catch (err: any) {
      console.error('Failed to start MediaRecorder:', err);
      showToast('Could not record with this device format', 'error');
    }
  };

  const stopRecording = () => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const processSelectedFile = async (file: File) => {
    const isVideo = (file.type && file.type.startsWith('video/')) || /\.(mp4|webm|mov|mkv|m4v|avi|3gp)$/i.test(file.name);
    if (!isVideo) {
      showToast('Please select a valid video file (MP4, WebM, MOV)', 'error');
      return;
    }

    selectedFileRef.current = file;
    setFileSelected(true);
    setFileName(file.name);
    setFileSize((file.size / (1024 * 1024)).toFixed(1) + ' MB');
    setSelectedPresetId(null);
    setUploadError(null);
    setUploadSuccess(false);

    // Create local object URL for instant preview and metadata detection
    const blobUrl = URL.createObjectURL(file);
    setPreviewBlobUrl(blobUrl);

    // Inspect video duration and aspect ratio
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.crossOrigin = 'anonymous';
    tempVideo.src = blobUrl;

    tempVideo.onloadedmetadata = () => {
      const durSec = tempVideo.duration || 0;
      const isPortrait = tempVideo.videoHeight > tempVideo.videoWidth;
      const formattedDur = formatSeconds(durSec);
      const isShortFormat = durSec <= 60 || isPortrait;

      if (isShortFormat) {
        setAutoDetectedShort(true);
        showToast(`⚡ Auto-detected as Short / Reel (${Math.round(durSec)}s, vertical ratio)!`, 'info');
      }

      setFormData(prev => ({
        ...prev,
        title: prev.title || file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
        duration: formattedDur,
        isShort: isShortFormat ? true : prev.isShort
      }));

      // Seek slightly into video to capture frame thumbnail
      tempVideo.currentTime = Math.min(1.0, durSec / 2);
    };

    tempVideo.onseeked = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = tempVideo.videoWidth || 480;
        canvas.height = tempVideo.videoHeight || 854;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(tempVideo, 0, 0, canvas.width, canvas.height);
          const thumbDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setFormData(prev => ({ ...prev, thumbnailUrl: thumbDataUrl }));
        }
      } catch (err) {
        console.warn('Canvas frame capture error (using preset thumb):', err);
      }
    };

    // Upload the video file to the server with multi-tier fallback
    uploadFileToServer(file);
  };

  const failUpload = (message: string) => {
    setIsUploading(false);
    setUploadProgress(0);
    setUploadSuccess(false);
    setUploadError(message);
    showToast(message, 'error');
  };

  const readErrorMessage = (text: string, fallback: string) => {
    try {
      const parsed = JSON.parse(text);
      return parsed.error || fallback;
    } catch {
      return fallback;
    }
  };

  const tryBase64Fallback = (file: File, previousError?: string) => {
    // Channel 2: Base64 JSON upload fallback (only for network-level failures)
    if (file.size > 70 * 1024 * 1024) {
      failUpload(previousError || 'Upload failed. Please try a smaller video (under 70MB) or check your connection.');
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await fetch('/api/videos/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filename: file.name,
            base64Data: reader.result,
            isShort: Boolean(formData.isShort)
          })
        });
        const data = await res.json().catch(() => ({} as any));
        if (res.ok && data.url) {
          setFormData(prev => ({ ...prev, videoUrl: data.url }));
          setUploadProgress(100);
          setUploadSuccess(true);
          setUploadError(null);
          setIsUploading(false);
          showToast('Video uploaded and ready to publish!', 'success');
          return;
        }
        failUpload(data.error || previousError || `Upload failed (server error ${res.status}).`);
      } catch {
        failUpload(previousError || 'Upload failed. Please check your connection and try again.');
      }
    };
    reader.onerror = () => failUpload('Could not read the selected file. Please choose it again.');
    reader.readAsDataURL(file);
  };

  const uploadToOwnServer = (file: File) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      showToast('Please sign in to upload videos', 'info');
      return;
    }
    if (file.size > 100 * 1024 * 1024) {
      failUpload('Video is too large. Maximum size is 100MB.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(10);
    setUploadError(null);
    setUploadSuccess(false);

    const xhr = new XMLHttpRequest();
    const cleanName = file.name || 'video.mp4';
    const query = new URLSearchParams({
      filename: cleanName,
      isShort: String(formData.isShort)
    });

    xhr.open('POST', `/api/videos/upload-raw?${query.toString()}`);
    xhr.withCredentials = true;
    xhr.setRequestHeader('Content-Type', file.type || 'video/mp4');
    xhr.setRequestHeader('X-Filename', encodeURIComponent(cleanName));

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const percent = Math.min(95, Math.round((e.loaded / e.total) * 100));
        setUploadProgress(percent);
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const res = JSON.parse(xhr.responseText);
          if (res.success && res.url) {
            setFormData(prev => ({ ...prev, videoUrl: res.url }));
            setUploadProgress(100);
            setUploadSuccess(true);
            setUploadError(null);
            setIsUploading(false);
            showToast('Video file saved to server and ready to publish!', 'success');
            return;
          }
        } catch {
          // fall through to error handling
        }
      }
      const message = readErrorMessage(
        xhr.responseText,
        xhr.status === 413
          ? 'Video is too large for the server. Please use a smaller file.'
          : `Upload failed (server error ${xhr.status}).`
      );
      // Auth / size / validation errors will not be fixed by retrying through another channel
      if (xhr.status === 401 || xhr.status === 400 || xhr.status === 413) {
        failUpload(message);
        return;
      }
      tryBase64Fallback(file, message);
    };

    xhr.onerror = () => {
      tryBase64Fallback(file, 'Network error while uploading. Please check your connection.');
    };

    xhr.send(file);
  };

  const uploadFileToServer = async (file: File) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      showToast('Please sign in to upload videos', 'info');
      return;
    }
    if (file.size > 100 * 1024 * 1024) {
      failUpload('Video is too large. Maximum size is 100MB.');
      return;
    }

    // Preferred path: signed direct upload to Cloudinary (permanent storage, no server size limit)
    let sign: any = null;
    let backendDown = false;
    let serverless = false;
    try {
      const res = await fetch('/api/upload/sign', { method: 'POST' });
      const isJson = (res.headers.get('content-type') || '').includes('application/json');
      if (!isJson) {
        backendDown = true; // got a web page instead of API data
      } else {
        const data = await res.json().catch(() => ({} as any));
        if (res.ok) sign = data;
        else if (res.status === 401) {
          failUpload('Please sign in again to upload videos.');
          return;
        } else serverless = Boolean(data.serverless);
      }
    } catch {
      backendDown = true; // "Failed to fetch": the API could not be reached at all
    }

    if (backendDown) {
      failUpload('Cannot reach the server API (/api). The backend is not running on this site. Redeploy with the Netlify function and check https://YOUR-SITE/api/health');
      return;
    }
    if (!sign || sign.provider !== 'cloudinary') {
      if (serverless && file.size > 4 * 1024 * 1024) {
        failUpload('Cloud storage is not set up yet. Add the Cloudinary keys (CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET) in your hosting environment variables to upload videos over 4 MB.');
        return;
      }
      uploadToOwnServer(file);
      return;
    }

    setIsUploading(true);
    setUploadProgress(5);
    setUploadError(null);
    setUploadSuccess(false);

    const body = new FormData();
    body.append('file', file);
    body.append('api_key', sign.apiKey);
    body.append('timestamp', String(sign.timestamp));
    body.append('folder', sign.folder);
    body.append('signature', sign.signature);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', sign.uploadUrl);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) setUploadProgress(Math.min(95, Math.round((e.loaded / e.total) * 100)));
    };
    xhr.onload = () => {
      try {
        const out = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300 && out.secure_url) {
          setFormData(prev => ({ ...prev, videoUrl: out.secure_url }));
          setUploadProgress(100);
          setUploadSuccess(true);
          setUploadError(null);
          setIsUploading(false);
          showToast('Video uploaded and ready to publish!', 'success');
          return;
        }
        failUpload(out?.error?.message || `Cloud upload failed (error ${xhr.status}).`);
      } catch {
        failUpload(`Cloud upload failed (error ${xhr.status}).`);
      }
    };
    xhr.onerror = () => failUpload('Network error while uploading. Please check your connection.');
    xhr.send(body);
  };

  const handleApplyPreset = (preset: QuickPreset) => {
    setSelectedPresetId(preset.id);
    setFileSelected(true);
    setFileName(preset.title.slice(0, 35) + '... (Ready Clip)');
    setFileSize('1.2 MB (Server Stream)');
    setPreviewBlobUrl(preset.videoUrl);
    setAutoDetectedShort(true);
    setIsUploading(false);
    setUploadProgress(100);

    setFormData({
      title: preset.title,
      description: preset.description,
      category: preset.category,
      tags: preset.tags,
      isShort: true,
      visibility: 'public',
      commentsEnabled: true,
      isMonetized: true,
      thumbnailUrl: preset.thumbnailUrl,
      videoUrl: preset.videoUrl,
      duration: preset.duration
    });

    showToast(`Loaded Short preset: "${preset.title.slice(0, 30)}..."`);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) processSelectedFile(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processSelectedFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }

    if (!formData.title.trim()) {
      showToast('Please provide a video title', 'error');
      return;
    }

    if (isUploading) {
      showToast('Video stream is still finalizing, please wait a moment...', 'info');
      return;
    }

    if (!agreementAccepted) {
      showToast('Please accept the Video Upload Agreement (Supplementary Platform Rules A, B & C)', 'error');
      return;
    }

    try {
      const isShortUpload = Boolean(formData.isShort);
      let finalVideoUrl = formData.videoUrl;
      if (!finalVideoUrl || finalVideoUrl.startsWith('blob:')) {
        showToast(uploadError || 'Please select a video file and wait for the upload to finish.', 'error');
        return;
      }

      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          videoUrl: finalVideoUrl,
          isShort: isShortUpload,
          tags: typeof formData.tags === 'string'
            ? formData.tags.split(',').map(t => t.trim()).filter(Boolean)
            : formData.tags
        })
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        if (res.status === 401) setAuthModalOpen(true);
        throw new Error(errorData.error || `Failed to publish video (server error ${res.status})`);
      }

      confetti({ particleCount: 80, spread: 70 });

      if (isShortUpload) {
        showToast('⚡ Short published successfully! Launching Shorts reel...', 'success');
        // Immediately navigate to shorts feed so user sees their new short playing
        setTimeout(() => {
          setActiveView('shorts');
        }, 350);
      } else {
        showToast('🎬 Video published successfully!', 'success');
        setActiveView('home');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Header Banner */}
      <div className="clay-card p-6 bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-pink-500/10 border border-violet-300/40 dark:border-violet-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-violet-600 dark:text-violet-400" />
              Creator Studio & Video Publishing
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Publish vertical mobile Shorts or full-length horizontal masterclasses to the global engineering community.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveView('shorts')}
            className="clay-btn clay-btn-secondary px-3.5 py-1.5 text-xs font-bold self-start sm:self-auto flex items-center gap-1.5"
          >
            <Flame className="w-4 h-4 text-rose-500" />
            Watch Trending Shorts
          </button>
        </div>
      </div>

      {/* Main Publishing Card */}
      <div className="clay-card p-6 bg-white dark:bg-[#181D2E] space-y-6">
        {/* Prominent Video Format Selector */}
        <div className="space-y-2">
          <label className="block text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
            1. Select Video Format
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Short Format Tab */}
            <button
              type="button"
              onClick={() => {
                setFormData(prev => ({
                  ...prev,
                  isShort: true,
                  category: prev.category === 'Aluminium & Façade Engineering' ? 'Curtain Wall & Glazing' : prev.category,
                  thumbnailUrl: prev.thumbnailUrl.includes('photo-1545324418-cc1a3fa10c00')
                    ? 'https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&h=1000&fit=crop'
                    : prev.thumbnailUrl
                }));
              }}
              className={`p-4 rounded-2xl border-2 text-left flex items-start gap-3 transition-all ${
                formData.isShort
                  ? 'border-rose-500 bg-rose-50/70 dark:bg-rose-950/30 ring-2 ring-rose-500/20 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                formData.isShort
                  ? 'bg-gradient-to-tr from-rose-500 to-pink-500 text-white shadow-md shadow-rose-500/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}>
                <Flame className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                    ⚡ Short Video / Reel
                  </span>
                  {formData.isShort && (
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-500 text-white">
                      Active Mode
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                  Under 60 seconds • Vertical 9:16 Feed • Instant playback in the Shorts Reel.
                </p>
              </div>
            </button>

            {/* Standard Long Video Tab */}
            <button
              type="button"
              onClick={() => {
                setFormData(prev => ({
                  ...prev,
                  isShort: false,
                  category: prev.category === 'Curtain Wall & Glazing' ? 'Aluminium & Façade Engineering' : prev.category,
                  thumbnailUrl: prev.thumbnailUrl.includes('photo-1506157786151-b8491531f063')
                    ? 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=450&fit=crop'
                    : prev.thumbnailUrl
                }));
              }}
              className={`p-4 rounded-2xl border-2 text-left flex items-start gap-3 transition-all ${
                !formData.isShort
                  ? 'border-violet-500 bg-violet-50/70 dark:bg-violet-950/30 ring-2 ring-violet-500/20 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                !formData.isShort
                  ? 'bg-gradient-to-tr from-violet-600 to-indigo-600 text-white shadow-md shadow-violet-500/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}>
                <Film className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                    🎬 Standard Long-form Video
                  </span>
                  {!formData.isShort && (
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-violet-600 text-white">
                      Active Mode
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                  Horizontal 16:9 • Comprehensive tutorials, site walkthroughs & BIM masterclasses.
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Quick Test Presets for Shorts */}
        <div className="p-4 rounded-2xl bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/50 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <h3 className="text-xs font-black uppercase tracking-wider text-amber-900 dark:text-amber-200">
                Quick Test Mode (Publish a Short in 1 Click)
              </h3>
            </div>
            <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold">
              No MP4 file on your device? Pick a demo clip:
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {QUICK_SHORT_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleApplyPreset(preset)}
                className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 ${
                  selectedPresetId === preset.id
                    ? 'border-amber-500 bg-amber-100 dark:bg-amber-900/40 text-amber-900 dark:text-amber-100 shadow-sm'
                    : 'border-amber-200/80 dark:border-amber-800/40 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-amber-400'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center flex-shrink-0 font-bold text-xs shadow-sm">
                  {selectedPresetId === preset.id ? <Check className="w-4 h-4" /> : <Play className="w-3.5 h-3.5" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold truncate">{preset.title}</p>
                  <p className="text-[10px] text-slate-400 truncate">{preset.duration} • {preset.category}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Video Source: File Upload vs Live Camera Studio */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="block text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
              2. Video Source
            </label>
            <div className="flex items-center p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  setInputMode('file');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  inputMode === 'file'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <UploadCloud className="w-3.5 h-3.5" />
                Upload File / Presets
              </button>
              <button
                type="button"
                onClick={() => {
                  setInputMode('camera');
                  startCamera();
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  inputMode === 'camera'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-sm shadow-rose-500/30'
                    : 'text-slate-500 hover:text-rose-500'
                }`}
              >
                <Camera className="w-3.5 h-3.5" />
                Record with Camera (HD)
              </button>
            </div>
          </div>

          {inputMode === 'camera' ? (
            /* Live Camera Recording Viewfinder */
            <div className="p-4 sm:p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-rose-500 text-white animate-pulse">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black tracking-wide uppercase text-white flex items-center gap-2">
                      Live Camera Recording Studio
                      {isRealWebcam ? (
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-full">
                          📹 HD Webcam Connected
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded-full">
                          🟣 Studio WebCam Live
                        </span>
                      )}
                    </h4>
                    <p className="text-[10px] text-slate-400">
                      {formData.isShort ? 'Shooting 9:16 vertical Short (Max 60s)' : 'Shooting 16:9 HD standard video'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setShowCameraHelp(!showCameraHelp)}
                    className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs flex items-center gap-1 transition"
                    title="Camera diagnostics"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold">Help</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      window.open(window.location.origin, '_blank');
                    }}
                    className="p-1.5 rounded-xl bg-violet-600/80 hover:bg-violet-600 text-white text-xs flex items-center gap-1 transition"
                    title="Open in top window to bypass iframe permissions"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold">Standalone Window</span>
                  </button>
                </div>
              </div>

              {/* Viewfinder Video Element */}
              <div className="relative mx-auto flex items-center justify-center bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl max-w-full">
                <div className={formData.isShort ? 'w-[260px] sm:w-[300px] aspect-[9/16]' : 'w-full aspect-video max-h-[380px]'}>
                  <video
                    ref={(el) => {
                      cameraVideoRef.current = el;
                      if (el && cameraStream && el.srcObject !== cameraStream) {
                        el.srcObject = cameraStream;
                        el.play().catch(e => console.warn('Cam play catch:', e));
                      }
                    }}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover ${isMirrored && cameraFacingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                  />
                </div>

                {/* Viewfinder Overlays */}
                <div className="absolute top-3 inset-x-3 flex items-center justify-between pointer-events-none">
                  {isRecording ? (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-600/90 text-white font-mono text-xs font-black shadow-lg backdrop-blur-md animate-pulse">
                      <Circle className="w-3 h-3 fill-white text-white" />
                      <span>REC {formatSeconds(recordedSeconds)} {formData.isShort && `/ 01:00`}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 text-white/80 font-mono text-[11px] backdrop-blur-md border border-white/10">
                      <span>STANDBY</span>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 pointer-events-auto">
                    <button
                      type="button"
                      onClick={() => setIsMirrored(!isMirrored)}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold transition backdrop-blur-md ${
                        isMirrored ? 'bg-white/20 text-white' : 'bg-black/50 text-white/60'
                      }`}
                    >
                      Mirror {isMirrored ? 'On' : 'Off'}
                    </button>
                  </div>
                </div>

                {/* Viewfinder Bottom Controls Bar */}
                <div className="absolute bottom-3 inset-x-3 flex items-center justify-between px-3 py-2 rounded-2xl bg-black/70 backdrop-blur-md border border-white/10">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleCameraFacing}
                      className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
                      title="Flip Camera (Front/Back)"
                    >
                      <RotateCw className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={toggleCameraMic}
                      className={`p-2 rounded-xl transition active:scale-95 ${
                        isCameraMicMuted ? 'bg-rose-500/80 text-white' : 'bg-white/10 hover:bg-white/20 text-white'
                      }`}
                      title={isCameraMicMuted ? 'Unmute Mic' : 'Mute Mic'}
                    >
                      {isCameraMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Primary Record Action */}
                  <div className="flex items-center gap-2">
                    {!isRecording ? (
                      <button
                        type="button"
                        onClick={startRecording}
                        disabled={isCameraLoading}
                        className="px-5 py-2 rounded-2xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-rose-600/40 transition disabled:opacity-50"
                      >
                        <Circle className="w-4 h-4 fill-white text-white" />
                        <span>Start Recording</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={stopRecording}
                        className="px-5 py-2 rounded-2xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-black font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-500/40 transition animate-pulse"
                      >
                        <Square className="w-4 h-4 fill-black text-black" />
                        <span>Stop & Use Video</span>
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      stopCamera();
                      setInputMode('file');
                    }}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition"
                  >
                    Cancel
                  </button>
                </div>
              </div>

              {/* Help & Browser Lock Icon Diagnostics */}
              {showCameraHelp && (
                <div className="p-3.5 rounded-2xl bg-slate-800/90 border border-slate-700 text-xs space-y-2 text-slate-300 animate-in fade-in">
                  <div className="flex items-center justify-between text-white font-bold">
                    <span className="flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-violet-400" />
                      Camera Permission Troubleshooting
                    </span>
                    <button onClick={() => setShowCameraHelp(false)} className="text-slate-400 hover:text-white">✕</button>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    1. <strong>Browser Lock Icon:</strong> Click the padlock icon in the browser address bar and ensure <strong>Camera</strong> and <strong>Microphone</strong> are set to <strong>Allow</strong>.
                  </p>
                  <p className="text-[11px] leading-relaxed">
                    2. <strong>Iframe Isolation Bypass:</strong> Embedded preview frames can restrict hardware capture. Click <strong>"Standalone Window"</strong> above to launch full camera access in top-level browser tab.
                  </p>
                  <p className="text-[11px] leading-relaxed">
                    3. <strong>Studio WebCam Fallback:</strong> If no webcam is attached or permission is denied, our built-in 60FPS Studio Visualizer automatically runs so you can still create and publish videos smoothly.
                  </p>
                </div>
              )}
            </div>
          ) : !fileSelected ? (
            /* File Dropzone */
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleFileDrop}
              className={`p-8 rounded-3xl border-3 border-dashed text-center cursor-pointer transition relative ${
                formData.isShort
                  ? 'border-rose-300 dark:border-rose-700 bg-rose-50/40 dark:bg-rose-950/20 hover:bg-rose-100/50'
                  : 'border-violet-300 dark:border-violet-700 bg-violet-50/40 dark:bg-violet-950/20 hover:bg-violet-100/50'
              }`}
            >
              <input
                type="file"
                accept="video/*,.mp4,.webm,.mov,.mkv"
                onChange={handleFileInput}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <div className={`w-16 h-16 mx-auto rounded-3xl flex items-center justify-center mb-3 shadow-md ${
                formData.isShort
                  ? 'bg-rose-100 dark:bg-rose-900/60 text-rose-600 shadow-rose-500/20'
                  : 'bg-violet-100 dark:bg-violet-900/60 text-violet-600 shadow-violet-500/20'
              }`}>
                <UploadCloud className="w-8 h-8" />
              </div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                Drag & Drop Video Files or Click to Browse
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                MP4, WebM, or MOV up to 100MB • Auto-detects Shorts & Video Specs
              </p>
            </div>
          ) : (
            /* Selected File / Stream Info Bar */
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <FileVideo className="w-9 h-9 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-bold text-slate-900 dark:text-slate-100">{fileName}</p>
                    {autoDetectedShort && (
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-500 text-white">
                        ⚡ Shorts Verified
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-500">
                    {fileSize} • Duration: {formData.duration} • Server Stream Ready
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setFileSelected(false);
                  setPreviewBlobUrl(null);
                  setUploadProgress(0);
                  setSelectedPresetId(null);
                  setAutoDetectedShort(false);
                }}
                className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 self-end sm:self-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Change Video
              </button>
            </div>
          )}
        </div>

        {/* Upload Progress Bar */}
        {isUploading && (
          <div className="space-y-1.5 p-3 rounded-2xl bg-violet-50/70 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-800">
            <div className="flex items-center justify-between text-xs font-bold text-violet-700 dark:text-violet-300">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 animate-spin text-violet-500" />
                Writing video stream to high-speed backend...
              </span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-violet-600 via-rose-500 to-pink-500 transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Upload Success Badge */}
        {uploadSuccess && !isUploading && (
          <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-200 animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Video successfully uploaded and encoded for instant global streaming.</span>
            </div>
            <span className="text-[10px] font-mono opacity-80">{formData.videoUrl.slice(0, 30)}...</span>
          </div>
        )}

        {/* Upload Error / Retry Bar */}
        {uploadError && !isUploading && (
          <div className="flex items-center justify-between p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs font-bold text-rose-800 dark:text-rose-200 animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 flex-shrink-0" />
              <span>{uploadError}</span>
            </div>
            {selectedFileRef.current && (
              <button
                type="button"
                onClick={() => selectedFileRef.current && uploadFileToServer(selectedFileRef.current)}
                className="px-3 py-1 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition flex items-center gap-1 active:scale-95"
              >
                <RotateCcw className="w-3 h-3" />
                Retry Upload
              </button>
            )}
          </div>
        )}

        {/* Video Preview Player if available */}
        {previewBlobUrl && (
          <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Preview Stream ({formData.isShort ? 'Shorts 9:16' : '16:9 Standard'})</span>
              <span className="text-[10px] text-emerald-400 font-mono">Stream Active</span>
            </div>
            <div className={`mx-auto rounded-xl overflow-hidden bg-black flex items-center justify-center ${
              formData.isShort ? 'max-w-[220px] aspect-[9/16]' : 'w-full aspect-video max-h-64'
            }`}>
              <video
                ref={previewVideoRef}
                src={previewBlobUrl}
                controls
                playsInline
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        )}

        {/* Video Metadata Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
              3. Video Details
            </label>
            <span className="text-[11px] font-bold text-violet-600 dark:text-violet-400">
              Target Feed: {formData.isShort ? '⚡ Shorts Feed' : '🎬 Videos Feed'}
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder={formData.isShort ? 'e.g. Spider Fitting Flex Under 1000 Pa! 🏢💥' : 'e.g. Unitized Curtain Wall Performance Testing at 1000 Pa'}
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs clay-input"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Description & Highlights
            </label>
            <textarea
              rows={3}
              placeholder="Explain the technical specs, formulas, BIM parameters or site safety details..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2 text-xs clay-input"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
              >
                {UPLOAD_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Tags & Hashtags
              </label>
              <input
                type="text"
                placeholder={formData.isShort ? 'Shorts, Reel, Engineering, SpiderGlazing' : 'Façade, Extrusion, Revit, Construction'}
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                className="w-full px-3.5 py-2 text-xs clay-input"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Visibility
              </label>
              <select
                value={formData.visibility}
                onChange={(e) => setFormData({ ...formData, visibility: e.target.value })}
                className="w-full px-3 py-2 text-xs clay-input bg-white dark:bg-slate-800"
              >
                <option value="public">Public (Visible to everyone)</option>
                <option value="unlisted">Unlisted (Anyone with link)</option>
                <option value="private">Private (Only you)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Duration Display
              </label>
              <input
                type="text"
                placeholder="e.g. 0:35 or 12:40"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full px-3.5 py-2 text-xs clay-input"
              />
            </div>
          </div>

          {/* Comments Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800">
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Enable Community Discussions</p>
              <p className="text-[10px] text-slate-400">Allow followers and job candidates to ask questions and comment</p>
            </div>
            <input
              type="checkbox"
              checked={formData.commentsEnabled}
              onChange={(e) => setFormData({ ...formData, commentsEnabled: e.target.checked })}
              className="w-4 h-4 accent-violet-600 rounded cursor-pointer"
            />
          </div>

          {/* Monetization Toggle (Partner Program) */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/60">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-xs font-black text-slate-900 dark:text-slate-100">
                    Monetize This Video (Partner Program)
                  </p>
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500 text-white">
                    55% / 45% Split
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Enable Watch Page Ads, Shorts Feed Ads, and Super Thanks tipping in compliance with Creator Monetization Terms.
                </p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-3 flex-shrink-0">
              <input
                type="checkbox"
                checked={formData.isMonetized}
                onChange={(e) => setFormData({ ...formData, isMonetized: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500" />
            </label>
          </div>

          {/* Supplementary Platform Rules: Video Upload Agreement (Sections A, B & C) */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  Video Upload Agreement (Supplementary Rules A, B & C)
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveView('policies')}
                className="text-[11px] font-bold text-violet-600 dark:text-violet-400 hover:underline flex items-center gap-1"
              >
                <span>Read Full Policies (A–H)</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700/60 text-[11px] text-slate-600 dark:text-slate-300 space-y-2 leading-relaxed">
              <p className="font-bold text-slate-800 dark:text-slate-100">
                By uploading a video, you confirm that:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400">
                <li>You own the video or have permission to publish it.</li>
                <li>You have permission to use included music, photographs and other copyrighted materials.</li>
                <li>The video does not violate another person's privacy or intellectual property rights.</li>
                <li>The video does not contain unlawful, fraudulent or prohibited material.</li>
                <li>You grant Aluminium Hub the limited platform licence described in the main Terms and Conditions.</li>
                <li>You remain responsible for the legality of your uploaded content.</li>
              </ul>
              {formData.isShort ? (
                <p className="text-[10px] text-rose-600 dark:text-rose-400 font-semibold pt-1 border-t border-slate-100 dark:border-slate-700">
                  ⚡ <strong>Short Video Rules (Sec. B):</strong> Must not contain copyrighted clips without permission, violent or unlawful material, fake promotions, or misleading links.
                </p>
              ) : (
                <p className="text-[10px] text-violet-600 dark:text-violet-400 font-semibold pt-1 border-t border-slate-100 dark:border-slate-700">
                  🎬 <strong>Long Video Rules (Sec. C):</strong> Suitable for aluminium tutorials, curtain wall demonstrations, factory tours, engineering presentations, and professional training.
                </p>
              )}
            </div>

            <label className="flex items-start gap-2.5 cursor-pointer pt-1 group">
              <input
                type="checkbox"
                required
                checked={agreementAccepted}
                onChange={(e) => setAgreementAccepted(e.target.checked)}
                className="w-4 h-4 mt-0.5 accent-violet-600 rounded cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition">
                I agree to the Video Upload Agreement and confirm full compliance with Supplementary Platform Rules A, B & C.
              </span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100 dark:border-slate-800">
            {!agreementAccepted ? (
              <p className="text-[11px] text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Please check the Video Upload Agreement box above to publish</span>
              </p>
            ) : (
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Agreement accepted and verified</span>
              </p>
            )}

            <div className="flex items-center gap-3 self-end sm:self-auto">
              <button
                type="button"
                onClick={() => setActiveView(formData.isShort ? 'shorts' : 'home')}
                className="clay-btn clay-btn-secondary px-5 py-2.5 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isUploading || !agreementAccepted}
                className={`px-7 py-2.5 text-xs font-black shadow-lg active:scale-95 transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 rounded-2xl text-white ${
                  formData.isShort
                    ? 'bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500 hover:from-rose-600 hover:to-pink-600 shadow-rose-500/30'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 shadow-violet-500/30'
                }`}
              >
                {formData.isShort ? <Flame className="w-4 h-4" /> : <Film className="w-4 h-4" />}
                {formData.isShort ? 'Publish to Shorts Reel' : 'Publish Long Video'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
