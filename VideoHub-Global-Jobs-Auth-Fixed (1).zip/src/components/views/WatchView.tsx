import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Video, Comment, Repost, StoreProduct } from '../../types/index.ts';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Settings,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  ShieldAlert,
  CheckCircle,
  Eye,
  Calendar,
  Send,
  MessageSquare,
  Sparkles,
  ArrowLeft,
  PictureInPicture,
  SkipForward,
  SkipBack,
  ListVideo,
  Clock,
  X,
  Repeat2,
  SlidersHorizontal,
  Gauge,
  Lock,
  Unlock,
  ChevronRight,
  ChevronLeft,
  Check,
  Activity,
  Repeat,
  Sun,
  Volume1,
  DollarSign,
  HeartHandshake,
  ShoppingBag,
  Heart,
  ExternalLink
} from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge.tsx';
import { VideoReactionBar } from '../video/VideoReactionBar.tsx';
import confetti from 'canvas-confetti';

export const WatchView: React.FC = () => {
  const {
    activeVideo,
    setActiveVideo,
    setActiveView,
    currentUser,
    setActiveProfileUsername,
    setReportTarget,
    showToast,
    setAuthModalOpen,
    playlists,
    createPlaylist,
    addVideoToPlaylist,
    removeVideoFromPlaylist,
    isAutoplay,
    bookmarkedVideoIds,
    toggleBookmark,
    openInMiniPlayer,
    currentPlaylistQueue,
    setCurrentPlaylistQueue,
    playNextInPlaylist,
    playPrevInPlaylist,
    addToCart,
    openStore,
    isInWishlist,
    toggleWishlist,
    setIsCartOpen
  } = useApp();

  const [featuredProducts, setFeaturedProducts] = useState<StoreProduct[]>([]);

  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [relatedVideos, setRelatedVideos] = useState<Video[]>([]);
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [isFollowed, setIsFollowed] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [isPlaylistDrawerOpen, setIsPlaylistDrawerOpen] = useState(false);
  const [showCC, setShowCC] = useState(false);
  const [videoReactions, setVideoReactions] = useState<Record<string, number>>({
    '❤️': 0,
    '🔥': 0,
    '🎉': 0,
    '👏': 0,
    '😂': 0,
  });

  const [isReposted, setIsReposted] = useState(false);
  const [repostsCount, setRepostsCount] = useState(0);
  const [reposts, setReposts] = useState<Repost[]>([]);
  const [activeEngagementTab, setActiveEngagementTab] = useState<'comments' | 'reposts'>('comments');
  const [repostModalOpen, setRepostModalOpen] = useState(false);
  const [quoteText, setQuoteText] = useState('');
  const [isSubmittingRepost, setIsSubmittingRepost] = useState(false);

  // Super Thanks / Creator Tip State
  const [thanksModalOpen, setThanksModalOpen] = useState(false);
  const [thanksAmount, setThanksAmount] = useState(5);
  const [thanksMessage, setThanksMessage] = useState('Outstanding engineering demo! Keep it up! 💎');
  const [isSendingThanks, setIsSendingThanks] = useState(false);

  // YouTube-style Settings Bottom Sheet State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsSubmenu, setSettingsSubmenu] = useState<'root' | 'quality' | 'speed' | 'captions' | 'more'>('root');
  const [selectedQuality, setSelectedQuality] = useState('Auto (1080p60)');
  const [selectedCaptionLang, setSelectedCaptionLang] = useState('English (auto-generated)');
  const [isScreenLocked, setIsScreenLocked] = useState(false);
  const [showUnlockPill, setShowUnlockPill] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [ambientMode, setAmbientMode] = useState(true);
  const [stableVolume, setStableVolume] = useState(true);
  const [statsForNerds, setStatsForNerds] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!activeVideo) return;
    setIsLiked(Boolean(activeVideo.isLiked));
    setLikesCount(activeVideo.likesCount);
    setIsReposted(Boolean(activeVideo.isReposted));
    setRepostsCount(activeVideo.repostsCount || 0);

    fetch(`/api/videos/${activeVideo.id}`)
      .then(r => r.json())
      .then(d => {
        if (d.related) setRelatedVideos(d.related);
        if (d.video?.isLiked !== undefined) setIsLiked(d.video.isLiked);
        if (d.video?.isReposted !== undefined) setIsReposted(d.video.isReposted);
        if (d.video?.repostsCount !== undefined) setRepostsCount(d.video.repostsCount);
      })
      .catch(() => {});

    fetch(`/api/videos/${activeVideo.id}/comments`)
      .then(r => r.json())
      .then(d => setComments(d.comments || []))
      .catch(() => {});

    fetch(`/api/videos/${activeVideo.id}/reposts`)
      .then(r => r.json())
      .then(d => {
        if (d.reposts) setReposts(d.reposts);
        if (d.repostsCount !== undefined) setRepostsCount(d.repostsCount);
        if (d.isReposted !== undefined) setIsReposted(d.isReposted);
      })
      .catch(() => {});

    // Check if following creator
    if (activeVideo.creatorId) {
      fetch(`/api/creators/${activeVideo.creator.username}`)
        .then(r => r.json())
        .then(d => setIsFollowed(Boolean(d.isFollowing)))
        .catch(() => {});
    }

    // Load featured store products related to this video / creator
    fetch('/api/store/products')
      .then(r => r.json())
      .then(d => {
        const allProds: StoreProduct[] = d.products || [];
        const creatorProds = allProds.filter(p => p.sellerId === activeVideo.creatorId);
        const tagProds = allProds.filter(p =>
          activeVideo.tags && activeVideo.tags.some(vt =>
            p.tags && p.tags.some(pt => pt.toLowerCase().includes(vt.toLowerCase()) || vt.toLowerCase().includes(pt.toLowerCase()))
          )
        );
        const combined = Array.from(new Set([...creatorProds, ...tagProds, ...allProds.filter(p => p.isFeatured)]));
        setFeaturedProducts(combined.slice(0, 3));
      })
      .catch(() => {});

    setIsPlaying(true);
  }, [activeVideo?.id]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      setDuration(videoRef.current.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    videoRef.current.muted = nextMute;
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSpeedMenu(false);
    showToast(`Playback speed set to ${speed}x`);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleLike = async () => {
    if (!activeVideo) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/videos/${activeVideo.id}/like`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setIsLiked(data.isLiked);
        setLikesCount(data.likesCount);
        if (data.isLiked) {
          setDisliked(false);
          confetti({ particleCount: 35, spread: 50 });
        }
      }
    } catch (e) {
      showToast('Could not register like', 'error');
    }
  };

  const handleEmojiReaction = (emoji: string) => {
    setVideoReactions(prev => ({
      ...prev,
      [emoji]: prev[emoji] + 1
    }));
    confetti({
      particleCount: 20,
      spread: 30,
      origin: { y: 0.8 },
      shapes: ['circle'],
    });
  };

  const handleFollowToggle = async () => {
    if (!activeVideo) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/creators/${activeVideo.creatorId}/follow`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setIsFollowed(data.isFollowing);
        showToast(data.isFollowing ? 'Subscribed to creator channel!' : 'Unsubscribed');
      }
    } catch (e) {
      showToast('Error subscribing', 'error');
    }
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !activeVideo) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/videos/${activeVideo.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newComment.trim() })
      });
      if (res.ok) {
        const data = await res.json();
        setComments(prev => [data.comment, ...prev]);
        setNewComment('');
        showToast('Comment submitted');
      }
    } catch (e) {
      showToast('Error posting comment', 'error');
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const renderCommentText = (text: string) => {
    const timeRegex = /\b(\d{1,2}:\d{2})\b/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match;

    while ((match = timeRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(text.slice(lastIndex, match.index));
      }
      const timeStr = match[1];
      const [min, sec] = timeStr.split(':').map(Number);
      const totalSeconds = min * 60 + sec;

      parts.push(
        <button
          key={`${match.index}-${timeStr}`}
          type="button"
          onClick={() => {
            if (videoRef.current) {
              videoRef.current.currentTime = totalSeconds;
              setCurrentTime(totalSeconds);
              if (!isPlaying) togglePlay();
            }
          }}
          className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-violet-100 dark:bg-violet-900/60 text-violet-700 dark:text-violet-300 font-mono font-bold text-[10px] hover:bg-violet-200 transition mx-0.5 cursor-pointer"
        >
          {timeStr}
        </button>
      );
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < text.length) {
      parts.push(text.slice(lastIndex));
    }
    return parts.length > 0 ? parts : text;
  };

  const handleQuickRepost = async () => {
    if (!activeVideo) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/videos/${activeVideo.id}/repost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id })
      });
      const data = await res.json();
      if (data.success) {
        setIsReposted(data.isReposted);
        setRepostsCount(data.repostsCount);
        if (data.isReposted) {
          confetti({ particleCount: 35, spread: 60, origin: { y: 0.7 } });
          showToast('Reposted video to your channel profile!');
          if (data.repost) {
            setReposts(prev => [data.repost, ...prev]);
          }
        } else {
          showToast('Removed repost');
          setReposts(prev => prev.filter(r => r.userId !== currentUser.id));
        }
        setRepostModalOpen(false);
      }
    } catch (err) {
      showToast('Failed to update repost', 'error');
    }
  };

  const handleQuoteRepost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeVideo) return;
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    setIsSubmittingRepost(true);
    try {
      const res = await fetch(`/api/videos/${activeVideo.id}/repost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          quoteText: quoteText.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        setIsReposted(true);
        setRepostsCount(data.repostsCount);
        if (data.repost) {
          setReposts(prev => [data.repost, ...prev.filter(r => r.id !== data.repost.id)]);
        }
        confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
        showToast('Quote reposted to your channel profile!');
        setQuoteText('');
        setRepostModalOpen(false);
        setActiveEngagementTab('reposts');
      }
    } catch (err) {
      showToast('Failed to post quote repost', 'error');
    } finally {
      setIsSubmittingRepost(false);
    }
  };

  const handleSendSuperThanks = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (!activeVideo) return;
    try {
      setIsSendingThanks(true);
      const res = await fetch(`/api/videos/${activeVideo.id}/super-thanks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: thanksAmount,
          message: thanksMessage.trim() || `Sent a $${thanksAmount} Super Thanks!`
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
        showToast(`🎉 Super Thanks of $${thanksAmount.toFixed(2)} sent to ${activeVideo.creator.name}!`, 'success');
        if (data.comment) {
          setComments(prev => [data.comment, ...prev]);
        }
        setThanksModalOpen(false);
      } else {
        showToast(data.message || 'Failed to send Super Thanks', 'error');
      }
    } catch (err) {
      showToast('Error sending Super Thanks', 'error');
    } finally {
      setIsSendingThanks(false);
    }
  };

  const displayChapters = (activeVideo?.chapters && activeVideo.chapters.length > 0)
    ? activeVideo.chapters
    : [
        { timestamp: 0, title: 'Introduction & Structural Concept' },
        { timestamp: Math.floor((duration || 60) * 0.25), title: 'Detailed Analysis & System Architecture' },
        { timestamp: Math.floor((duration || 60) * 0.55), title: 'Technical Demonstration & Real-World Execution' },
        { timestamp: Math.floor((duration || 60) * 0.82), title: 'Engineering Takeaways & Quality Inspection' }
      ];

  if (!activeVideo) {
    return (
      <div className="text-center py-20">
        <p className="text-sm font-bold text-slate-500">No video selected.</p>
        <button onClick={() => setActiveView('home')} className="mt-4 clay-btn clay-btn-primary px-4 py-2 text-xs font-bold">
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-16">
      {/* Playlist Drawer */}
      <div className={`fixed inset-y-0 right-0 w-80 bg-white dark:bg-slate-900 shadow-2xl z-50 p-6 transition-transform ${isPlaylistDrawerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-extrabold text-lg text-slate-900 dark:text-slate-100">Your Playlists</h2>
          <button onClick={() => setIsPlaylistDrawerOpen(false)} className="text-slate-500">Close</button>
        </div>
        <div className="space-y-4">
          {playlists.map(p => (
            <button 
              key={p.id}
              onClick={() => p.videoIds.includes(activeVideo.id) ? removeVideoFromPlaylist(p.id, activeVideo.id) : addVideoToPlaylist(p.id, activeVideo.id)}
              className="w-full flex items-center justify-between p-3 clay-card hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              <span className="font-bold text-sm text-slate-900 dark:text-slate-100">{p.name}</span>
              {p.videoIds.includes(activeVideo.id) ? <CheckCircle className="w-5 h-5 text-violet-500" /> : <div className="w-5 h-5 border-2 border-slate-300 rounded-full" />}
            </button>
          ))}
          <button onClick={() => {
              const name = prompt('Playlist name:');
              if (name) createPlaylist(name);
          }} className="w-full mt-4 clay-btn clay-btn-secondary py-2 text-xs font-bold">
            Create New Playlist
          </button>
        </div>
      </div>
      
      {/* Top back button */}
      <button
        onClick={() => setActiveView('home')}
        className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to feed
      </button>

      {/* Playlist Queue Banner (if active) */}
      {currentPlaylistQueue && (
        <div className="clay-card p-3.5 bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-xl flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <ListVideo className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black tracking-wide">
                Playlist Queue: {currentPlaylistQueue.playlist.name}
              </p>
              <p className="text-[11px] text-white/80">
                Playing video {currentPlaylistQueue.currentIndex + 1} of {currentPlaylistQueue.playlist.videoIds.length}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={playPrevInPlaylist}
              disabled={currentPlaylistQueue.currentIndex === 0}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/25 disabled:opacity-30 transition"
              title="Previous Video in Playlist"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              onClick={playNextInPlaylist}
              disabled={currentPlaylistQueue.currentIndex === currentPlaylistQueue.playlist.videoIds.length - 1}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/25 disabled:opacity-30 transition"
              title="Next Video in Playlist"
            >
              <SkipForward className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPlaylistQueue(null)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/25 text-white/80 hover:text-white transition ml-2"
              title="Exit Playlist Mode"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Video Player, Metadata, Comments */}
        <div className="lg:col-span-2 space-y-5">
          {/* Custom Video Player Container with Ambient Mode */}
          <div className="relative">
            {ambientMode && (
              <div className="absolute -inset-3 rounded-[36px] bg-gradient-to-tr from-violet-600/30 via-indigo-600/20 to-purple-600/30 blur-2xl pointer-events-none -z-10 transition-opacity duration-300" />
            )}

            <div
              ref={containerRef}
              className="relative aspect-video rounded-3xl overflow-hidden bg-black shadow-2xl group border-2 border-slate-800"
            >
              <video
                ref={videoRef}
                key={activeVideo.id}
                src={activeVideo.videoUrl && !activeVideo.videoUrl.includes('commondatastorage.googleapis.com') ? activeVideo.videoUrl : '/api/media/stream/video1.mp4'}
                poster={activeVideo.thumbnailUrl}
                autoPlay
                playsInline
                loop={isLooping}
                onClick={() => {
                  if (isScreenLocked) {
                    setShowUnlockPill(true);
                  } else {
                    togglePlay();
                  }
                }}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => {
                  if (isLooping) return;
                  setIsPlaying(false);
                  if (currentPlaylistQueue) {
                    playNextInPlaylist();
                  } else if (isAutoplay && relatedVideos.length > 0) {
                    setActiveVideo(relatedVideos[0]);
                  }
                }}
                className="w-full h-full object-cover cursor-pointer"
                onError={(e) => {
                  console.warn('Watch video stream notice, recovering with stream accelerator:', e);
                  if (videoRef.current && !videoRef.current.src.endsWith('/video1.mp4')) {
                    videoRef.current.src = '/api/media/stream/video1.mp4';
                    videoRef.current.load();
                    videoRef.current.play().catch(() => {});
                  }
                }}
              />

              {/* Subtitle Overlay */}
              {showCC && activeVideo.subtitles && (
                <div className="absolute bottom-16 inset-x-4 flex justify-center pointer-events-none z-20">
                  <div className="px-4 py-2 bg-black/80 backdrop-blur-md rounded-xl text-white font-bold text-base text-center shadow-lg border border-white/20 max-w-xl">
                    {activeVideo.subtitles.find(s => currentTime >= s.startTime && currentTime <= s.endTime)?.text || ''}
                  </div>
                </div>
              )}

              {/* Top Header Controls (Title + CC + Settings) */}
              {!isScreenLocked && (
                <div className="absolute inset-x-0 top-0 p-3 bg-gradient-to-b from-black/85 via-black/40 to-transparent flex items-center justify-between z-20 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-xs font-bold text-white/90 truncate max-w-[60%] drop-shadow">
                    {activeVideo.title}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowCC(!showCC);
                        showToast(showCC ? 'Captions turned off' : 'Captions turned on');
                      }}
                      className={`px-2 py-1 rounded-md text-[11px] font-black transition ${
                        showCC ? 'bg-white text-black' : 'bg-black/50 text-white hover:bg-black/70'
                      }`}
                      title="Captions"
                    >
                      CC
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSettingsSubmenu('root');
                        setIsSettingsOpen(true);
                      }}
                      className="p-1.5 rounded-full bg-black/50 hover:bg-black/70 text-white transition active:scale-95"
                      title="Settings"
                    >
                      <Settings className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Stats For Nerds HUD Overlay */}
              {statsForNerds && (
                <div className="absolute top-3 left-3 z-30 p-3 rounded-2xl bg-[#161616]/95 text-white font-mono text-[10px] space-y-1 backdrop-blur-md border border-white/20 max-w-xs shadow-2xl animate-in fade-in">
                  <div className="flex items-center justify-between pb-1 border-b border-white/20">
                    <span className="font-bold text-amber-400 flex items-center gap-1">
                      <Activity className="w-3.5 h-3.5" /> Stats for nerds
                    </span>
                    <button onClick={() => setStatsForNerds(false)} className="text-white/60 hover:text-white">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p><span className="text-white/50">Video ID:</span> {activeVideo.id.slice(0, 14)}</p>
                  <p><span className="text-white/50">Quality / FPS:</span> {selectedQuality}</p>
                  <p><span className="text-white/50">Viewport:</span> 1280x720 / 60fps</p>
                  <p><span className="text-white/50">Codecs:</span> vp09.02.51.10.01 / opus</p>
                  <p><span className="text-white/50">Speed / Loop:</span> {playbackSpeed}x / {isLooping ? 'On' : 'Off'}</p>
                  <p><span className="text-white/50">Connection:</span> 48.6 Mbps (Optimal)</p>
                  <p><span className="text-white/50">Buffer Health:</span> {(duration ? Math.min(26.4, duration - currentTime).toFixed(2) : 24.12)} s</p>
                </div>
              )}

              {/* Screen Locked Floating Unlock Pill */}
              {isScreenLocked && (
                <div
                  onClick={() => setShowUnlockPill(true)}
                  className="absolute inset-0 z-30 flex flex-col items-center justify-start pt-6 cursor-pointer bg-transparent"
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsScreenLocked(false);
                      setShowUnlockPill(false);
                      showToast('Screen unlocked');
                    }}
                    className="px-5 py-2.5 rounded-full bg-[#212121]/95 text-white border border-white/25 shadow-2xl flex items-center gap-2 text-xs font-bold hover:bg-neutral-800 active:scale-95 transition backdrop-blur-md"
                  >
                    <Lock className="w-4 h-4 text-white" />
                    <span>Screen locked • Tap to unlock</span>
                  </button>
                </div>
              )}

              {/* Custom Control Bar Overlay */}
              {!isScreenLocked && (
                <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/95 via-black/60 to-transparent transition-opacity duration-200 flex flex-col gap-2 opacity-90 group-hover:opacity-100 z-10">
                  {/* Scrubber Range and Chapter Markers */}
                  {duration > 0 && (
                    <div className="relative w-full h-1.5 mb-1 flex items-center pointer-events-none">
                      {displayChapters.map((chapter, index) => {
                        const left = Math.min((chapter.timestamp / duration) * 100, 100);
                        return (
                          <button
                            key={index}
                            className="absolute h-3 w-1 bg-white hover:bg-violet-400 cursor-pointer pointer-events-auto rounded-full z-10 transition-transform hover:scale-150"
                            style={{ left: `${left}%` }}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (videoRef.current) {
                                videoRef.current.currentTime = chapter.timestamp;
                                setCurrentTime(chapter.timestamp);
                              }
                            }}
                            title={`${formatTime(chapter.timestamp)} - ${chapter.title}`}
                          />
                        );
                      })}
                    </div>
                  )}
                  <input
                    type="range"
                    min="0"
                    max={duration || 100}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-1.5 bg-white/30 rounded-lg appearance-none cursor-pointer accent-violet-500"
                  />

                  <div className="flex items-center justify-between text-white text-xs">
                    {/* Left Controls: Play/Pause, Volume, Time */}
                    <div className="flex items-center gap-3">
                      <button onClick={togglePlay} className="p-1 text-white hover:text-violet-400 transition">
                        {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                      </button>

                      <div className="flex items-center gap-1.5 group/vol">
                        <button onClick={toggleMute} className="p-1 hover:text-violet-400">
                          {isMuted || volume === 0 ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5" />}
                        </button>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={isMuted ? 0 : volume}
                          onChange={handleVolumeChange}
                          className="w-16 h-1 bg-white/40 rounded appearance-none cursor-pointer accent-violet-400"
                        />
                      </div>

                      <span className="text-[11px] font-mono text-slate-300">
                        {formatTime(currentTime)} / {formatTime(duration)}
                      </span>
                    </div>

                    {/* Right Controls: CC, Settings (YouTube sheet), Speed, PiP, Fullscreen */}
                    <div className="flex items-center gap-2 relative">
                      <button
                        onClick={() => {
                          setShowCC(!showCC);
                          showToast(showCC ? 'Captions turned off' : 'Captions turned on');
                        }}
                        className={`px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold ${showCC ? 'text-violet-400' : 'text-white'}`}
                      >
                        CC
                      </button>

                      {/* YouTube Settings Gear Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSettingsSubmenu('root');
                          setIsSettingsOpen(true);
                        }}
                        className="p-1 text-white hover:text-violet-400 transition"
                        title="Settings"
                      >
                        <Settings className="w-5 h-5" />
                      </button>

                      <button
                        onClick={() => {
                          setSettingsSubmenu('speed');
                          setIsSettingsOpen(true);
                        }}
                        className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold"
                        title="Playback speed"
                      >
                        {playbackSpeed === 1 ? '1x' : `${playbackSpeed}x`}
                      </button>

                      {/* Picture-in-Picture Mini-Player Minimize Button */}
                      <button
                        onClick={() => {
                          openInMiniPlayer(activeVideo);
                          setActiveView('home');
                        }}
                        title="Minimize to Floating PiP Player"
                        className="p-1 text-white hover:text-violet-400 transition"
                      >
                        <PictureInPicture className="w-5 h-5" />
                      </button>

                      <button onClick={toggleFullscreen} className="p-1 hover:text-violet-400">
                        {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* YouTube-Style Settings Bottom Sheet */}
              {isSettingsOpen && (
                <div
                  onClick={() => setIsSettingsOpen(false)}
                  className="absolute inset-0 z-50 bg-black/60 backdrop-blur-[2px] flex flex-col justify-end transition-opacity duration-200"
                >
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="w-full bg-[#212121] text-white rounded-t-3xl border-t border-white/10 shadow-2xl p-4 pt-2 pb-5 max-h-[85%] overflow-y-auto animate-in slide-in-from-bottom duration-200"
                  >
                    {/* Top drag pill handle */}
                    <div className="w-10 h-1 bg-neutral-600 rounded-full mx-auto mb-2" />

                    {/* ROOT MENU (Exact YouTube UI from Screenshot) */}
                    {settingsSubmenu === 'root' && (
                      <div className="space-y-1">
                        {/* Quality */}
                        <button
                          onClick={() => setSettingsSubmenu('quality')}
                          className="w-full flex items-center justify-between px-3 py-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition text-left group"
                        >
                          <div className="flex items-center gap-4">
                            <SlidersHorizontal className="w-6 h-6 text-white stroke-[1.8]" />
                            <span className="text-base font-normal text-white">Quality</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-neutral-400 group-hover:text-neutral-200">
                            <span className="text-sm font-normal text-neutral-300">{selectedQuality}</span>
                            <ChevronRight className="w-4 h-4 text-neutral-400" />
                          </div>
                        </button>

                        {/* Playback speed */}
                        <button
                          onClick={() => setSettingsSubmenu('speed')}
                          className="w-full flex items-center justify-between px-3 py-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition text-left group"
                        >
                          <div className="flex items-center gap-4">
                            <Gauge className="w-6 h-6 text-white stroke-[1.8]" />
                            <span className="text-base font-normal text-white">Playback speed</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-neutral-400 group-hover:text-neutral-200">
                            <span className="text-sm font-normal text-neutral-300">
                              {playbackSpeed === 1 ? '1x' : `${playbackSpeed}x`}
                            </span>
                            <ChevronRight className="w-4 h-4 text-neutral-400" />
                          </div>
                        </button>

                        {/* Captions */}
                        <button
                          onClick={() => setSettingsSubmenu('captions')}
                          className="w-full flex items-center justify-between px-3 py-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition text-left group"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-6 h-5 rounded border-[1.8px] border-white flex items-center justify-center text-[10px] font-black text-white leading-none">
                              CC
                            </div>
                            <span className="text-base font-normal text-white">Captions</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-neutral-400 group-hover:text-neutral-200">
                            <span className="text-sm font-normal text-neutral-300">
                              {showCC ? selectedCaptionLang.split(' ')[0] : 'Off'}
                            </span>
                            <ChevronRight className="w-4 h-4 text-neutral-400" />
                          </div>
                        </button>

                        {/* Lock screen */}
                        <button
                          onClick={() => {
                            setIsScreenLocked(true);
                            setIsSettingsOpen(false);
                            setShowUnlockPill(true);
                            showToast('Screen locked • Tap to unlock');
                          }}
                          className="w-full flex items-center justify-between px-3 py-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition text-left group"
                        >
                          <div className="flex items-center gap-4">
                            <Lock className="w-6 h-6 text-white stroke-[1.8]" />
                            <span className="text-base font-normal text-white">Lock screen</span>
                          </div>
                        </button>

                        {/* More */}
                        <button
                          onClick={() => setSettingsSubmenu('more')}
                          className="w-full flex items-center justify-between px-3 py-3 rounded-2xl hover:bg-white/10 active:bg-white/15 transition text-left group"
                        >
                          <div className="flex items-center gap-4">
                            <Settings className="w-6 h-6 text-white stroke-[1.8]" />
                            <span className="text-base font-normal text-white">More</span>
                          </div>
                          <ChevronRight className="w-5 h-5 text-neutral-400" />
                        </button>
                      </div>
                    )}

                    {/* SUBMENU: QUALITY */}
                    {settingsSubmenu === 'quality' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-3 px-1 py-1 border-b border-white/10 mb-2">
                          <button
                            onClick={() => setSettingsSubmenu('root')}
                            className="p-1 rounded-full hover:bg-white/10 text-white"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <h4 className="text-base font-semibold text-white">Quality</h4>
                        </div>
                        <p className="px-3 text-xs text-neutral-400">
                          Current video: <span className="text-white font-medium">{selectedQuality}</span>
                        </p>

                        <div className="space-y-1">
                          {[
                            { name: 'Auto (1080p60)', desc: 'Adjusts to give you the best experience' },
                            { name: 'Higher picture quality (1080p60 HD)', desc: 'Uses more data' },
                            { name: 'Data saver (480p)', desc: 'Lower picture quality' },
                            { name: '1080p60 Full HD', desc: 'Highest crisp quality' },
                            { name: '720p60 HD', desc: 'Smooth high definition' },
                            { name: '480p SD', desc: 'Standard definition' },
                            { name: '360p', desc: 'Fast loading' },
                            { name: '240p', desc: 'Data-efficient' },
                          ].map((q) => {
                            const isSelected = selectedQuality === q.name || (selectedQuality === 'Auto (1080p60)' && q.name === 'Auto (1080p60)');
                            return (
                              <button
                                key={q.name}
                                onClick={() => {
                                  setSelectedQuality(q.name);
                                  showToast(`Video quality set to ${q.name}`);
                                  setIsSettingsOpen(false);
                                }}
                                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition text-left"
                              >
                                <div>
                                  <p className="text-sm font-medium text-white">{q.name}</p>
                                  <p className="text-[11px] text-neutral-400">{q.desc}</p>
                                </div>
                                {isSelected && <Check className="w-4 h-4 text-white" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* SUBMENU: PLAYBACK SPEED */}
                    {settingsSubmenu === 'speed' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-3 px-1 py-1 border-b border-white/10 mb-2">
                          <button
                            onClick={() => setSettingsSubmenu('root')}
                            className="p-1 rounded-full hover:bg-white/10 text-white"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <h4 className="text-base font-semibold text-white">Playback speed</h4>
                        </div>

                        <div className="space-y-1">
                          {[
                            { speed: 0.25, label: '0.25x' },
                            { speed: 0.5, label: '0.5x' },
                            { speed: 0.75, label: '0.75x' },
                            { speed: 1, label: 'Normal (1x)' },
                            { speed: 1.25, label: '1.25x' },
                            { speed: 1.5, label: '1.5x' },
                            { speed: 1.75, label: '1.75x' },
                            { speed: 2, label: '2x' },
                          ].map((item) => (
                            <button
                              key={item.speed}
                              onClick={() => {
                                handleSpeedChange(item.speed);
                                setIsSettingsOpen(false);
                              }}
                              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition text-left"
                            >
                              <span className="text-sm font-medium text-white">{item.label}</span>
                              {playbackSpeed === item.speed && <Check className="w-4 h-4 text-white" />}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* SUBMENU: CAPTIONS */}
                    {settingsSubmenu === 'captions' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-3 px-1 py-1 border-b border-white/10 mb-2">
                          <button
                            onClick={() => setSettingsSubmenu('root')}
                            className="p-1 rounded-full hover:bg-white/10 text-white"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <h4 className="text-base font-semibold text-white">Captions</h4>
                        </div>

                        <div className="space-y-1">
                          <button
                            onClick={() => {
                              setShowCC(false);
                              showToast('Captions turned off');
                              setIsSettingsOpen(false);
                            }}
                            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition text-left"
                          >
                            <span className="text-sm font-medium text-white">Turn off captions</span>
                            {!showCC && <Check className="w-4 h-4 text-white" />}
                          </button>

                          {[
                            'English (auto-generated)',
                            'Arabic (auto-translated)',
                            'Spanish (auto-translated)',
                            'Urdu (auto-translated)',
                            'French (auto-translated)',
                          ].map((lang) => (
                            <button
                              key={lang}
                              onClick={() => {
                                setShowCC(true);
                                setSelectedCaptionLang(lang);
                                showToast(`Captions set to ${lang}`);
                                setIsSettingsOpen(false);
                              }}
                              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition text-left"
                            >
                              <span className="text-sm font-medium text-white">{lang}</span>
                              {showCC && selectedCaptionLang === lang && <Check className="w-4 h-4 text-white" />}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* SUBMENU: MORE */}
                    {settingsSubmenu === 'more' && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 px-1 py-1 border-b border-white/10 mb-2">
                          <button
                            onClick={() => setSettingsSubmenu('root')}
                            className="p-1 rounded-full hover:bg-white/10 text-white"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <h4 className="text-base font-semibold text-white">More options</h4>
                        </div>

                        <div className="space-y-2">
                          {/* Loop */}
                          <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 transition">
                            <div className="flex items-center gap-3">
                              <Repeat className="w-5 h-5 text-neutral-300" />
                              <div>
                                <p className="text-sm font-medium text-white">Loop video</p>
                                <p className="text-[11px] text-neutral-400">Replays continuously</p>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                const next = !isLooping;
                                setIsLooping(next);
                                showToast(next ? 'Looping enabled' : 'Looping disabled');
                              }}
                              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                                isLooping ? 'bg-violet-600 justify-end' : 'bg-neutral-600 justify-start'
                              }`}
                            >
                              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                            </button>
                          </div>

                          {/* Ambient mode */}
                          <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 transition">
                            <div className="flex items-center gap-3">
                              <Sun className="w-5 h-5 text-neutral-300" />
                              <div>
                                <p className="text-sm font-medium text-white">Ambient mode</p>
                                <p className="text-[11px] text-neutral-400">Glow effect around player</p>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                const next = !ambientMode;
                                setAmbientMode(next);
                                showToast(next ? 'Ambient mode enabled' : 'Ambient mode disabled');
                              }}
                              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                                ambientMode ? 'bg-violet-600 justify-end' : 'bg-neutral-600 justify-start'
                              }`}
                            >
                              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                            </button>
                          </div>

                          {/* Stable volume */}
                          <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 transition">
                            <div className="flex items-center gap-3">
                              <Volume1 className="w-5 h-5 text-neutral-300" />
                              <div>
                                <p className="text-sm font-medium text-white">Stable volume</p>
                                <p className="text-[11px] text-neutral-400">Balances loud & quiet scenes</p>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                const next = !stableVolume;
                                setStableVolume(next);
                                showToast(next ? 'Stable volume enabled' : 'Stable volume disabled');
                              }}
                              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                                stableVolume ? 'bg-violet-600 justify-end' : 'bg-neutral-600 justify-start'
                              }`}
                            >
                              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                            </button>
                          </div>

                          {/* Stats for nerds */}
                          <div className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/5 transition">
                            <div className="flex items-center gap-3">
                              <Activity className="w-5 h-5 text-neutral-300" />
                              <div>
                                <p className="text-sm font-medium text-white">Stats for nerds</p>
                                <p className="text-[11px] text-neutral-400">Video technical metrics overlay</p>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                const next = !statsForNerds;
                                setStatsForNerds(next);
                                setIsSettingsOpen(false);
                                showToast(next ? 'Stats for nerds enabled' : 'Stats disabled');
                              }}
                              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                                statsForNerds ? 'bg-violet-600 justify-end' : 'bg-neutral-600 justify-start'
                              }`}
                            >
                              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                            </button>
                          </div>

                          {/* Report */}
                          <button
                            onClick={() => {
                              setIsSettingsOpen(false);
                              setReportTarget({
                                type: 'video',
                                id: activeVideo.id,
                                title: activeVideo.title
                              });
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition text-left text-rose-400"
                          >
                            <ShieldAlert className="w-5 h-5" />
                            <span className="text-sm font-medium">Report this video</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Viewer Engagement Reaction Bar (Animated Emojis: Like, Laugh, Fire, Mindblown, etc.) */}
          <VideoReactionBar videoId={activeVideo.id} videoTitle={activeVideo.title} />

          {/* Interactive Video Chapters Card */}
          <div className="clay-card p-4 bg-white dark:bg-[#181D2E] border border-slate-200/60 dark:border-slate-800 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-violet-500" />
                <h3 className="text-xs font-black text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  Video Chapters & Key Moments ({displayChapters.length})
                </h3>
              </div>
              <span className="text-[10px] text-slate-400">Click any moment to jump</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {displayChapters.map((chapter, index) => {
                const isCurrent =
                  currentTime >= chapter.timestamp &&
                  (index === displayChapters.length - 1 || currentTime < displayChapters[index + 1].timestamp);

                return (
                  <button
                    key={index}
                    onClick={() => {
                      if (videoRef.current) {
                        videoRef.current.currentTime = chapter.timestamp;
                        setCurrentTime(chapter.timestamp);
                        if (!isPlaying) togglePlay();
                      }
                    }}
                    className={`flex items-center justify-between text-xs p-2.5 rounded-2xl transition text-left ${
                      isCurrent
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-500/20 font-black'
                        : 'bg-slate-50 dark:bg-slate-900/40 text-slate-700 dark:text-slate-300 hover:bg-violet-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span className="truncate pr-2">{chapter.title}</span>
                    <span
                      className={`font-mono text-[11px] px-2 py-0.5 rounded-md flex-shrink-0 font-bold ${
                        isCurrent
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {formatTime(chapter.timestamp)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Video Title */}
          <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {activeVideo.title}
          </h1>

          {/* Action Row & Creator Details */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200/60 dark:border-slate-800/80">
            {/* Channel Info */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setActiveProfileUsername(activeVideo.creator.username);
                  setActiveView('profile');
                }}
                className="flex-shrink-0"
              >
                <img
                  src={activeVideo.creator.avatar}
                  alt={activeVideo.creator.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-violet-400 shadow-sm"
                />
              </button>

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                    {activeVideo.creator.name}
                  </span>
                  {activeVideo.creator.verified && <VerifiedBadge size={16} />}
                </div>
                <span className="text-xs text-slate-400">@{activeVideo.creator.username}</span>
              </div>

              <button
                onClick={handleFollowToggle}
                className={`ml-3 px-4 py-2 rounded-2xl text-xs font-bold transition active:scale-95 ${
                  isFollowed
                    ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    : 'clay-btn clay-btn-primary'
                }`}
              >
                {isFollowed ? 'Subscribed' : 'Subscribe'}
              </button>
            </div>

            {/* Interaction Buttons (Like, Dislike, Share, Report) */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center clay-card rounded-2xl p-1 bg-white dark:bg-slate-800">
                <button
                  onClick={handleLike}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition ${
                    isLiked
                      ? 'text-violet-600 dark:text-violet-400 font-extrabold bg-violet-50 dark:bg-violet-950/40'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                  <span>{likesCount.toLocaleString()}</span>
                </button>
                <div className="w-[1px] h-4 bg-slate-200 dark:bg-slate-700 mx-1" />
                <button
                  onClick={() => {
                    setDisliked(!disliked);
                    if (!disliked) setIsLiked(false);
                  }}
                  className={`p-1.5 rounded-xl transition ${
                    disliked ? 'text-rose-500 bg-rose-50 dark:bg-rose-950/40' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                  title="Dislike"
                >
                  <ThumbsDown className="w-4 h-4" />
                </button>
              </div>

              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  showToast('Video link copied to clipboard!');
                }}
                className="clay-btn clay-btn-secondary px-3.5 py-2 text-xs font-bold gap-1.5"
              >
                <Share2 className="w-4 h-4" />
                Share
              </button>

              <button
                onClick={() => {
                  if (!currentUser) {
                    setAuthModalOpen(true);
                    return;
                  }
                  setRepostModalOpen(true);
                }}
                className={`clay-btn px-3.5 py-2 text-xs font-bold gap-1.5 transition ${
                  isReposted
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border-emerald-300 dark:border-emerald-700'
                    : 'clay-btn-secondary'
                }`}
                title="Repost video"
              >
                <Repeat2 className={`w-4 h-4 ${isReposted ? 'stroke-[2.5] text-emerald-600 dark:text-emerald-400' : ''}`} />
                <span>{repostsCount > 0 ? `${repostsCount} Repost${repostsCount > 1 ? 's' : ''}` : 'Repost'}</span>
              </button>

              {/* Super Thanks ($) Creator Tip Button */}
              <button
                onClick={() => {
                  if (!currentUser) {
                    setAuthModalOpen(true);
                    return;
                  }
                  setThanksModalOpen(true);
                }}
                className="clay-btn px-3.5 py-2 text-xs font-bold gap-1.5 bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 hover:from-amber-500/20 hover:to-orange-500/20 transition active:scale-95"
                title="Send Super Thanks tip to creator"
              >
                <HeartHandshake className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>Thanks ($)</span>
              </button>
              
              <button
                onClick={() => toggleBookmark(activeVideo.id)}
                className={`clay-btn px-3.5 py-2 text-xs font-bold gap-1.5 ${bookmarkedVideoIds.includes(activeVideo.id) ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 border-amber-200' : 'clay-btn-secondary'}`}
              >
                <Bookmark className={`w-4 h-4 ${bookmarkedVideoIds.includes(activeVideo.id) ? 'fill-current' : ''}`} />
                {bookmarkedVideoIds.includes(activeVideo.id) ? 'Bookmarked' : 'Bookmark'}
              </button>

              <button
                onClick={() =>
                  setReportTarget({
                    type: 'video',
                    id: activeVideo.id,
                    title: activeVideo.title
                  })
                }
                className="p-2 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                title="Report Video"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-200/60 dark:border-slate-800/80">
              {Object.entries(videoReactions).map(([emoji, count]) => (
                <button
                  key={emoji}
                  onClick={() => handleEmojiReaction(emoji)}
                  className="clay-card p-2 rounded-xl hover:scale-110 transition flex items-center gap-1 text-xs bg-white dark:bg-slate-800"
                >
                  <span className="text-base">{emoji}</span>
                  <span className="font-bold text-slate-600 dark:text-slate-400">{count}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Video Description Accordion */}
          <div className="clay-card p-4 bg-slate-50/70 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800">
            <div className="flex items-center gap-4 text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                {activeVideo.views.toLocaleString()} views
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {new Date(activeVideo.createdAt).toLocaleDateString()}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-[10px]">
                {activeVideo.category}
              </span>
            </div>

            <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed">
              {activeVideo.description}
            </p>

            <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800">
              {activeVideo.tags.map((t) => (
                <span 
                  key={t} 
                  className="px-3 py-1 rounded-full text-[11px] font-bold text-violet-700 dark:text-violet-300 bg-violet-100/50 dark:bg-violet-900/30 hover:bg-violet-200 dark:hover:bg-violet-800 cursor-pointer transition"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Shoppable Products in this Video */}
          {featuredProducts.length > 0 && (
            <div className="clay-card p-4 sm:p-5 bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-rose-500/5 border border-amber-300/60 dark:border-amber-700/50 rounded-3xl space-y-3.5 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-amber-500/25">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                      <span>Featured Store Products in this Video</span>
                      <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-900 text-[9px] font-black uppercase tracking-wider">
                        SHOP
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Creator verified gear, demonstrated tools, and official merchandise
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => openStore()}
                  className="text-xs font-black text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 flex items-center gap-1 transition px-2.5 py-1 rounded-xl hover:bg-amber-100/60 dark:hover:bg-amber-950/40"
                >
                  <span>Explore Marketplace</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {featuredProducts.map((prod) => {
                  const inWish = isInWishlist(prod.id);
                  return (
                    <div
                      key={prod.id}
                      className="clay-card p-3 rounded-2xl bg-white/95 dark:bg-[#181D2E]/95 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between group hover:border-amber-400 transition"
                    >
                      <div className="space-y-2">
                        <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900">
                          <img
                            src={prod.thumbnailUrl}
                            alt={prod.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleWishlist(prod.id);
                            }}
                            className="absolute top-1.5 right-1.5 p-1 rounded-lg bg-black/50 text-white hover:text-rose-400 backdrop-blur-sm transition active:scale-90"
                            title={inWish ? 'Remove from wishlist' : 'Save to wishlist'}
                          >
                            <Heart className={`w-3.5 h-3.5 ${inWish ? 'fill-rose-500 text-rose-500' : ''}`} />
                          </button>
                          <span className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-black/70 text-white text-[9px] font-bold">
                            {prod.categoryName.split('&')[0].trim()}
                          </span>
                        </div>

                        <h4 className="text-xs font-black text-slate-900 dark:text-slate-100 line-clamp-1" title={prod.title}>
                          {prod.title}
                        </h4>
                        <p className="text-[10px] text-slate-400 truncate">by {prod.brand || prod.sellerName}</p>
                      </div>

                      <div className="pt-2 mt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                        <div>
                          <span className="text-xs font-black text-amber-600 dark:text-amber-400">
                            ${prod.price.toFixed(2)}
                          </span>
                          <span className="text-[9px] text-slate-400 block font-semibold">
                            ≈ SAR {(prod.price * 3.75).toFixed(0)}
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            addToCart(prod, 1);
                            setIsCartOpen(true);
                          }}
                          className="clay-btn bg-amber-500 hover:bg-amber-600 text-white px-2.5 py-1.5 rounded-xl text-[10px] font-black flex items-center gap-1 shadow-sm active:scale-95 transition"
                          title="Add to shopping cart"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Buy</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Engagement Section: Comments & Reposts Tabs */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
              <button
                onClick={() => setActiveEngagementTab('comments')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition ${
                  activeEngagementTab === 'comments'
                    ? 'bg-violet-600 text-white shadow-sm shadow-violet-500/20'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>Comments</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  activeEngagementTab === 'comments' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}>
                  {comments.length}
                </span>
              </button>

              <button
                onClick={() => setActiveEngagementTab('reposts')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition ${
                  activeEngagementTab === 'reposts'
                    ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-500/20'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Repeat2 className="w-4 h-4" />
                <span>Reposts</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  activeEngagementTab === 'reposts' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}>
                  {repostsCount}
                </span>
              </button>

              <div className="ml-auto">
                <button
                  onClick={() => {
                    if (!currentUser) {
                      setAuthModalOpen(true);
                      return;
                    }
                    setRepostModalOpen(true);
                  }}
                  className="clay-btn clay-btn-primary px-3 py-1.5 text-[11px] font-bold gap-1 inline-flex items-center"
                >
                  <Repeat2 className="w-3.5 h-3.5" />
                  {isReposted ? 'Manage Repost' : 'Repost Video'}
                </button>
              </div>
            </div>

            {/* Comments Tab Panel */}
            {activeEngagementTab === 'comments' && (
              <div className="space-y-4">
                {/* Comment Form */}
                <form onSubmit={handlePostComment} className="space-y-2">
                  <div className="flex gap-3">
                    <img
                      src={currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'}
                      alt={currentUser?.name || 'User'}
                      className="w-9 h-9 rounded-full object-cover border border-slate-200 flex-shrink-0"
                    />
                    <div className="flex-1 flex gap-2">
                      <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder={currentUser ? 'Add a thoughtful comment (e.g. "Check the seal at 0:45!")...' : 'Sign in to join the conversation'}
                        className="flex-1 px-4 py-2 text-xs clay-input"
                      />
                      <button
                        type="submit"
                        disabled={!newComment.trim()}
                        className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold gap-1 disabled:opacity-40"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Post
                      </button>
                    </div>
                  </div>

                  {/* Timestamp chip inserter */}
                  <div className="flex items-center gap-2 pl-12">
                    <span className="text-[10px] text-slate-400">Quick insert:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const tag = `${formatTime(currentTime)} `;
                        setNewComment(prev => prev ? `${prev} ${tag}` : tag);
                      }}
                      className="px-2 py-0.5 rounded-md bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 font-mono text-[10px] font-bold hover:bg-violet-200 transition flex items-center gap-1"
                    >
                      <Clock className="w-3 h-3" />
                      + At {formatTime(currentTime)}
                    </button>
                  </div>
                </form>

                {/* Comments List */}
                <div className="space-y-3 pt-2">
                  {comments.length === 0 ? (
                    <div className="text-center py-8 clay-card bg-white/50 dark:bg-slate-900/30">
                      <MessageSquare className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                      <p className="text-xs text-slate-500 font-medium">No comments yet. Start the engineering discussion!</p>
                    </div>
                  ) : (
                    comments.map((comment) => (
                      <div key={comment.id} className="clay-card p-3 bg-white/70 dark:bg-slate-900/40 flex gap-3">
                        <img
                          src={comment.user.avatar}
                          alt={comment.user.name}
                          className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                        />
                        <div className="flex-1 text-xs">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-slate-900 dark:text-slate-100">
                                {comment.user.name}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                @{comment.user.username}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {new Date(comment.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="text-slate-700 dark:text-slate-300 mt-1 leading-snug">
                            {renderCommentText(comment.text)}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Reposts Tab Panel */}
            {activeEngagementTab === 'reposts' && (
              <div className="space-y-3">
                {reposts.length === 0 ? (
                  <div className="text-center py-10 clay-card bg-white/60 dark:bg-slate-900/40 border border-dashed border-slate-300 dark:border-slate-700 rounded-2xl">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
                      <Repeat2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">No reposts yet</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1 mb-4">
                      Be the first engineer to repost this video to your profile with your technical insights!
                    </p>
                    <button
                      onClick={() => {
                        if (!currentUser) {
                          setAuthModalOpen(true);
                          return;
                        }
                        setRepostModalOpen(true);
                      }}
                      className="clay-btn clay-btn-primary px-4 py-2 text-xs font-bold gap-1.5 inline-flex items-center"
                    >
                      <Repeat2 className="w-4 h-4" />
                      Repost this Video
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {reposts.map((rp) => (
                      <div key={rp.id} className="clay-card p-3.5 bg-white/80 dark:bg-slate-900/50 space-y-2.5 border border-slate-200/80 dark:border-slate-800">
                        <div className="flex items-center justify-between">
                          <div
                            onClick={() => {
                              setActiveProfileUsername(rp.user.username);
                              setActiveView('profile');
                            }}
                            className="flex items-center gap-2 cursor-pointer group"
                          >
                            <img
                              src={rp.user.avatar}
                              alt={rp.user.name}
                              className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition"
                            />
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-xs text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 transition">
                                  {rp.user.name}
                                </span>
                                {rp.user.verified && <VerifiedBadge />}
                                <span className="text-[10px] text-slate-400">@{rp.user.username}</span>
                              </div>
                              <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                                <Repeat2 className="w-3 h-3" />
                                Reposted video
                              </p>
                            </div>
                          </div>

                          <span className="text-[10px] text-slate-400">
                            {new Date(rp.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        {rp.quoteText ? (
                          <div className="pl-10">
                            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border-l-4 border-emerald-500 text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                              "{rp.quoteText}"
                            </div>
                          </div>
                        ) : (
                          <div className="pl-10">
                            <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg">
                              <Repeat2 className="w-3 h-3 text-emerald-500" />
                              Direct repost to profile
                            </span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Related Videos Rail */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
              Related Engineering & Tech Videos
            </h3>
          </div>

          <div className="space-y-3">
            {relatedVideos.map((vid) => (
              <div
                key={vid.id}
                onClick={() => {
                  setActiveVideo(vid);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="clay-card p-2 flex gap-3 cursor-pointer group hover:border-violet-400 transition"
              >
                <div className="relative w-36 aspect-video rounded-xl overflow-hidden bg-slate-900 flex-shrink-0">
                  <img
                    src={vid.thumbnailUrl}
                    alt={vid.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-black/80 text-white">
                    {vid.duration}
                  </span>
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-2 leading-tight group-hover:text-violet-600 transition-colors">
                    {vid.title}
                  </h4>
                  <div className="text-[10px] text-slate-400 mt-1">
                    <p className="truncate">{vid.creator.name}</p>
                    <p>{vid.views.toLocaleString()} views</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Repost Modal */}
      {repostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="clay-card bg-white dark:bg-slate-900 max-w-lg w-full p-6 space-y-4 shadow-2xl relative border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setRepostModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Repeat2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Repost Video
                </h3>
                <p className="text-xs text-slate-500">
                  Share this engineering video with your network and followers
                </p>
              </div>
            </div>

            {/* Video preview miniature */}
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex gap-3 items-center">
              <img
                src={activeVideo.thumbnailUrl}
                alt={activeVideo.title}
                className="w-20 aspect-video rounded-lg object-cover flex-shrink-0"
              />
              <div className="min-w-0 flex-1">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                  {activeVideo.title}
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  by {activeVideo.creator.name} • {activeVideo.views.toLocaleString()} views
                </p>
              </div>
            </div>

            {/* Quick 1-click repost option */}
            <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-extrabold text-emerald-900 dark:text-emerald-200">
                  {isReposted ? 'Currently Reposted' : 'Instant Repost'}
                </p>
                <p className="text-[11px] text-emerald-700/80 dark:text-emerald-400">
                  {isReposted ? 'Click to undo your repost from your profile' : '1-click share directly to your profile and followers'}
                </p>
              </div>
              <button
                onClick={handleQuickRepost}
                className={`clay-btn px-3 py-1.5 text-xs font-bold gap-1.5 ${
                  isReposted
                    ? 'bg-rose-100 text-rose-700 hover:bg-rose-200 dark:bg-rose-950/60 dark:text-rose-300'
                    : 'bg-emerald-600 text-white hover:bg-emerald-700'
                }`}
              >
                <Repeat2 className="w-3.5 h-3.5" />
                {isReposted ? 'Undo Repost' : 'Repost Now'}
              </button>
            </div>

            {/* Quote Repost section */}
            <form onSubmit={handleQuoteRepost} className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                Or Add Your Technical Commentary (Quote Repost)
              </label>
              <textarea
                value={quoteText}
                onChange={(e) => setQuoteText(e.target.value)}
                placeholder="Share your technical opinion, highlight a specific timestamp, or ask a question to your network..."
                className="w-full h-24 px-3 py-2 text-xs clay-input resize-none"
                maxLength={400}
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>{quoteText.length}/400 characters</span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRepostModalOpen(false)}
                    className="clay-btn clay-btn-secondary px-3 py-1.5 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!quoteText.trim() || isSubmittingRepost}
                    className="clay-btn clay-btn-primary px-4 py-1.5 text-xs font-bold gap-1.5 disabled:opacity-50"
                  >
                    <Repeat2 className="w-3.5 h-3.5" />
                    {isSubmittingRepost ? 'Posting...' : 'Quote & Repost'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Super Thanks ($) Creator Tip Modal */}
      {thanksModalOpen && activeVideo && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="clay-card p-6 bg-white dark:bg-[#181D2E] max-w-md w-full space-y-5 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shadow-md">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                    Send Super Thanks
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    Support {activeVideo.creator.name} directly with a highlighted comment
                  </p>
                </div>
              </div>
              <button
                onClick={() => setThanksModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {/* Quick Amount Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Select Tip Amount (USD)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[2, 5, 10, 25].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setThanksAmount(amt)}
                    className={`py-2 rounded-xl text-xs font-black transition active:scale-95 ${
                      thanksAmount === amt
                        ? 'bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-md shadow-amber-500/25 ring-2 ring-amber-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                {[50, 100].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setThanksAmount(amt)}
                    className={`py-2 rounded-xl text-xs font-black transition active:scale-95 ${
                      thanksAmount === amt
                        ? 'bg-gradient-to-tr from-rose-500 to-pink-500 text-white shadow-md shadow-rose-500/25 ring-2 ring-rose-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    ${amt} VIP
                  </button>
                ))}
              </div>
            </div>

            {/* Live Highlighted Comment Preview */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/40 dark:to-orange-950/30 border border-amber-200 dark:border-amber-900/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  Preview in Comments Feed
                </span>
                <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-black">
                  ${thanksAmount.toFixed(2)} Super Thanks
                </span>
              </div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 italic">
                "{thanksMessage || 'Outstanding engineering demo! Keep it up!'}"
              </p>
            </div>

            {/* Custom message input */}
            <form onSubmit={handleSendSuperThanks} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Message to Creator
                </label>
                <textarea
                  rows={2}
                  value={thanksMessage}
                  onChange={(e) => setThanksMessage(e.target.value)}
                  placeholder="Leave an encouraging message with your tip..."
                  maxLength={160}
                  className="w-full px-3 py-2 text-xs clay-input"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200/60 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                ✨ <strong>Partner Program Terms:</strong> 70% of tip value (${(thanksAmount * 0.7).toFixed(2)}) is credited immediately to {activeVideo.creator.name}'s verified creator balance.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setThanksModalOpen(false)}
                  className="clay-btn clay-btn-secondary px-4 py-2 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingThanks}
                  className="clay-btn clay-btn-primary px-5 py-2 text-xs font-black bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white shadow-md shadow-amber-500/25"
                >
                  {isSendingThanks ? 'Sending...' : `Send $${thanksAmount.toFixed(2)} Thanks`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
