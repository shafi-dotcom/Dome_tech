import React, { useRef, useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { Play, Pause, Volume2, VolumeX, Maximize2, X } from 'lucide-react';

export const MiniPlayer: React.FC = () => {
  const {
    miniPlayerVideo,
    closeMiniPlayer,
    expandMiniPlayer,
    activeView
  } = useApp();

  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  // Auto-play when mounted or source changes
  useEffect(() => {
    if (videoRef.current && miniPlayerVideo) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  }, [miniPlayerVideo?.id]);

  if (!miniPlayerVideo || activeView === 'watch') return null;

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleTimeUpdate = () => {
    if (videoRef.current && videoRef.current.duration) {
      setProgress((videoRef.current.currentTime / videoRef.current.duration) * 100);
    }
  };

  return (
    <div
      onClick={expandMiniPlayer}
      className="fixed bottom-20 lg:bottom-6 right-4 z-40 w-72 sm:w-80 clay-card bg-slate-900/95 dark:bg-[#111422]/95 border border-violet-500/30 text-white shadow-2xl rounded-2xl overflow-hidden cursor-pointer group transition-all duration-200 hover:shadow-violet-500/20 animate-in slide-in-from-bottom-6"
    >
      {/* Video Viewport */}
      <div className="relative aspect-video w-full bg-black overflow-hidden">
        <video
          ref={videoRef}
          src={miniPlayerVideo.videoUrl}
          autoPlay
          playsInline
          muted={isMuted}
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setIsPlaying(false)}
          className="w-full h-full object-cover"
        />

        {/* Hover / Overlay Controls */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-2">
          {/* Top Bar */}
          <div className="flex items-center justify-between text-white/90">
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-600/80">PiP Mini</span>
            <div className="flex items-center gap-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  expandMiniPlayer();
                }}
                title="Expand to Full Player"
                className="p-1 rounded-lg hover:bg-white/20 transition text-white"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  closeMiniPlayer();
                }}
                title="Close Mini-Player"
                className="p-1 rounded-lg hover:bg-white/20 transition text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Center Play Button */}
          <div className="flex items-center justify-center">
            <button
              onClick={togglePlay}
              className="w-9 h-9 rounded-full bg-white/25 hover:bg-white/40 backdrop-blur-md flex items-center justify-center text-white transition active:scale-95"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
            </button>
          </div>

          {/* Bottom Volume */}
          <div className="flex items-center justify-between text-xs">
            <button
              onClick={toggleMute}
              className="p-1 rounded hover:bg-white/20 text-white/90 transition"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>
            <span className="text-[10px] font-medium text-slate-300">Tap to maximize</span>
          </div>
        </div>

        {/* Mini progress line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
          <div
            className="h-full bg-violet-500 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Info footer */}
      <div className="p-2.5 flex items-center justify-between gap-2">
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold text-slate-100 truncate">
            {miniPlayerVideo.title}
          </p>
          <p className="text-[10px] text-slate-400 truncate">
            {miniPlayerVideo.creator.name}
          </p>
        </div>

        <button
          onClick={togglePlay}
          className="p-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white transition active:scale-95 flex-shrink-0"
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5 fill-white" /> : <Play className="w-3.5 h-3.5 fill-white" />}
        </button>
      </div>
    </div>
  );
};
