import React, { useState, useEffect } from 'react';
import { Lightbulb } from 'lucide-react';

const TIPS = [
  "Consistently upload high-quality content to build trust with your viewers.",
  "Engage with your comments to foster a strong, loyal community.",
  "Use descriptive titles and tags to improve your video searchability.",
  "Collaborate with other creators in your niche to reach new audiences.",
  "Analyze your Creator Dashboard metrics to see what content resonates most.",
  "Try out Shorts to boost discoverability and channel visibility.",
];

export const CreatorTipsWidget: React.FC = () => {
  const [tip, setTip] = useState('');
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const fetchTip = () => {
      setIsVisible(false);
      setTimeout(() => {
        setTip(TIPS[Math.floor(Math.random() * TIPS.length)]);
        setIsVisible(true);
      }, 500); // Wait for fade out
    };

    fetchTip(); // Initial fetch
    const interval = setInterval(fetchTip, 10000); // Fetch new tip every 10 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`clay-card p-5 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-slate-900 dark:to-slate-800 border border-amber-200/50 dark:border-slate-700 transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400">
          <Lightbulb className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-black text-slate-900 dark:text-slate-100">Creator Tip</h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
            {tip}
          </p>
        </div>
      </div>
    </div>
  );
};
