import React, { useState, useEffect, useRef } from 'react';
import { Video } from '../../types/index.ts';
import { Eye, Share2, VolumeX, Sparkles, Play } from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge.tsx';
import { QuickReactionMenu } from '../common/QuickReactionMenu.tsx';

interface VideoFeedCardProps {
  video: Video;
  isAutoplay: boolean;
  onVideoClick: (video: Video) => void;
  onShare: (e: React.MouseEvent, video: Video) => void;
  onCreatorClick: (username: string) => void;
}

export const VideoFeedCard: React.FC<VideoFeedCardProps> = ({
  video,
  isAutoplay,
  onVideoClick,
  onShare,
  onCreatorClick
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // IntersectionObserver to detect when video card is scrolled into view
  useEffect(() => {
    if (!isAutoplay || !containerRef.current) {
      setIsInView(false);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          // Trigger autoplay when at least 60% of the video card is visible in viewport
          setIsInView(entry.isIntersecting && entry.intersectionRatio >= 0.6);
        });
      },
      {
        threshold: [0, 0.3, 0.6, 0.9],
        rootMargin: '0px 0px -10% 0px'
      }
    );

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [isAutoplay]);

  // Determine whether to play silent preview (only when isAutoplay setting is enabled)
  const shouldPlayPreview = isAutoplay && (isInView || isHovered);

  useEffect(() => {
    if (videoRef.current) {
      if (shouldPlayPreview) {
        const promise = videoRef.current.play();
        if (promise !== undefined) {
          promise.catch(() => {
            // Autoplay policy prevented playback
          });
        }
      } else {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
      }
    }
  }, [shouldPlayPreview]);

  // Fallback safe stream URL if original is external
  const previewSource = (video.videoUrl && !video.videoUrl.includes('commondatastorage.googleapis.com'))
    ? video.videoUrl
    : '/api/media/stream/video1.mp4';

  return (
    <div
      ref={containerRef}
      onClick={() => onVideoClick(video)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="clay-card p-3 group cursor-pointer flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
    >
      <div>
        {/* Thumbnail & Video Preview Container */}
        <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900 mb-3 shadow-inner">
          {/* Static Poster Image */}
          <img
            src={video.thumbnailUrl}
            alt={video.title}
            className={`w-full h-full object-cover transition-all duration-300 ${
              shouldPlayPreview && videoLoaded ? 'opacity-0 scale-105' : 'opacity-100 group-hover:scale-105'
            }`}
            loading="lazy"
          />

          {/* Autoplay Silent Video Preview on Scroll / Hover (Only when isAutoplay is ON) */}
          {isAutoplay && (
            <video
              ref={videoRef}
              src={previewSource}
              muted
              playsInline
              loop
              preload="metadata"
              onLoadedData={() => setVideoLoaded(true)}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 pointer-events-none ${
                shouldPlayPreview ? 'opacity-100' : 'opacity-0'
              }`}
            />
          )}

          {/* Subtle gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

          {/* Active Auto-play In-View Pill */}
          {shouldPlayPreview && (
            <div className="absolute top-2 left-2 z-10 flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/75 backdrop-blur-md text-white font-black text-[10px] border border-white/20 animate-in fade-in duration-150">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
              <span>Auto-playing</span>
              <VolumeX className="w-3 h-3 text-slate-300 ml-0.5 opacity-80" />
            </div>
          )}

          {/* Autoplay OFF Notice on Hover (if disabled) */}
          {!isAutoplay && isHovered && (
            <div className="absolute top-2 left-2 z-10 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md text-white/90 font-bold text-[9px] border border-white/10">
              <Play className="w-2.5 h-2.5 fill-white text-white" />
              <span>Tap to play</span>
            </div>
          )}

          {/* Duration Badge */}
          <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-lg bg-black/80 text-white text-[11px] font-bold backdrop-blur-sm z-10">
            {video.duration}
          </span>

          {/* Quick Reaction Menu */}
          <QuickReactionMenu videoId={video.id} />

          {/* Quick Share Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onShare(e, video);
            }}
            className="absolute top-2 right-2 p-1.5 rounded-xl bg-black/60 text-white hover:bg-black/85 opacity-0 group-hover:opacity-100 transition active:scale-90 z-20"
            title="Share Video"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Creator Info & Metadata */}
        <div className="flex gap-2.5">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onCreatorClick(video.creator.username);
            }}
            className="flex-shrink-0 active:scale-95 transition"
          >
            <img
              src={video.creator.avatar}
              alt={video.creator.name}
              className="w-9 h-9 rounded-full object-cover border border-violet-200 dark:border-violet-800 shadow-sm"
            />
          </button>

          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
              {video.title}
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-1 truncate">
              <span>{video.creator.name}</span>
              {video.creator.verified && <VerifiedBadge size={12} />}
            </p>
            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
              <span className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                {video.views.toLocaleString()} views
              </span>
              <span>•</span>
              <span className="truncate">{video.category}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
