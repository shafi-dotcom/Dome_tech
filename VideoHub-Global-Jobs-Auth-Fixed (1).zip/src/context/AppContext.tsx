import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Video, Job, Notification, MembershipTier, Playlist, StoreProduct, CartItem } from '../types/index.ts';

type ActiveView =
  | 'home'
  | 'shorts'
  | 'explore'
  | 'watch'
  | 'live_match'
  | 'jobs'
  | 'job_detail'
  | 'upload'
  | 'notifications'
  | 'subscriptions'
  | 'profile'
  | 'messages'
  | 'applications'
  | 'playlists'
  | 'admin'
  | 'policies'
  | 'monetization'
  | 'store';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

export interface PlaylistQueue {
  playlist: Playlist;
  currentIndex: number;
}

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  activeVideo: Video | null;
  setActiveVideo: (video: Video | null) => void;
  activeJob: Job | null;
  setActiveJob: (job: Job | null) => void;
  activeProfileUsername: string | null;
  setActiveProfileUsername: (username: string | null) => void;
  unreadCount: number;
  setUnreadCount: (count: number) => void;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  authModalTab: 'login' | 'register';
  setAuthModalTab: (tab: 'login' | 'register') => void;
  openAuthModal: (tab?: 'login' | 'register') => void;
  loginUser: (user: User, token?: string) => void;
  logout: () => Promise<void>;
  applyModalJob: Job | null;
  setApplyModalJob: (job: Job | null) => void;
  settingsModalOpen: boolean;
  setSettingsModalOpen: (open: boolean) => void;
  reportTarget: { type: 'video' | 'job' | 'comment' | 'user'; id: string; title: string } | null;
  setReportTarget: (target: { type: 'video' | 'job' | 'comment' | 'user'; id: string; title: string } | null) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
  refreshUserData: () => Promise<void>;
  switchDemoUser: (userId: string) => Promise<void>;
  playlists: Playlist[];
  createPlaylist: (name: string) => void;
  addVideoToPlaylist: (playlistId: string, videoId: string) => void;
  removeVideoFromPlaylist: (playlistId: string, videoId: string) => void;
  renamePlaylist: (playlistId: string, name: string) => void;
  reorderPlaylistVideos: (playlistId: string, videoIds: string[]) => void;
  isAutoplay: boolean;
  setIsAutoplay: (autoplay: boolean) => void;
  verificationModalOpen: boolean;
  setVerificationModalOpen: (open: boolean) => void;
  bookmarkedVideoIds: string[];
  toggleBookmark: (videoId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  uploadInitialFormat: 'short' | 'long';
  setUploadInitialFormat: (format: 'short' | 'long') => void;
  navigateToUpload: (format?: 'short' | 'long') => void;
  // Mini-Player Picture-in-Picture State
  miniPlayerVideo: Video | null;
  setMiniPlayerVideo: (video: Video | null) => void;
  openInMiniPlayer: (video: Video) => void;
  closeMiniPlayer: () => void;
  expandMiniPlayer: () => void;
  // Playlist playback queue
  currentPlaylistQueue: PlaylistQueue | null;
  setCurrentPlaylistQueue: (queue: PlaylistQueue | null) => void;
  playPlaylist: (playlist: Playlist, startIndex?: number) => void;
  playNextInPlaylist: () => void;
  playPrevInPlaylist: () => void;
  // Live Subscriber Match Room
  activeMatchId: string | null;
  setActiveMatchId: (id: string | null) => void;
  userCoins: number;
  setUserCoins: React.Dispatch<React.SetStateAction<number>>;
  openLiveMatch: (matchId?: string) => void;
  // Online Shopping Store & Wishlist (Global Context)
  wishlistProductIds: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  cart: CartItem[];
  addToCart: (product: StoreProduct, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  storeCategory: string;
  setStoreCategory: (cat: string) => void;
  openStore: (category?: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [activeJob, setActiveJob] = useState<Job | null>(null);
  const [activeProfileUsername, setActiveProfileUsername] = useState<string | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');

  const openAuthModal = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setAuthModalOpen(true);
  };
  const [applyModalJob, setApplyModalJob] = useState<Job | null>(null);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [verificationModalOpen, setVerificationModalOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ type: 'video' | 'job' | 'comment' | 'user'; id: string; title: string } | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem('playlists');
      return saved ? JSON.parse(saved) : [{ id: 'default', name: 'Watch Later', videoIds: [] }];
    } catch {
      return [{ id: 'default', name: 'Watch Later', videoIds: [] }];
    }
  });
  const [isAutoplay, setIsAutoplay] = useState(() => {
    try {
      const saved = localStorage.getItem('autoplay');
      return saved ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });
  const [bookmarkedVideoIds, setBookmarkedVideoIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [uploadInitialFormat, setUploadInitialFormat] = useState<'short' | 'long'>('long');
  const [activeMatchId, setActiveMatchId] = useState<string | null>(null);
  const [userCoins, setUserCoins] = useState<number>(() => {
    const saved = localStorage.getItem('user_gift_coins');
    return saved && !isNaN(Number(saved)) ? Math.max(500, Number(saved)) : 2500;
  });

  const openLiveMatch = (matchId?: string) => {
    if (matchId) setActiveMatchId(matchId);
    setActiveView('live_match');
  };

  useEffect(() => {
    localStorage.setItem('user_gift_coins', userCoins.toString());
  }, [userCoins]);

  const navigateToUpload = (format: 'short' | 'long' = 'long') => {
    setUploadInitialFormat(format);
    setActiveView('upload');
  };

  useEffect(() => {
    localStorage.setItem('playlists', JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem('autoplay', JSON.stringify(isAutoplay));
  }, [isAutoplay]);

  useEffect(() => {
    localStorage.setItem('bookmarks', JSON.stringify(bookmarkedVideoIds));
  }, [bookmarkedVideoIds]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = `toast-${Date.now()}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  };

  // Online Shopping Store & Wishlist state (stored in global context)
  const [wishlistProductIds, setWishlistProductIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('store_wishlist');
      return saved ? JSON.parse(saved) : ['prod-1', 'prod-4'];
    } catch {
      return ['prod-1', 'prod-4'];
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('store_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [storeCategory, setStoreCategory] = useState('all');

  useEffect(() => {
    try {
      localStorage.setItem('store_wishlist', JSON.stringify(wishlistProductIds));
    } catch (e) {
      console.warn('Could not save wishlist to localStorage', e);
    }
  }, [wishlistProductIds]);

  useEffect(() => {
    try {
      localStorage.setItem('store_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Could not save cart to localStorage', e);
    }
  }, [cart]);

  const toggleWishlist = (productId: string) => {
    setWishlistProductIds(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist', 'info');
        return prev.filter(id => id !== productId);
      } else {
        showToast('💖 Saved to wishlist for later!', 'success');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => {
    return wishlistProductIds.includes(productId);
  };

  const addToCart = (product: StoreProduct, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        showToast(`Updated quantity in cart (${existing.quantity + quantity})`, 'success');
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        showToast(`🛒 Added "${product.title.slice(0, 24)}..." to cart`, 'success');
        return [...prev, { product, quantity }];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    showToast('Item removed from cart', 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartSubtotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);

  const openStore = (category?: string) => {
    if (category) setStoreCategory(category);
    setActiveView('store');
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  // Authentication is maintained by the server's HttpOnly cookie.
  // Never copy session credentials into JavaScript-accessible storage.
  const loginUser = (user: User, _token?: string) => {
    setCurrentUser(user);
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } catch (e) {
      console.warn('Logout notice:', e);
    } finally {
      setCurrentUser(null);
      showToast('You have been logged out successfully.', 'info');
    }
  };

  const refreshUserData = async () => {
    try {
      const headers: Record<string, string> = {};
      const res = await fetch('/api/auth/me', {
        headers,
        credentials: 'include'
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
      }
      const notifRes = await fetch('/api/notifications/unread-count', {
        headers,
        credentials: 'include'
      });
      if (notifRes.ok) {
        const notifData = await notifRes.json();
        setUnreadCount(notifData.unreadCount || 0);
      }
    } catch (e) {
      console.warn('Could not sync user info:', e);
    }
  };

  const switchDemoUser = async (_userId: string) => {
    showToast('Demo account switching is disabled. Please sign in with your own account.', 'info');
  };

  const createPlaylist = (name: string) => {
    const newPlaylist: Playlist = { id: Date.now().toString(), name, videoIds: [] };
    setPlaylists(prev => [...prev, newPlaylist]);
    showToast(`Playlist "${name}" created`);
  };

  const addVideoToPlaylist = (playlistId: string, videoId: string) => {
    setPlaylists(prev => prev.map(p => 
      p.id === playlistId ? { ...p, videoIds: [...p.videoIds, videoId] } : p
    ));
    showToast('Video added to playlist');
  };

  const removeVideoFromPlaylist = (playlistId: string, videoId: string) => {
    setPlaylists(prev => prev.map(p => 
      p.id === playlistId ? { ...p, videoIds: p.videoIds.filter(id => id !== videoId) } : p
    ));
    showToast('Video removed from playlist');
  };

  const deletePlaylist = (playlistId: string) => {
    setPlaylists(prev => prev.filter(p => p.id !== playlistId));
    showToast('Playlist deleted');
  };

  const toggleBookmark = (videoId: string) => {
    setBookmarkedVideoIds(prev =>
      prev.includes(videoId) ? prev.filter(id => id !== videoId) : [...prev, videoId]
    );
    showToast('Bookmark updated');
  };

  useEffect(() => {
    refreshUserData();
    const interval = setInterval(() => {
      fetch('/api/notifications/unread-count')
        .then(r => r.json())
        .then(d => setUnreadCount(d.unreadCount))
        .catch(() => {});
    }, 12000);
    return () => clearInterval(interval);
  }, []);

  const [miniPlayerVideo, setMiniPlayerVideo] = useState<Video | null>(null);
  const [currentPlaylistQueue, setCurrentPlaylistQueue] = useState<PlaylistQueue | null>(null);

  const openInMiniPlayer = (video: Video) => {
    setMiniPlayerVideo(video);
    showToast(`Minimized "${video.title.slice(0, 30)}..." to Floating Player`);
  };

  const closeMiniPlayer = () => {
    setMiniPlayerVideo(null);
  };

  const expandMiniPlayer = () => {
    if (miniPlayerVideo) {
      setActiveVideo(miniPlayerVideo);
      setActiveView('watch');
      setMiniPlayerVideo(null);
    }
  };

  const renamePlaylist = (playlistId: string, name: string) => {
    setPlaylists(prev => prev.map(p => p.id === playlistId ? { ...p, name } : p));
    showToast(`Playlist renamed to "${name}"`);
  };

  const reorderPlaylistVideos = (playlistId: string, videoIds: string[]) => {
    setPlaylists(prev => prev.map(p => p.id === playlistId ? { ...p, videoIds } : p));
  };

  const playPlaylist = async (playlist: Playlist, startIndex = 0) => {
    if (!playlist.videoIds || playlist.videoIds.length === 0) {
      showToast('This playlist is currently empty', 'info');
      return;
    }
    const safeIndex = Math.max(0, Math.min(startIndex, playlist.videoIds.length - 1));
    const targetVideoId = playlist.videoIds[safeIndex];

    try {
      const res = await fetch(`/api/videos/${targetVideoId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.video) {
          setCurrentPlaylistQueue({ playlist, currentIndex: safeIndex });
          setActiveVideo(data.video);
          setActiveView('watch');
          showToast(`Playing playlist "${playlist.name}" (${safeIndex + 1}/${playlist.videoIds.length})`);
          return;
        }
      }
    } catch (e) {
      console.warn('Error loading playlist video:', e);
    }
    // Fallback: search in existing videos
    setCurrentPlaylistQueue({ playlist, currentIndex: safeIndex });
    setActiveView('watch');
  };

  const playNextInPlaylist = async () => {
    if (!currentPlaylistQueue) return;
    const nextIdx = currentPlaylistQueue.currentIndex + 1;
    if (nextIdx < currentPlaylistQueue.playlist.videoIds.length) {
      const nextId = currentPlaylistQueue.playlist.videoIds[nextIdx];
      try {
        const res = await fetch(`/api/videos/${nextId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.video) {
            setCurrentPlaylistQueue({ ...currentPlaylistQueue, currentIndex: nextIdx });
            setActiveVideo(data.video);
            return;
          }
        }
      } catch (e) {}
    } else {
      showToast('Reached the end of the playlist');
    }
  };

  const playPrevInPlaylist = async () => {
    if (!currentPlaylistQueue) return;
    const prevIdx = currentPlaylistQueue.currentIndex - 1;
    if (prevIdx >= 0) {
      const prevId = currentPlaylistQueue.playlist.videoIds[prevIdx];
      try {
        const res = await fetch(`/api/videos/${prevId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.video) {
            setCurrentPlaylistQueue({ ...currentPlaylistQueue, currentIndex: prevIdx });
            setActiveVideo(data.video);
            return;
          }
        }
      } catch (e) {}
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        activeView,
        setActiveView,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        activeVideo,
        setActiveVideo,
        activeJob,
        setActiveJob,
        activeProfileUsername,
        setActiveProfileUsername,
        unreadCount,
        setUnreadCount,
        authModalOpen,
        setAuthModalOpen,
        authModalTab,
        setAuthModalTab,
        openAuthModal,
        loginUser,
        logout,
        applyModalJob,
        setApplyModalJob,
        settingsModalOpen,
        setSettingsModalOpen,
        reportTarget,
        setReportTarget,
        isDarkMode,
        toggleDarkMode,
        toasts,
        showToast,
        refreshUserData,
        switchDemoUser,
        playlists,
        createPlaylist,
        addVideoToPlaylist,
        removeVideoFromPlaylist,
        renamePlaylist,
        reorderPlaylistVideos,
        deletePlaylist,
        isAutoplay,
        setIsAutoplay,
        verificationModalOpen,
        setVerificationModalOpen,
        bookmarkedVideoIds,
        toggleBookmark,
        uploadInitialFormat,
        setUploadInitialFormat,
        navigateToUpload,
        miniPlayerVideo,
        setMiniPlayerVideo,
        openInMiniPlayer,
        closeMiniPlayer,
        expandMiniPlayer,
        currentPlaylistQueue,
        setCurrentPlaylistQueue,
        playPlaylist,
        playNextInPlaylist,
        playPrevInPlaylist,
        activeMatchId,
        setActiveMatchId,
        userCoins,
        setUserCoins,
        openLiveMatch,
        // Online Shopping Store & Wishlist
        wishlistProductIds,
        toggleWishlist,
        isInWishlist,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        isCartOpen,
        setIsCartOpen,
        storeCategory,
        setStoreCategory,
        openStore
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
