import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'es' | 'fr' | 'ja' | 'ar';

export interface LanguageOption {
  code: Language;
  name: string;
  nativeName: string;
  flag: string;
  region: string;
}

export const AVAILABLE_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English (US)', flag: '🇺🇸', region: 'United States & Global' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', region: 'España & Latinoamérica' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', region: 'France & Francophonie' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵', region: '日本 (Japan)' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', region: 'الشرق الأوسط والخليج' }
];

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  currentLanguageDetails: LanguageOption;
  languages: LanguageOption[];
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    'settings': 'Settings',
    'general_settings': 'General Preferences',
    'autoplay': 'Auto-Play on Scroll',
    'autoplay_desc': 'Automatically play video previews on scroll in Home and Shorts feeds',
    'language': 'Interface Language',
    'language_desc': 'Select your preferred language across navigation and controls',
    'language_selector': 'Language Selection',
    'login': 'Sign In',
    'register': 'Create Account',
    'logout': 'Sign Out',
    'welcome_back': 'Welcome Back',
    'search': 'Search videos, curtain wall tech, jobs...',
    'saved': 'Saved',
    'store': 'Store & Merch',
    'home': 'Home Feed',
    'shorts': 'Shorts Reel',
    'jobs': 'Global Jobs',
    'profile': 'My Channel',
    'close': 'Close',
    'enabled': 'Enabled',
    'disabled': 'Disabled',
    'save_changes': 'Save Changes'
  },
  es: {
    'settings': 'Configuración',
    'general_settings': 'Preferencias Generales',
    'autoplay': 'Reproducción Automática al Desplazarse',
    'autoplay_desc': 'Reproducir vistas previas de video automáticamente al desplazarse',
    'language': 'Idioma de la Interfaz',
    'language_desc': 'Seleccione su idioma preferido en navegación y controles',
    'language_selector': 'Selección de Idioma',
    'login': 'Iniciar Sesión',
    'register': 'Crear Cuenta',
    'logout': 'Cerrar Sesión',
    'welcome_back': 'Bienvenido de Nuevo',
    'search': 'Buscar videos, tecnología de muros cortina, empleos...',
    'saved': 'Guardados',
    'store': 'Tienda y Productos',
    'home': 'Inicio',
    'shorts': 'Shorts',
    'jobs': 'Empleos Globales',
    'profile': 'Mi Canal',
    'close': 'Cerrar',
    'enabled': 'Habilitado',
    'disabled': 'Deshabilitado',
    'save_changes': 'Guardar Cambios'
  },
  fr: {
    'settings': 'Paramètres',
    'general_settings': 'Préférences Générales',
    'autoplay': 'Lecture Automatique au Défilement',
    'autoplay_desc': 'Lire automatiquement les aperçus vidéo en défilant dans Accueil et Shorts',
    'language': "Langue de l'Interface",
    'language_desc': "Choisissez votre langue préférée pour la navigation et l'interface",
    'language_selector': 'Sélection de la Langue',
    'login': 'Se Connecter',
    'register': 'Créer un Compte',
    'logout': 'Déconnexion',
    'welcome_back': 'Bon retour',
    'search': 'Rechercher vidéos, façades vitrées, emplois...',
    'saved': 'Enregistrés',
    'store': 'Boutique & Produits',
    'home': 'Accueil',
    'shorts': 'Shorts',
    'jobs': 'Offres Internationales',
    'profile': 'Ma Chaîne',
    'close': 'Fermer',
    'enabled': 'Activé',
    'disabled': 'Désactivé',
    'save_changes': 'Enregistrer'
  },
  ja: {
    'settings': '設定',
    'general_settings': '一般環境設定',
    'autoplay': 'スクロール自動再生',
    'autoplay_desc': 'ホームおよびショートフィードのスクロール時に動画プレビューを自動再生',
    'language': 'インターフェース言語',
    'language_desc': 'ナビゲーションおよび操作画面の表示言語を選択します',
    'language_selector': '言語の選択',
    'login': 'サインイン / ログイン',
    'register': 'アカウント新規登録',
    'logout': 'サインアウト',
    'welcome_back': 'おかえりなさい',
    'search': '動画、カーテンウォール技術、求人を検索...',
    'saved': '保存済み',
    'store': 'オンラインストア & グッズ',
    'home': 'ホームフィード',
    'shorts': 'ショートリール',
    'jobs': 'グローバルエンジニア求人',
    'profile': 'マイチャンネル & プロフィール',
    'close': '閉じる',
    'enabled': '有効',
    'disabled': '無効',
    'save_changes': '変更を保存'
  },
  ar: {
    'settings': 'الإعدادات',
    'general_settings': 'التفضيلات العامة',
    'autoplay': 'التشغيل التلقائي عند التمرير',
    'autoplay_desc': 'تشغيل معاينات الفيديو تلقائياً أثناء التمرير في خلاصة الفيديو والشورتس',
    'language': 'لغة الواجهة',
    'language_desc': 'اختر لغة الواجهة والقوائم المفضلة لديك',
    'language_selector': 'تحديد اللغة',
    'login': 'تسجيل الدخول',
    'register': 'إنشاء حساب جديد',
    'logout': 'تسجيل الخروج',
    'welcome_back': 'مرحباً بك مجدداً',
    'search': 'البحث عن الفيديوهات، واجهات الألمنيوم، والوظائف...',
    'saved': 'المحفوظات',
    'store': 'المتجر والمنتجات',
    'home': 'الرئيسية',
    'shorts': 'شورتس',
    'jobs': 'وظائف هندسية عالمية',
    'profile': 'قناتي وملفي الشخصي',
    'close': 'إغلاق',
    'enabled': 'مفعل',
    'disabled': 'معطل',
    'save_changes': 'حفظ التغييرات'
  }
};

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('preferred_language') as Language;
      if (saved && (saved === 'en' || saved === 'es' || saved === 'fr' || saved === 'ja' || saved === 'ar')) {
        return saved;
      }
      return 'en';
    } catch {
      return 'en';
    }
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('preferred_language', lang);
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const t = (key: string) => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  const currentLanguageDetails =
    AVAILABLE_LANGUAGES.find(l => l.code === language) || AVAILABLE_LANGUAGES[0];

  return (
    <I18nContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currentLanguageDetails,
        languages: AVAILABLE_LANGUAGES
      }}
    >
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used within an I18nProvider');
  return context;
};
