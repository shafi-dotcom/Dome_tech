# VideoHub + Global Jobs — Vercel Package Validation

## Package preparation
- Added `.nvmrc` selecting Node.js 24.
- Added `VERCEL-DEPLOYMENT-GUIDE.md` with the Express/Vercel settings and required production environment variables.
- Corrected the README deployment instructions: Vercel Output Directory must be left empty for the Express deployment; Netlify continues to publish `dist`.
- Preserved the existing Express default export, Vite build lifecycle scripts, and `public/videos` media.
- Excluded `.aistudio` temporary workspace files, generated build output, local dependencies, and environment-secret files from the deployment ZIP.

## Checks completed
- Static security smoke checks: **17/17 passed**.
- JavaScript syntax checks: **5/5 passed** (`index.js`, `admin.js`, `db.js`, `seed-data.js`, `netlify/functions/api.js`).
- Vercel static asset preparation/cleanup simulation: **passed**. Generated `dist` files were copied into `public`, cleaned on the next prebuild, and existing `public/videos` files were preserved.
- ZIP integrity: verified after packaging.

## Current supplied deployment target
- Production origin in this package: `https://videohub-global-jobs1.vercel.app`. Set Vercel `APP_URL` to this exact origin.

## Not completed
- `npm install` did not finish in this execution environment, so `npm test`, `npm run lint`, and `npm run build` could not be run.
- No live Vercel deployment, production environment, MongoDB connection, Google OAuth, or Cloudinary integration was exercised.
- Static checks are not a penetration test or a guarantee of production security.

## Required before production deployment
Set `NODE_ENV=production`, `MONGODB_URI`, `MONGODB_DB_NAME`, a unique `AUTH_SECRET` (32+ characters; preferably `openssl rand -hex 48`), and `APP_URL` equal to `https://videohub-global-jobs1.vercel.app` (or the exact production origin you use). Configure `ADMIN_EMAILS` and optional Google/Cloudinary credentials as needed. Keep secrets in Vercel Environment Variables, never in Git or the ZIP.
