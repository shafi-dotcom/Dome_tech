# VideoHub + Global Jobs — Vercel Deployment Guide

## Deploy this package

**Production website:** https://videohub-global-jobs1.vercel.app

The ZIP contains the deployable project at its root. Do not upload the outer ZIP from the original GitHub download; use this cleaned package or import the extracted project folder into GitHub.

1. Extract the ZIP. The deployable project root is the folder containing `package.json` and `index.js`.
2. In Vercel, create a project and import this folder/repository.
3. Set the Root Directory to the project root.
4. Select Node.js **24.x** (the repository `.nvmrc` also specifies 24).
5. Set Build Command to `npm run build`.
6. Leave Output Directory **empty**. This is an Express deployment, not a static-only Vite deployment.
7. Deploy.

Vercel's Express detection uses the root `index.js` default export. Do not add a catch-all rewrite that bypasses the Express app. The build lifecycle runs `prebuild`, `build`, and `postbuild`: generated Vite assets are copied from `dist/` into `public/`, while existing `public/videos/` assets are retained. A manifest lets the next `prebuild` remove only generated frontend files.

## Required production environment

Set these in Vercel Project Settings → Environment Variables (Production, and Preview only if you intentionally use real services there):

- `NODE_ENV` = `production`
- `MONGODB_URI` = your MongoDB Atlas connection string
- `MONGODB_DB_NAME` = `videohub_jobs`
- `AUTH_SECRET` = a unique random secret, at least 32 characters (recommended: `openssl rand -hex 48`)
- `APP_URL` = `https://videohub-global-jobs1.vercel.app` (must exactly match the production site origin)
- `ADMIN_EMAILS` = exact comma-separated administrator email allowlist

Optional, only when enabling those integrations:

- `GOOGLE_CLIENT_ID` — Google Identity Services web client ID
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` — durable serverless video storage

Never put real credentials in the ZIP, source code, or Git. If a credential was ever committed or shared, rotate it.

## Security and production setup

- Store all real credentials only in Vercel Project Settings → Environment Variables. Never commit `.env` files or paste secrets into source code.
- Generate `AUTH_SECRET` with `openssl rand -hex 48`; do not reuse a password or another project's secret.
- Use a MongoDB Atlas database user limited to this application's database, and allow network access only as narrowly as your deployment setup permits.
- Put only trusted administrator email addresses in `ADMIN_EMAILS`.
- Configure Cloudinary before enabling user video uploads. Vercel function storage is ephemeral; local uploads are not durable.
- Configure Vercel Firewall / platform rate limiting as an additional layer. The in-process limiter is per serverless instance, not global.
- If you attach a custom domain later, update `APP_URL` to that exact HTTPS origin and redeploy.

## After deployment

Check the following:

- `https://YOUR-DOMAIN/api/health` reports a healthy persistent database.
- Home page and a nested browser route load directly.
- Registration, login, logout, and `/api/auth/me` behave correctly.
- Unauthenticated API mutations return 401.
- Cookie-authenticated mutations from an unapproved Origin are rejected.
- Uploads use configured durable storage.
- Logs contain no missing-environment-variable or database initialization errors.

## Deployment verification status

The package's static security smoke test can be run locally with `npm run security:check`. The build and full application tests require dependencies to install successfully (`npm install`) and must be run before production release. After deployment, use the health endpoint and manual checks below. A passing static check is not a penetration test or proof that the live deployment is secure.

## Important limitations

- The source package's static security smoke test is not a penetration test.
- Full build, type-check, automated application tests, OAuth, database, Cloudinary, and live Vercel behavior must be verified in the actual deployment environment.
- Production startup intentionally fails closed if MongoDB or a sufficiently strong `AUTH_SECRET` is missing.
- Payments and payouts are intentionally disabled in production until a real payment provider and verified webhook/ledger implementation are added.
