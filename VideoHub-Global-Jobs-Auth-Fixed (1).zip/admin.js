// ========================================================
// admin.js - Reusable Administrative Service Module
// Provides secure, server-side management operations for
// VideoHub + Global Jobs platform.
// ========================================================

import { memoryStore } from './db.js';

// The store is persisted to MongoDB by db.js, so admin logic always works on it.
const connectToDatabase = async () => ({ db: null, isConnected: false });

/**
 * Record an action to the audit log
 */
export async function logAdminAction(adminUser, action, details) {
  const logEntry = {
    id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    adminId: adminUser?.id || 'system',
    adminName: adminUser?.name || 'Authorized Admin',
    action,
    details,
    timestamp: new Date().toISOString()
  };

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    try {
      await db.collection('auditLogs').insertOne(logEntry);
    } catch (e) {
      console.error('[Admin Log Error]', e);
    }
  } else {
    memoryStore.auditLogs.unshift(logEntry);
    if (memoryStore.auditLogs.length > 200) {
      memoryStore.auditLogs.pop();
    }
  }

  return logEntry;
}

/**
 * Retrieve platform overview metrics
 */
export async function getPlatformMetrics() {
  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    const totalUsers = await db.collection('users').countDocuments();
    const totalVideos = await db.collection('videos').countDocuments();
    const totalJobs = await db.collection('jobs').countDocuments();
    const totalApplications = await db.collection('applications').countDocuments();
    const pendingReports = await db.collection('reports').countDocuments({ status: 'pending' });
    const activeVacancies = await db.collection('jobs').countDocuments({ status: 'active' });

    return {
      totalUsers,
      totalVideos,
      totalJobs,
      activeVacancies,
      totalApplications,
      pendingReports,
      proSubscribers: Math.floor(totalUsers * 0.28) + 12,
      databaseType: 'MongoDB Atlas'
    };
  }

  return {
    totalUsers: memoryStore.users.length,
    totalVideos: memoryStore.videos.length,
    totalJobs: memoryStore.jobs.length,
    activeVacancies: memoryStore.jobs.filter(j => j.status === 'active').length,
    totalApplications: memoryStore.applications.length,
    pendingReports: memoryStore.reports.filter(r => r.status === 'pending').length,
    proSubscribers: memoryStore.users.filter(u => u.membershipPlan !== 'free').length,
    databaseType: 'In-Memory Resilient Store'
  };
}

/**
 * List and filter registered users
 */
export async function listUsers({ search = '', role = '', status = '', page = 1, limit = 20 }) {
  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    const query = {};
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { username: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    if (role) query.role = role;
    if (status) query.status = status;

    const skip = (page - 1) * limit;
    const users = await db.collection('users').find(query).skip(skip).limit(limit).toArray();
    const total = await db.collection('users').countDocuments(query);

    return { users, total, page, totalPages: Math.ceil(total / limit) };
  }

  let filtered = [...memoryStore.users];
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(u => u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }
  if (role) filtered = filtered.filter(u => u.role === role);
  if (status) filtered = filtered.filter(u => u.status === status);

  const total = filtered.length;
  const skip = (page - 1) * limit;
  const users = filtered.slice(skip, skip + limit);

  return { users, total, page, totalPages: Math.ceil(total / limit) };
}

/**
 * Suspend or restore a user account
 */
export async function updateUserStatus(userId, newStatus, adminUser) {
  if (!['active', 'suspended'].includes(newStatus)) {
    throw new Error('Invalid user status. Allowed: active, suspended');
  }

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    await db.collection('users').updateOne({ id: userId }, { $set: { status: newStatus } });
  } else {
    const user = memoryStore.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');
    user.status = newStatus;
  }

  await logAdminAction(adminUser, 'USER_STATUS_CHANGE', `Updated user (${userId}) status to ${newStatus}`);
  return { success: true, userId, status: newStatus };
}

/**
 * Assign role and verification badge to a user
 */
export async function updateUserRole(userId, { role, verified }, adminUser) {
  const allowedRoles = ['user', 'creator', 'employer', 'admin'];
  if (role && !allowedRoles.includes(role)) {
    throw new Error('Invalid role specified');
  }

  const updateFields = {};
  if (role) updateFields.role = role;
  if (typeof verified === 'boolean') updateFields.verified = verified;

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    await db.collection('users').updateOne({ id: userId }, { $set: updateFields });
  } else {
    const user = memoryStore.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');
    if (role) user.role = role;
    if (typeof verified === 'boolean') user.verified = verified;
  }

  await logAdminAction(adminUser, 'USER_ROLE_OR_VERIFY_CHANGE', `Updated user (${userId}) role: ${role}, verified: ${verified}`);
  return { success: true, userId, ...updateFields };
}

/**
 * Moderation: Update video status (approve, hide, flag, remove)
 */
export async function moderateVideo(videoId, moderationStatus, adminUser) {
  const allowed = ['approved', 'pending', 'flagged', 'removed'];
  if (!allowed.includes(moderationStatus)) {
    throw new Error('Invalid video moderation status');
  }

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    await db.collection('videos').updateOne({ id: videoId }, { $set: { moderationStatus } });
  } else {
    const vid = memoryStore.videos.find(v => v.id === videoId);
    if (!vid) throw new Error('Video not found');
    vid.moderationStatus = moderationStatus;
  }

  await logAdminAction(adminUser, 'MODERATE_VIDEO', `Changed video (${videoId}) moderation status to ${moderationStatus}`);
  return { success: true, videoId, moderationStatus };
}

/**
 * Moderation: Update job listing status (active, closed, under_review, featured)
 */
export async function moderateJob(jobId, { status, featured }, adminUser) {
  const updateFields = {};
  if (status) updateFields.status = status;
  if (typeof featured === 'boolean') updateFields.featured = featured;

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    await db.collection('jobs').updateOne({ id: jobId }, { $set: updateFields });
  } else {
    const job = memoryStore.jobs.find(j => j.id === jobId);
    if (!job) throw new Error('Job listing not found');
    if (status) job.status = status;
    if (typeof featured === 'boolean') job.featured = featured;
  }

  await logAdminAction(adminUser, 'MODERATE_JOB', `Updated job (${jobId}) status: ${status}, featured: ${featured}`);
  return { success: true, jobId, ...updateFields };
}

/**
 * Review and resolve reported content
 */
export async function resolveReport(reportId, resolutionStatus, adminUser) {
  if (!['resolved', 'dismissed'].includes(resolutionStatus)) {
    throw new Error('Resolution status must be resolved or dismissed');
  }

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    await db.collection('reports').updateOne({ id: reportId }, { $set: { status: resolutionStatus } });
  } else {
    const rep = memoryStore.reports.find(r => r.id === reportId);
    if (!rep) throw new Error('Report item not found');
    rep.status = resolutionStatus;
  }

  await logAdminAction(adminUser, 'RESOLVE_REPORT', `Report ${reportId} marked as ${resolutionStatus}`);
  return { success: true, reportId, status: resolutionStatus };
}

/**
 * Broadcast an administrative announcement to all or specific users
 */
export async function sendAdminAnnouncement(title, message, target = 'all', adminUser) {
  const notifTemplate = {
    id: `notif-ann-${Date.now()}`,
    actorId: adminUser?.id || 'u-admin',
    actorName: adminUser?.name || 'VideoHub Admin',
    actorAvatar: adminUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
    type: 'admin_announcement',
    title,
    message,
    read: false,
    createdAt: new Date().toISOString()
  };

  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    const allUsers = await db.collection('users').find({}).project({ id: 1 }).toArray();
    const notifs = allUsers.map(u => ({ ...notifTemplate, recipientId: u.id, id: `notif-${u.id}-${Date.now()}` }));
    if (notifs.length > 0) {
      await db.collection('notifications').insertMany(notifs);
    }
  } else {
    memoryStore.users.forEach(u => {
      memoryStore.notifications.unshift({
        ...notifTemplate,
        id: `notif-${u.id}-${Date.now()}`,
        recipientId: u.id
      });
    });
  }

  await logAdminAction(adminUser, 'BROADCAST_ANNOUNCEMENT', `Sent announcement: "${title}" to ${target}`);
  return { success: true, title, message };
}

/**
 * Get audit logs for system governance
 */
export async function getAuditLogs(limit = 50) {
  const { db, isConnected } = await connectToDatabase();
  if (isConnected && db) {
    return await db.collection('auditLogs').find({}).sort({ timestamp: -1 }).limit(limit).toArray();
  }
  return memoryStore.auditLogs.slice(0, limit);
}
