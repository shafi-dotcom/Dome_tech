import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distDir = path.join(root, 'dist');
const publicDir = path.join(root, 'public');
const manifestPath = path.join(root, '.vercel-public-manifest.json');

if (!fs.existsSync(path.join(distDir, 'index.html'))) {
  throw new Error('Vite build did not produce dist/index.html');
}
fs.mkdirSync(publicDir, { recursive: true });
const copied = [];
for (const name of fs.readdirSync(distDir)) {
  // Original media is already stored under public/videos and should not be duplicated.
  if (name === 'videos') continue;
  fs.cpSync(path.join(distDir, name), path.join(publicDir, name), { recursive: true });
  copied.push(name);
}
fs.writeFileSync(manifestPath, JSON.stringify(copied, null, 2) + '\n');
console.log(`Prepared ${copied.length} frontend item(s) in public/ for Vercel.`);
